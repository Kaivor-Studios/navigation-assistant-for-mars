MARSWALK Home Preview v0.3

1. Extract this ZIP file.
2. Open index.html in Chrome, Edge, or another modern browser.
3. Keep an internet connection active: the page loads Three.js and Mars imagery from external sources.

This is a standalone preview and does not modify your main MARSWALK project.
