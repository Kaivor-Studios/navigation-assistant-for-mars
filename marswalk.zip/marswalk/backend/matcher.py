"""Runtime Mars place matcher loaded by the server.

Two stages over the trained TF-IDF + nearest-neighbour index:

  1. Exact alias / longest-contained-alias lookup. His five hardcoded places
     are first in the place list, so their aliases register first and win any
     tie — "olympus" resolves to his Olympus Mons, not olympus-rupes.
  2. Fuzzy character n-gram TF-IDF nearest-neighbour, gated by a cosine
     threshold. Handles typos ("olympous mons") and partial names.

This is the trained model that augments his app.js searchLocation(): his five
places and coordinate parser still run first, unchanged; only when both miss
does the server consult this matcher.
"""
import os, pickle
from difflib import SequenceMatcher


class Matcher:
    def __init__(self, model_path):
        m = pickle.load(open(model_path, "rb"))
        self.places = m["places"]
        self.vec = m["vectorizer"]
        self.nn = m["nn"]
        self.labels = m["labels"]
        self.thr = m["threshold"]
        # alias -> place index; first registration wins (his 5 are first)
        self.alias_index = {}
        for i, p in enumerate(self.places):
            names = [p["name"].lower()]
            names += [a.lower() for a in p.get("aliases", [])]
            for n in names:
                if n not in self.alias_index:
                    self.alias_index[n] = i
        # sorted by length desc for longest-contained matching
        self._aliases_by_len = sorted(self.alias_index.keys(), key=len, reverse=True)

    def _pack(self, i, confidence):
        p = self.places[i]
        return {
            "ok": True, "id": p["id"], "name": p["name"],
            "lat": p["lat"], "lon": p["lon"], "type": p.get("type", ""),
            "detail": p.get("detail", ""), "source": p.get("source", ""),
            "confidence": round(float(confidence), 3),
        }

    def search(self, q):
        q = (q or "").strip().lower()
        if not q:
            return {"ok": False, "reason": "empty"}
        # stage 1a: exact alias
        if q in self.alias_index:
            return self._pack(self.alias_index[q], 1.0)
        # stage 1b: longest contained alias ("take me to olympus mons")
        for alias in self._aliases_by_len:
            if alias in q:
                return self._pack(self.alias_index[alias], 0.95)
        # stage 2: fuzzy TF-IDF nearest neighbours supply recall candidates;
        # a difflib ratio against each candidate's name+aliases picks the best
        # and gates out unrelated queries (no hallucinated matches).
        qv = self.vec.transform([q])
        k = min(10, len(self.labels))
        dist, idx = self.nn.kneighbors(qv, n_neighbors=k)
        best_i, best_score = -1, 0.0
        for j in range(k):
            pi = self.labels[idx[0, j]]
            p = self.places[pi]
            refs = [p["name"].lower()] + [a.lower() for a in p.get("aliases", [])]
            # max ratio over each alias individually (a long alias list would
            # otherwise dilute the concatenated-string ratio)
            ratio = max(SequenceMatcher(None, q, r).ratio() for r in refs)
            if ratio > best_score:
                best_score, best_i = ratio, pi
        if best_i >= 0 and best_score >= 0.55:
            return self._pack(best_i, best_score)
        return {"ok": False, "confidence": round(float(best_score), 3), "reason": "below precision gate"}


_singleton = None


def get_matcher(model_path=None):
    global _singleton
    if _singleton is None:
        here = os.path.dirname(os.path.abspath(__file__))
        if model_path is None:
            model_path = os.path.join(here, "model", "marswalk_matcher.pkl")
        _singleton = Matcher(model_path)
    return _singleton
