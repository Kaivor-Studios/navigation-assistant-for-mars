"""Marswalk backend — minimal server built around his frontend.

Serves his three frontend files (index.html, app.js, styles.css) and one
trained-AI endpoint (/search) that augments his searchLocation().

His files are byte-identical on disk to his GitHub repo (md5-verified at boot).
By default the server makes ONE surgical edit to app.js AT SERVE TIME so that
searchLocation(), only after his five hardcoded places and coordinate parser
both miss, asks the trained Mars matcher and flies there using his own
flyTo / selectLocation / closePanel. Set MARSWALK_PURE=1 to serve his app.js
with zero edits.

Nothing else is added: no extra UI, no other AI services, no chat, no terrain
endpoints. His interface stays exactly his.
"""
import os
from fastapi import FastAPI, Query
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse, Response
import uvicorn

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)            # the marswalk/ folder (his files live here)
FRONTEND = ROOT                         # index.html, app.js, styles.css, README.md
PURE = os.environ.get("MARSWALK_PURE", "0") == "1"

EXPECTED_MD5 = {
    "index.html":  "5dd743614311a076d47e59d6b2232a8e",
    "app.js":      "e168d1d801b976e4adaa72f9053c99a4",
    "styles.css":  "9d96c59e3a61f5f7e6efd7f38049b237",
    "README.md":   "99f49a2347b6f3292dfd29072dd50b55",
}

# --- the one surgical edit to his app.js ------------------------------------
_SEARCH_FN = b"  function searchLocation(query) {"
_SEARCH_FN_ASYNC = b"  async function searchLocation(query) {"
_PLACE_NOT_FOUND = b'    ui.coordinate.textContent = "Place not found \xc2\xb7 try Gale, Jezero or coordinates";'
_MATCHER_FALLBACK = (
    b'    try {\n'
    b'      const _r = await (await fetch("/search?q=" + encodeURIComponent(normalized))).json();\n'
    b'      if (_r && _r.ok) {\n'
    b'        closePanel("search-panel");\n'
    b'        viewer.camera.flyTo({ destination: CesiumLib.Cartesian3.fromDegrees(normalizeLongitude(_r.lon), _r.lat, 690000, MARS), orientation: { heading: 0, pitch: CesiumLib.Math.toRadians(-48), roll: 0 }, duration: 1.7, complete: () => selectLocation(_r.lat, normalizeLongitude(_r.lon)) });\n'
    b'        ui.coordinate.textContent = _r.name + (_r.type ? " \xc2\xb7 " + _r.type : "");\n'
    b'        return;\n'
    b'      }\n'
    b'    } catch (_e) { console.warn("marswalk search backend unavailable", _e); }\n'
    b'    '
)


def build_boosted_app_js(raw: bytes) -> bytes:
    """Apply the two surgical edits to his app.js bytes."""
    if _SEARCH_FN not in raw:
        raise RuntimeError("searchLocation signature not found in his app.js — refusing to patch")
    if _PLACE_NOT_FOUND not in raw:
        raise RuntimeError("searchLocation fallback line not found in his app.js — refusing to patch")
    out = raw.replace(_SEARCH_FN, _SEARCH_FN_ASYNC, 1)
    out = out.replace(_PLACE_NOT_FOUND, _MATCHER_FALLBACK + _PLACE_NOT_FOUND.strip(), 1)
    return out


def _read(name):
    with open(os.path.join(FRONTEND, name), "rb") as fh:
        return fh.read()


def _md5(data: bytes) -> str:
    import hashlib
    return hashlib.md5(data).hexdigest()


# --- verify his files are byte-identical to GitHub at boot ------------------
_raw_app_js = _read("app.js")
_raw_index = _read("index.html")
_raw_styles = _read("styles.css")
_raw_readme = _read("README.md")
for _name, _data in [("index.html", _raw_index), ("app.js", _raw_app_js),
                     ("styles.css", _raw_styles), ("README.md", _raw_readme)]:
    _got = _md5(_data)
    if _got != EXPECTED_MD5[_name]:
        raise SystemExit(f"ERROR: {_name} md5 {_got} != expected {EXPECTED_MD5[_name]} "
                         f"(his file was modified on disk; refusing to serve).")
print(f"[marswalk] his 4 frontend files verified byte-identical to GitHub (md5 ok).")

_app_js_served = _raw_app_js if PURE else build_boosted_app_js(_raw_app_js)
if PURE:
    print("[marswalk] MARSWALK_PURE=1 → serving his app.js with ZERO edits.")
else:
    print(f"[marswalk] app.js served with 1 surgical edit (searchLocation async + matcher fallback). "
          f"His file on disk unchanged ({len(_raw_app_js)} bytes).")

# --- matcher (trained) ------------------------------------------------------
from matcher import get_matcher  # noqa: E402
_matcher = get_matcher()

app = FastAPI(title="marswalk-backend", docs_url=None, redoc_url=None, openapi_url=None)


@app.get("/", response_class=HTMLResponse)
def index():
    return Response(_raw_index, media_type="text/html; charset=utf-8")


@app.get("/app.js", response_class=PlainTextResponse)
def app_js():
    return Response(_app_js_served, media_type="application/javascript; charset=utf-8")


@app.get("/styles.css", response_class=PlainTextResponse)
def styles():
    return Response(_raw_styles, media_type="text/css; charset=utf-8")


@app.get("/search")
def search(q: str = Query("", description="free-text Mars place query")):
    r = _matcher.search(q)
    return JSONResponse(r)


@app.get("/healthz")
def healthz():
    return {"ok": True, "pure": PURE, "places": len(_matcher.places),
            "frontend_md5_verified": True}


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8000"))
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="info")
