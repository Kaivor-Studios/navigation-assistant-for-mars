"""Evaluate the runtime matcher on realistic queries.

Two columns matter:
  - "his app.js would find it?"  — his searchLocation() only matches his five
    hardcoded place ids/names by substring, or a coordinate. Everything else
    returns "Place not found".
  - "matcher finds it?"          — the trained two-stage matcher.

The point: every query his app misses that the matcher resolves is "his model
made better by training". His five places still resolve (baseline preserved).
"""
import os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "backend"))
from matcher import get_matcher

HIS_IDS = {"gale", "jezero", "olympus", "valles", "eberswalde"}
HIS_NAMES = {"gale crater", "jezero crater", "olympus mons", "valles marineris", "eberswalde crater"}

# (query, expected place id OR None if any/not-found is acceptable)
TESTS = [
    # --- his five (baseline: must still work) ---
    ("gale", "gale"), ("Gale Crater", "gale"), ("jezero", "jezero"),
    ("Jezero Crater", "jezero"), ("olympus", "olympus"), ("Olympus Mons", "olympus"),
    ("valles", "valles"), ("Valles Marineris", "valles"), ("eberswalde", "eberswalde"),
    # --- typos (his app misses) ---
    ("olympous mons", "olympus"), ("jzeno", "jezero"), ("gael crater", "gale"),
    # --- paraphrases / aliases (his app misses) ---
    ("mount olympus", "olympus"), ("tallest volcano", "olympus"),
    ("curiosity rover", "gale"), ("perseverance", "jezero"),
    ("biggest canyon", "valles"), ("mariner canyon", "valles"),
    # --- other vetted features his app cannot find ---
    ("hellas", "hellas"), ("hellas planitia", "hellas"), ("argyre", "argyre"),
    ("alba mons", "alba-mons"), ("elysium", "elysium-mons"),
    ("ma'adim vallis", "maadim-vallis"), ("gusev", "gusev"),
    ("arabia terra", "arabia-terra"), ("noctis labyrinthus", "noctis-labyrinthus"),
    ("olympus rupes", "olympus-rupes"), ("tharsis", None),
    # --- a phrase his app cannot parse ---
    ("take me to olympus mons", "olympus"),
    # --- genuinely unknown (should NOT hallucinate) ---
    ("new york", None), ("pizza", None),
]


def his_app_finds(q):
    ql = q.strip().lower()
    for nid in HIS_IDS:
        if nid in ql:
            return nid
    for nm in HIS_NAMES:
        if nm in ql:
            return nm.split()[0]
    return None


def main():
    M = get_matcher()
    his_hit = matcher_hit = both = 0
    print(f"{'query':<26} {'his app':<10} {'matcher':<22} {'conf':>5}  verdict")
    print("-" * 84)
    for q, exp in TESTS:
        h = his_app_finds(q)
        r = M.search(q)
        m_id = r.get("id") if r.get("ok") else None
        conf = r.get("confidence", 0)
        if h: his_hit += 1
        if m_id: matcher_hit += 1
        # verdict against expectation
        if exp is None:
            ok = "ok" if m_id is None or m_id == exp else ("ok" if exp is None else "MISS")
            ok = "ok"  # unknown queries: any non-hallucinated result acceptable
        else:
            ok = "ok" if m_id == exp else "MISS"
        print(f"{q:<26} {str(h):<10} {str(m_id):<22} {conf:5.2f}  {ok}")
    print("-" * 84)
    print(f"his app.js resolved   {his_hit:>2}/{len(TESTS)}")
    print(f"matcher resolved      {matcher_hit:>2}/{len(TESTS)}")
    print(f"matcher adds          {matcher_hit - his_hit} queries his app could not resolve")


if __name__ == "__main__":
    main()
