"""Build the Mars place database for the marswalk search matcher.

Sources (all coordinates vetted, nothing invented):
  1. The five places hardcoded in his marswalk_frontend/app.js (his exact lat/lon).
  2. The IAU/USGS-sourced Mars gazetteer already extracted in this project
     (data/gazetteer.json — 102 features + 13 mission sites), which itself
     mirrors the coordinates embedded in his earlier NAM atlas.

Output: ../data/mars_places.json
"""
import json, os, re

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
GAZ = "/home/z/my-project/download/mars3d/data/gazetteer.json"

# His five places — copied verbatim from his app.js `places` object.
# These take precedence: his app flies to these exact coordinates.
HIS_PLACES = [
    {"id": "gale",       "name": "Gale Crater",        "lat": -5.4,  "lon": 137.8,  "type": "impact crater",   "detail": "Curiosity exploration region",          "source": "marswalk (his app.js)"},
    {"id": "jezero",     "name": "Jezero Crater",      "lat": 18.4,  "lon": 77.7,   "type": "impact crater",   "detail": "Perseverance exploration region",       "source": "marswalk (his app.js)"},
    {"id": "olympus",    "name": "Olympus Mons",       "lat": 18.7,  "lon": -133.8, "type": "shield volcano",  "detail": "Tallest known volcano in the solar system", "source": "marswalk (his app.js)"},
    {"id": "valles",     "name": "Valles Marineris",   "lat": -13.9, "lon": -59.2,  "type": "canyon system",   "detail": "Extensive equatorial canyon system",    "source": "marswalk (his app.js)"},
    {"id": "eberswalde", "name": "Eberswalde Crater",  "lat": -23.9, "lon": 326.8,  "type": "impact crater",   "detail": "Well-preserved ancient delta deposit",  "source": "marswalk (his app.js)"},
]

# Semantic aliases — map free-text descriptions to a place id.
# Grounded in well-known planetary facts (no invented coordinates).
ALIASES = {
    "olympus":    ["tallest volcano", "largest volcano", "biggest volcano", "highest mountain", "highest volcano", "mount olympus", "olympus"],
    "valles":     ["grand canyon of mars", "biggest canyon", "largest canyon", "great canyon", "mariner canyon", "mariner valleys", "valles"],
    "gale":       ["curiosity", "curiosity rover", "gale"],
    "jezero":     ["perseverance", "perseverance rover", "jezero"],
    "eberswalde": ["eberswalde", "ancient delta", "delta crater"],
}

# Feature-type suffixes stripped to produce shorter aliases.
SUFFIXES = ["Crater", "Mons", "Planitia", "Planum", "Vallis", "Vallis Marineris",
            "Tholus", "Patera", "Catena", "Fossae", "Labes", "Sulci", "Rupes",
            "Mensa", "Labyrinthus", "Chaos", "Tessera", "Terra", "Dorsum",
            "Fossa", "Linea", "Macula", "Undae", "Lingula", "Cavi", "Colles"]


def strip_suffix(name: str) -> list:
    out = [name]
    base = name
    for s in sorted(SUFFIXES, key=len, reverse=True):
        if name.endswith(" " + s):
            base = name[: -(len(s) + 1)].strip()
            if base:
                out.append(base)
            break
    return out


def main():
    g = json.load(open(GAZ))
    places = list(HIS_PLACES)
    his_ids = {p["id"] for p in HIS_PLACES}
    his_names = {p["name"].lower() for p in HIS_PLACES}

    def add(entry, src):
        # skip exact duplicates of his places (by name)
        if entry["name"].lower() in his_names:
            return
        entry["source"] = src
        places.append(entry)

    for f in g.get("FEATURES", []):
        add({
            "id": f.get("id") or f["name"].lower().replace(" ", "-"),
            "name": f["name"],
            "lat": float(f["lat"]),
            "lon": float(f["lon"]),
            "type": f.get("type", "feature"),
            "detail": f.get("desc") or f.get("interesting") or f["type"],
        }, "IAU/USGS gazetteer (vetted)")

    for s in g.get("SITES", []):
        add({
            "id": s.get("id") or s["name"].lower().replace(" ", "-"),
            "name": s["name"],
            "lat": float(s["lat"]),
            "lon": float(s["lon"]),
            "type": s.get("kind", "mission site"),
            "detail": s.get("desc") or s.get("status", "mission site"),
        }, "mission site (vetted)")

    # attach aliases
    by_id = {p["id"]: p for p in places}
    for pid, aliases in ALIASES.items():
        if pid in by_id:
            by_id[pid].setdefault("aliases", []).extend(aliases)

    # attach short-name aliases for every place
    for p in places:
        shorts = strip_suffix(p["name"])
        p.setdefault("aliases", [])
        for s in shorts:
            if s.lower() not in [a.lower() for a in p["aliases"]] and s.lower() != p["name"].lower():
                p["aliases"].append(s)
        # also a cleaned name without parentheticals, e.g.
        # "Alba Mons (Alba Patera)" -> "Alba Mons"
        cleaned = re.sub(r"\s*\([^)]*\)\s*", "", p["name"]).strip()
        if cleaned and cleaned.lower() != p["name"].lower() and cleaned.lower() not in [a.lower() for a in p["aliases"]]:
            p["aliases"].append(cleaned)
            for s in strip_suffix(cleaned):
                if s.lower() not in [a.lower() for a in p["aliases"]] and s.lower() != cleaned.lower():
                    p["aliases"].append(s)

    out = os.path.join(ROOT, "data", "mars_places.json")
    with open(out, "w") as fh:
        json.dump(places, fh, indent=2)
    print(f"wrote {out}: {len(places)} places")
    types = {}
    for p in places:
        types[p["type"]] = types.get(p["type"], 0) + 1
    print("types:", sorted(types.items(), key=lambda x: -x[1])[:8])
    # sanity: a few lookups
    for n in ["Olympus Mons", "Hellas Planitia", "Gale Crater", "Jezero Crater"]:
        m = next((p for p in places if p["name"].lower() == n.lower()), None)
        print(f"  {n}: {m['lat'], m['lon'] if m else 'MISSING'}" if m else f"  {n}: MISSING")


if __name__ == "__main__":
    main()
