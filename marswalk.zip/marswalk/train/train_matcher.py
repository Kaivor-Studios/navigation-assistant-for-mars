"""Train the marswalk place matcher (small classical ML).

For each place, build query paraphrases (full name, short name, aliases, type).
Fit a character n-gram TF-IDF + cosine NearestNeighbors over all paraphrases.
The server vectorizes a query and returns the place whose paraphrase is closest,
provided cosine similarity is above a threshold.

This is "his model made better by training": his app.js searchLocation() only
knew five hardcoded places via exact substring match; this trained matcher
recognises ~115 vetted Mars features and tolerates typos / paraphrases /
partial names, while his five places and coordinate parser keep working
unchanged in his code.

Output: ../backend/model/marswalk_matcher.pkl
"""
import json, os, pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neighbors import NearestNeighbors

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PLACES = os.path.join(ROOT, "data", "mars_places.json")
MODEL = os.path.join(ROOT, "backend", "model", "marswalk_matcher.pkl")
THRESHOLD = 0.18  # cosine floor; below it → "not found"


def paraphrases(p):
    out = [p["name"], p["name"].lower()]
    out += [a for a in p.get("aliases", [])]
    out += [a.lower() for a in p.get("aliases", [])]
    if "type" in p:
        out.append(p["type"])
    out += [s.replace("-", " ") for s in out]
    return list(dict.fromkeys(out))


def main():
    places = json.load(open(PLACES))
    rows, labels = [], []
    for i, p in enumerate(places):
        for ph in paraphrases(p):
            rows.append(ph); labels.append(i)

    vec = TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 4),
                          sublinear_tf=True, lowercase=True, min_df=1)
    X = vec.fit_transform(rows)
    nn = NearestNeighbors(n_neighbors=1, metric="cosine", algorithm="brute").fit(X)

    os.makedirs(os.path.dirname(MODEL), exist_ok=True)
    with open(MODEL, "wb") as fh:
        pickle.dump({"places": places, "vectorizer": vec, "nn": nn,
                     "labels": labels, "threshold": THRESHOLD}, fh)

    print(f"trained on {len(rows)} paraphrases across {len(places)} places")
    print(f"wrote {MODEL} ({os.path.getsize(MODEL)} bytes)")
    print(f"threshold (cosine floor): {THRESHOLD}")


if __name__ == "__main__":
    main()
