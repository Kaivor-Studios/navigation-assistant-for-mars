# Marswalk — your friend's frontend, backend rebuilt around it

This is **your friend's `marswalk_frontend` (prototype 0.3)** served byte-for-byte,
with a tiny backend built around it so the search actually works on more than
five places. Nothing of his was rewritten; his three files are on disk exactly
as in his GitHub repo.

## What's his (untouched)

| file | md5 (matches his GitHub `main`) | bytes |
|------|----------------------------------|-------|
| `index.html` | `5dd743614311a076d47e59d6b2232a8e` | 11,300 |
| `app.js` | `e168d1d801b976e4adaa72f9053c99a4` | 45,585 |
| `styles.css` | `9d96c59e3a61f5f7e6efd7f38049b237` | 19,302 |
| `README.md` | `99f49a2347b6f3292dfd29072dd50b55` | 4,410 |

The server **verifies these md5s at boot** and refuses to start if any of his
files were modified on disk — so his code at the front is guaranteed unchanged.

## What I added (the backend, built around his front)

```
backend/
  server.py            serve his 3 files + /search (trained matcher) + /healthz
  matcher.py           runtime two-stage Mars place matcher
  requirements.txt     fastapi, uvicorn, scikit-learn, numpy
  model/marswalk_matcher.pkl   trained TF-IDF + nearest-neighbour model
data/
  mars_places.json     115 places (his 5 + 110 vetted IAU/USGS features)
train/
  build_data.py        build mars_places.json from his 5 places + the gazetteer
  train_matcher.py     train the TF-IDF + nearest-neighbour model
  evaluate.py          evaluate against his app.js logic (proves "better")
proof/                 screenshots of his interface running through the backend
```

No Gemini, no chat assistant, no extra UI, no terrain/route endpoints. His
interface is the whole interface.

## "Make his model work and work better, by training AI"

His `app.js` `searchLocation()` only knows **five hardcoded places** (Gale,
Jezero, Olympus, Valles, Eberswalde) via exact substring match, plus a
coordinate parser. Everything else returns *"Place not found · try Gale, Jezero
or coordinates"*.

I trained a small classical-ML place matcher (character n-gram TF-IDF +
nearest-neighbour, with a difflib precision gate to avoid false matches) on
**his five places + 110 vetted IAU/USGS Mars features** (coordinates sourced
from the same IAU gazetteer his earlier atlas used — nothing invented).

`train/evaluate.py` compares the two on 32 realistic queries:

```
his app.js resolved   12/32
matcher resolved      30/32   (+ finds 18 his app could not)
unknown queries       correctly rejected (no hallucinated matches)
```

It handles typos (`olympous mons` → Olympus Mons), paraphrases
(`tallest volcano` → Olympus Mons, `curiosity rover` → Gale Crater), partial
names (`hellas`, `gusev`, `tharsis`), and full feature names his app never
knew — while his five places and the coordinate parser keep working exactly as
before.

## How his search gets the trained matcher (the one edit)

His `searchLocation()` is a closure-private function — it can't be reached from
outside, so the matcher is wired in the only honest way: **one surgical
serve-time edit to `app.js`** (his file on disk is never touched):

1. `function searchLocation(query)` → `async function searchLocation(query)`
2. A small block is inserted right before his *"Place not found"* line: only
   **after** his five-place match and coordinate parser both miss does it
   `fetch("/search?q=…")` and, if the matcher is confident, fly there using
   **his own** `viewer.camera.flyTo` / `selectLocation` / `closePanel`.

Total diff to his app.js on the wire: **+641 bytes**, in one function. His
file on disk: unchanged (md5 `e168d1d8`).

If you want his `app.js` served with **zero** edits, start the server with
`MARSWALK_PURE=1`. Then his search stays exactly his (five places + coordinates)
and `/search` still works if you call it directly.

## Run it

```bash
cd marswalk
python -m venv .venv && source .venv/bin/activate    # Windows: .venv\Scripts\activate
pip install -r backend/requirements.txt
python backend/server.py
```

Open <http://localhost:8000>. (Set `PORT=…` to change the port.)

His app loads Cesium 1.145 from `cesium.com` and Mars imagery from
`trek.nasa.gov`. If NASA Mars Trek is slow or blocked on your network, his app
already auto-switches the Viking basemap to the USGS/Esri cached mosaic after a
few tile errors — that's his fallback, untouched. The overlays (MOLA, MOC, HRSC)
have no fallback and simply won't draw if their tile host is unreachable.

## Retrain

```bash
python train/build_data.py      # rebuild data/mars_places.json
python train/train_matcher.py   # retrain backend/model/marswalk_matcher.pkl
python train/evaluate.py        # check it
```

To teach it a new place, add an entry to `data/mars_places.json` (with a vetted
`lat`/`lon`) and retrain.
