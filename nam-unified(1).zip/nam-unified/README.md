# NAM Unified — best of all worlds

One FastAPI application integrating the four uploaded packages into a single
system. The **root experience is a new unified minimalist web app** (marswalk's
field-atlas chrome + the MOLA terrain engine + every backend capability wired
to a working UI element), while the flagship **NAM.html stays byte-identical**
(md5-verified at startup) and every backend capability of all three backend
packages remains available under its original contract.

```bash
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
# open http://localhost:8000            -> the unified NAM app (default UI)
# open http://localhost:8000/NAM.html   -> flagship NAM.html (byte-identical)
# open http://localhost:8000/marswalk/  -> marswalk globe (matcher-augmented search)
# open http://localhost:8000/three      -> mars3d Three.js globe (globe layers API)
# open http://localhost:8000/reference-ui -> endpoint reference page
# open http://localhost:8000/docs       -> full OpenAPI/Swagger UI
```

Docker: `docker compose up --build` (port 8000, health-checked).

Optional env vars (all off by default, everything works fully local):
`NAM_GEMINI_API_KEY` / `NAM_LLM_API_URL`+`NAM_LLM_API_KEY` — let the hybrid AI
phrase its grounded answers with a remote LLM (it still reasons locally and
falls back honestly); `MARSWALK_PURE=1` — serve marswalk's app.js with zero
edits (its `/search` endpoint keeps working either way).

## What came from where

| Source package | What it contributes to the unified system | Where it lives now |
|---|---|---|
| **NAM.html** (5.3 MB single file) | The flagship self-contained Cesium globe: embedded MOLA MEGDR elevation + roughness + Viking MDIM boot texture, 102-feature gazetteer, 13 landing sites, 16 spectral targets, 13 instruments, elevation profiles, mission planner, its own 16-tool rule-based assistant | Served **byte-identical** at `/NAM.html` — md5 `77a7f8fe…` checked at every boot |
| **unified frontend** (new) | The default minimalist app at `/`: Cesium globe with a real MOLA heightmap **terrain provider** (relief + vertical exaggeration + camera collision), marswalk's star-skybox/trackpad/layer-fallback recipes, six registered base layers (live Trek tiles, backend-cached OPM proxy tiles, and layers *generated client-side from the embedded MEGDR* — elevation, slope, roughness, hazard), split-screen layer compare, typo-tolerant search, location dossiers (elevation/slope/roughness/pressure/hazard/dose + actions), A* mission routing with presets + KML export, 8-type node placement, measure tool with elevation-profile charts, first-person **Walk View** (Three.js terrain mesh + rover POV library), the 24-tool assistant with SSE streaming and quick actions, live storm alerts + presence over WebSocket, 3D/flat/Columbus/polar projections, sun lighting and graticule | `frontend/unified/` — plain HTML/CSS/JS, no build step |
| **nam-backend** (FastAPI v2) | The REST + WebSocket backbone: `/api/v1/*` catalogs, elevation/slope/hazard, shelters/water/radiation, storm simulation, presence, 3-preset A* routing, missions/nodes CRUD, Walk View feed (7 POV library), the 25-tool deterministic assistant with SSE chat, `/ws/events` + `/ws/presence` | `app/api/routes.py`, `app/core/*`, `app/ws/*` — contract unchanged |
| **mars3d** | The **C++ terrain cruncher** (`libterrain.so` via ctypes, numpy fallback): full-planet Horn slope/roughness/hazard in ~230 ms, terrain-weighted A*, NASA-style landing-site scoring, globe JSON layers; the **hybrid multilingual AI** (trained 9-language intent classifier, tfidf-l1-logreg over 6,172 examples + retrieval grounding + optional remote phrasing); honest dataset registry | `app/intel/*` — exposed verbatim at `/terrain/sample`, `/terrain/tile`, `/route/plan`, `/landing/score`, `/globe/heightmap`, `/globe/layers`, `/datasets`, `/metrics`, `/ai/ask`, `/ai/status`, `/healthz` |
| **marswalk** | The **trained place matcher**: char-ngram TF-IDF + cosine NN over 115 curated places with semantic aliases, two-stage search with a 0.55 difflib precision gate that **refuses to hallucinate**; its own globe UI (Cesium + Mars Trek tiles) with serve-time md5-verified patching | `app/match/*` — served at `/search` and `/api/v1/search`; UI at `/marswalk/` |

## Integrations that only exist because these are now one system

1. **ML-first assistant routing.** The nam-backend assistant (regex intents)
   now falls through to the mars3d trained classifier when the regex misses —
   so `带我去奥林匹斯山` (Chinese), `tallest volcano` (paraphrase) and other
   non-English/odd phrasings route to real tool calls. A confidence gate
   (0.55) keeps it conservative; the regex path still wins first, so the
   original deterministic behaviour is unchanged.
2. **Multilingual alias bridge.** The model's 9-language feature aliases
   (`entities.feature_aliases`: 奥林匹斯山, 海拉斯, Monte Olimpo, Олимп…) map
   non-English mentions to canonical names, which the marswalk matcher then
   resolves to coordinates — typos and all.
3. **Matcher-integrated tooling.** The assistant's feature lookup and the
   `/search` endpoint share the trained matcher; `/search` additionally
   enriches hits with MOLA elevation + pressure and normalizes longitude to
   the platform-canonical east-positive form (plus `lon_180`).
4. **Storm alerts actually broadcast.** The original nam-backend had
   `publish_storm_alert()` but nothing called it; now
   `POST /api/v1/env/storms/simulate` pushes `storm.alert` to every
   `/ws/events` client (tested).
5. **CORS spec fix.** `allow_credentials=False` with the wildcard origin, so
   browsers honour `Access-Control-Allow-Origin: *` (the v2 combination was
   invalid per spec).
6. **One merged health surface.** `/health` reports every component's status;
   `/healthz` keeps the mars3d shape; `/metrics` now also reports the matcher.
7. **Adaptive global A\* routing.** The v1 planner failed beyond ~200 km
   (fixed 6000-step budget on the 4 ppd grid). It now picks a grid stride
   from the straight-line distance (1×/2×/4×/8×) — regional routes keep full
   0.25° fidelity, and globe-spanning traverses (Jezero → Olympus Mons,
   8,300 km) plan in ~200 ms with the same cost function and honest
   provenance about the effective cell size.
8. **UI route persistence.** `POST /api/v1/plans/{id}/route` stores a
   computed route (waypoints/stats/preset) on a mission so KML export and
   the assistant see the exact planned path; waypoint/stop changes broadcast
   `mission.plan_changed` on `/ws/events`.
9. **Assistant intent training.** The deterministic router learned the eight
   flagship phrases: landing-site listing (returns the 13-site catalogue to
   the UI), Jezero-vs-Gale comparison, highest-mountain ranking (sampled
   live from the MOLA grid), Perseverance/Curiosity traverse context
   (labelled documented, not live telemetry), and ancient-water regions
   (find_water at the Nili Fossae analogue region). All 10/10 quick chips
   route to tool calls, flights, or grounded catalog answers.
10. **Frontend ellipsoid correctness.** The UI converts camera positions via
    the Mars ellipsoid manually — Cesium's `positionCartographic` silently
    uses WGS84, which on Mars puts the "camera height" ~2,600 km underground.

## Honesty rules (inherited and enforced)

- Every dataset response carries provenance; simulated values are labelled
  `[SIM]` / `simulated: true`.
- The matcher refuses guesses below its precision gate (`pizza` →
  `{"ok": false, "reason": "below precision gate"}`).
- The hybrid AI answers only from the embedded catalog; the remote LLM (if
  configured) is fed exactly the retrieved facts and any failure falls back
  to the local answer with `fallback: true` and `remote_error` set.
- NAM.html degrades gracefully offline: no internet → embedded NASA data and
  a visible "tile services unreachable" badge; nothing is faked.

## Verification

```bash
python -m pytest tests/ -q     # 50 tests: contracts, byte-identity, engines,
                               # matcher, ML routing, WS storm broadcast, the
                               # 8 flagship assistant phrases, global A*
                               # routing, mission-route persistence + KML
```

Key verified behaviours: NAM.html served at `/NAM.html` has md5
`77a7f8febad5d2287be79b4ad876cf1d` (identical to the upload); the cruncher
loads as `nam-terrain-1.0 g++-O3`; Olympus Mons samples ≈ +19–21 km; the
matcher returns Olympus for `olympous mons` (0.96) and rejects `pizza`;
`POST /route/plan` returns a C++ A* polyline; the SSE chat streams
`role → tokens → tool_call → tool_result → done` events; a simulated storm
reaches `/ws/events` as `storm.alert` within ~1 s; global routes plan
(Jezero → Olympus ≈ 8,300 km) in ~0.25 s. The frontend was additionally
click-tested live in a headless browser: boot, search, dossier, layers +
overlays, split compare, assistant streaming + fly-to, walk view with POV
lookup, measure + profile charts, mission create → waypoints → A* route →
KML export, storm simulation → WebSocket toast — with a clean console.

## Known limitations (inherited, stated plainly)

- The trained model's multilingual coverage varies: English and Chinese are
  strong; some phrasings in other languages classify at lower confidence and
  fall back to the deterministic help text (never a wrong answer).
- The marswalk matcher's place set is 115 curated entries — it is a precision
  tool, not the full IAU gazetteer; the 102-feature gazetteer search remains
  available at `/api/v1/gazetteer`.
- MOLA sampling is 4 px/deg (~15 km cells): Walk View "25 m resolution"
  terrain patches are honest bilinear interpolations, flagged in the payload.
- Node/mission state is in-memory (restart clears it) — same as the source
  packages; nothing was silently changed to pretend otherwise.
- Two of the six registered layers have no upstream URL (embedded/generated
  layers), so the tile proxy honestly 503s for those ids; the 3 OPM layers
  proxy and cache fine.
