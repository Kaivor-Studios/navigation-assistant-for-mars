/* NAM unified — single minimalist front-end assembled from the best of all
   four packages:
     · globe recipe + trackpad fix + fallback logic  → marswalk
     · MOLA terrain engine + generated rasters       → mars3d (/globe/*)
     · offline layers/search/walk/assistant data     → nam-backend (/api/v1/*)
   All live data carries credit; all simulated values are labelled. */

(() => {
  "use strict";

  // ------------------------------------------------------------------ const
  const MARS_A = 3396190, MARS_B = 3376200;
  const API = "/api/v1";
  const $ = (id) => document.getElementById(id);
  const TREK = "https://trek.nasa.gov/tiles/Mars/EQ";

  // Mars Trek WMTS products (equirectangular service, same grid as marswalk)
  const TREK_LAYERS = {
    viking: { id: "viking", name: "Viking MDIM 2.1 colour mosaic", tileId: "Mars_Viking_MDIM21_ClrMosaic_global_232m",
      maxLevel: 7, format: "jpg", credit: "NASA / JPL / USGS",
      fallbackUrl: "https://tiles.arcgis.com/tiles/lqRTrQp2HrfnJt8U/arcgis/rest/services/mars_viking_mosaic/MapServer/tile/{z}/{y}/{x}",
      fallbackCredit: "NASA / JPL / USGS · Esri cache" },
    mola: { id: "mola", name: "MOLA colour hillshade (Trek)", tileId: "Mars_MGS_MOLA_ClrShade_merge_global_463m",
      maxLevel: 8, format: "jpg", credit: "NASA / JPL · MGS MOLA" },
  };
  const NODE_COLORS = {
    waypoint: "#4da3ff", cache: "#ffb02e", shelter: "#3fd68f", water: "#3ec9dc",
    hazard: "#ff5d5d", poi: "#c792ea", person: "#ffd54f", area: "#9aa7b6",
  };

  let C = null, MARS = null, viewer = null, terrainData = null, rasterData = null;
  let baseLayer = null, baseLayerId = null, usingFallback = false, baseTileErrors = 0;
  const overlays = new Map();          // id -> {imagery, def}
  const entitySets = new Map();        // id -> C.CustomDataSource
  let compareOn = false, compareLayerObj = null;
  let selected = null;                 // {lat, lon}
  let routeStart = null, routeEnd = null;
  let measureMode = false, measurePts = [], measureEntities = [];
  let nodePlaceMode = null;            // current node type when placing
  let currentMission = null;
  let nodeType = "waypoint";
  let heightmapImg = null;             // canvas for generated layers

  // ---------------------------------------------------------------- helpers
  async function jget(url) {
    const r = await fetch(url);
    if (!r.ok) throw new Error(`${url} → ${r.status}`);
    return r.json();
  }
  async function jpost(url, body) {
    const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) });
    if (!r.ok) throw new Error(`${url} → ${r.status}`);
    return r.json();
  }
  function haversineKm(aLat, aLon, bLat, bLon) {
    const R = 3389.5, toR = Math.PI / 180;
    const dLa = (bLat - aLat) * toR, dLo = (bLon - aLon) * toR;
    const a = Math.sin(dLa / 2) ** 2 + Math.cos(aLat * toR) * Math.cos(bLat * toR) * Math.sin(dLo / 2) ** 2;
    return 2 * R * Math.asin(Math.sqrt(a));
  }
  const fLat = (v) => `${Math.abs(v).toFixed(3)}°${v >= 0 ? "N" : "S"}`;
  const fLon = (v) => { const e = ((v % 360) + 360) % 360; const w = e > 180 ? e - 360 : e; return `${Math.abs(w).toFixed(3)}°${w >= 0 ? "E" : "W"}`; };
  function toast(title, body, cls = "", ms = 6500) {
    const t = document.createElement("div");
    t.className = `toast ${cls}`;
    t.innerHTML = `<h4></h4><p></p>`;
    t.querySelector("h4").textContent = title;
    if (body) t.querySelector("p").textContent = body;
    $("toasts").appendChild(t);
    setTimeout(() => t.remove(), ms);
  }
  function connState(cls, label) {
    $("conn-dot").className = `dot ${cls}`;
    $("conn-label").textContent = label;
  }

  // --------------------------------------------------- MOLA terrain provider
  // Builds a real heightmap terrain provider from the embedded MOLA MEGDR
  // grid served by /globe/heightmap (360×180, 1°/cell). Gives the globe true
  // relief, vertical exaggeration and terrain-aware camera collision.
  function sampleGrid(g, lonDeg, latDeg) {
    const w = g.w, h = g.h;
    const col = (lonDeg + 180) / 360 * w - 0.5;
    const row = (90 - latDeg) / 180 * h - 0.5;
    const x0 = Math.floor(col), y0 = Math.floor(row);
    const fx = col - x0, fy = row - y0;
    const at = (x, y) => {
      const xi = ((x % w) + w) % w;
      const yi = Math.min(h - 1, Math.max(0, y));
      return g.data[yi * w + xi];
    };
    const v = at(x0, y0) * (1 - fx) * (1 - fy) + at(x0 + 1, y0) * fx * (1 - fy)
            + at(x0, y0 + 1) * (1 - fx) * fy + at(x0 + 1, y0 + 1) * fx * fy;
    return v;
  }

  function buildMarsTerrain() {
    const g = terrainData;
    const tiling = new C.GeographicTilingScheme({ ellipsoid: MARS });
    const MAX_LEVEL = 6, SIZE = 65;
    // Level-0 geometric error (Cesium formula); static helper moved in newer
    // Cesium releases, so compute it ourselves with a runtime fallback.
    const L0_ERR = MARS.maximumRadius * 2 * Math.PI * 0.25 / SIZE;
    const provider = {
      tilingScheme: tiling,
      ready: true,
      readyPromise: Promise.resolve(true),
      errorEvent: new C.Event(),
      credit: new C.Credit("MOLA MEGDR (upsampled) · NASA PDS"),
      hasWaterMask: false,
      requestTileGeometry(x, y, level) {
        const rect = tiling.tileXYToRectangle(x, y, level);
        const west = C.Math.toDegrees(rect.west), east = C.Math.toDegrees(rect.east);
        const north = C.Math.toDegrees(rect.north), south = C.Math.toDegrees(rect.south);
        const buf = new Float32Array(SIZE * SIZE);
        for (let j = 0; j < SIZE; j++) {
          const lat = north - (j / (SIZE - 1)) * (north - south);
          for (let i = 0; i < SIZE; i++) {
            const lon = west + (i / (SIZE - 1)) * (east - west);
            buf[j * SIZE + i] = sampleGrid(g, lon, lat);
          }
        }
        return Promise.resolve(new C.HeightmapTerrainData({
          buffer: buf, width: SIZE, height: SIZE,
          childTileMask: level >= MAX_LEVEL ? 0 : 15,
          structure: { heightScale: 1.0, heightOffset: 0.0, elementsPerHeight: 1, stride: 1, elementMultiplier: 1.0, isBigEndian: false },
        }));
      },
      getLevelMaximumGeometricError(level) {
        if (C.TerrainProvider && typeof C.TerrainProvider.getLevelMaximumGeometricError === "function") {
          return C.TerrainProvider.getLevelMaximumGeometricError(level);
        }
        return L0_ERR / (1 << level);
      },
      getTileDataAvailable(x, y, level) { return level <= MAX_LEVEL; },
      hasTileAvailability() { return false; },
    };
    return provider;
  }

  // -------------------------------------------------- generated raster layers
  // MOLA elevation / slope / roughness / hazard — painted client-side from
  // the mars3d engine outputs (/globe/heightmap, /globe/layers) into a single
  // equirectangular image. Works fully offline.
  function lerpColor(stops, t) {
    t = Math.min(1, Math.max(0, t));
    for (let i = 1; i < stops.length; i++) {
      if (t <= stops[i][0]) {
        const [t0, c0] = stops[i - 1], [t1, c1] = stops[i];
        const k = (t - t0) / Math.max(1e-6, t1 - t0);
        return [c0[0] + (c1[0] - c0[0]) * k, c0[1] + (c1[1] - c0[1]) * k, c0[2] + (c1[2] - c0[2]) * k,
                c0[3] + (c1[3] - c0[3]) * k];
      }
    }
    const c = stops[stops.length - 1][1]; return c;
  }
  const ELEV_STOPS = [
    [0.00, [24, 12, 60, 255]],     // deepest basins (Hellas floor)
    [0.10, [40, 60, 150, 255]],    // low basins
    [0.18, [70, 130, 180, 255]],   // low plains
    [0.26, [130, 160, 140, 255]],  // transitional plains
    [0.32, [190, 168, 120, 255]],  // sand highlands
    [0.42, [205, 150, 95, 255]],   // tan
    [0.55, [190, 110, 60, 255]],   // rust
    [0.72, [170, 70, 45, 255]],    // red-brown
    [0.88, [225, 215, 205, 255]],  // pale high plateau
    [1.00, [250, 248, 244, 255]],  // summit white
  ];
  function paintRaster(canvas, w, h, colorFn) {
    const ctx = canvas.getContext("2d");
    const img = ctx.createImageData(w, h);
    const d = img.data;
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const i = y * w + x;
        const rgba = colorFn(rasterData, x, y, i);
        d[i * 4] = rgba[0]; d[i * 4 + 1] = rgba[1]; d[i * 4 + 2] = rgba[2]; d[i * 4 + 3] = rgba[3];
      }
    }
    ctx.putImageData(img, 0, 0);
    return canvas;
  }
  function rasterColorizer(kind) {
    const { w, h } = rasterData;
    if (kind === "elev") {
      return (_g, _x, y, i) => {
        const t = (rasterData.elev[i] - rasterData.minE) / (rasterData.maxE - rasterData.minE);
        return lerpColor(ELEV_STOPS, t);
      };
    }
    if (kind === "slope") {
      return (_g, _x, y, i) => {
        const s = rasterData.slope[i];
        const a = Math.min(235, 30 + s * 26);
        return [255, 130 + Math.min(120, s * 8), 40, a];
      };
    }
    if (kind === "rough") {
      return (_g, _x, y, i) => {
        const r = rasterData.rough[i];
        const a = Math.min(225, 20 + r * 34);
        return [255, 210 - Math.min(150, r * 9), 60, a];
      };
    }
    return (_g, _x, y, i) => { // hazard
      const hz = rasterData.hazard[i];
      if (hz < 0.15) return [0, 0, 0, 0];
      const a = Math.min(215, hz * 300);
      return [255, Math.round(220 - hz * 180), 70, a];
    };
  }
  async function buildGeneratedLayers() {
    const [hm, gl] = await Promise.all([jget("/globe/heightmap"), jget("/globe/layers")]);
    const w = hm.w, h = hm.h;
    let minE = Infinity, maxE = -Infinity;
    for (const v of hm.data) { if (v < minE) minE = v; if (v > maxE) maxE = v; }
    rasterData = {
      w, h, minE, maxE,
      elev: hm.data, slope: gl.slope, rough: gl.rough, hazard: gl.hazard,
    };
    const kinds = ["elev", "slope", "rough", "hazard"];
    const canvases = {};
    for (const k of kinds) {
      const cv = document.createElement("canvas");
      cv.width = w; cv.height = h;
      paintRaster(cv, w, h, rasterColorizer(k));
      canvases[k] = cv.toDataURL("image/png");
    }
    heightmapImg = canvases;
    return canvases;
  }

  function singleImageLayer(dataUrl, creditText, alpha = 1) {
    const opts = {
      url: dataUrl,
      rectangle: C.Rectangle.fromDegrees(-180, -90, 180, 90),
      tilingScheme: new C.GeographicTilingScheme({ ellipsoid: MARS }),
      credit: new C.Credit(creditText),
    };
    const layer = new C.SingleTileImageryProvider(opts);
    return layer;
  }

  function trekProvider(def, useFallback = false) {
    const url = useFallback && def.fallbackUrl ? def.fallbackUrl
      : `${TREK}/${def.tileId}/1.0.0/default/default028mm/{z}/{y}/{x}.${def.format}`;
    return new C.UrlTemplateImageryProvider({
      url,
      tilingScheme: new C.GeographicTilingScheme({ ellipsoid: MARS }),
      minimumLevel: 0, maximumLevel: def.maxLevel || 7,
      rectangle: C.Rectangle.fromDegrees(-180, -89.999, 180, 89.999),
      credit: new C.Credit(useFallback ? (def.fallbackCredit || def.credit) : def.credit),
      tileWidth: 256, tileHeight: 256,
    });
  }
  function proxyProvider(def) {
    // Backend cached tile proxy (OpenPlanetaryMap upstream)
    return new C.UrlTemplateImageryProvider({
      url: `${API}/layers/${def.id}/tiles/{z}/{x}/{y}`,
      tilingScheme: new C.GeographicTilingScheme({ ellipsoid: MARS }),
      minimumLevel: 0, maximumLevel: 7,
      rectangle: C.Rectangle.fromDegrees(-180, -89.999, 180, 89.999),
      credit: new C.Credit(def.credit || "OpenPlanetaryMap"),
      tileWidth: 256, tileHeight: 256,
    });
  }

  // ------------------------------------------------------------ layer defs
  let LAYER_REGISTRY = [];  // from /api/v1/layers
  const BASE_DEFS = [
    { id: "viking",        name: "Viking MDIM 2.1 colour mosaic", src: "live",  credit: "NASA / JPL / USGS", make: () => trekProvider(TREK_LAYERS.viking, usingFallback) },
    { id: "mola-color",    name: "MOLA colour hillshade (Trek)",  src: "live",  credit: "NASA / JPL · MGS MOLA", make: () => trekProvider(TREK_LAYERS.mola) },
    { id: "opm-basemap",   name: "OPM Mars basemap v0.2",         src: "proxy", credit: "OpenPlanetaryMap / CARTO", make: (def) => proxyProvider(def) },
    { id: "opm-mola-color",name: "OPM shaded colour MOLA",        src: "proxy", credit: "OpenPlanetaryMap / CARTO · NASA MGS", make: (def) => proxyProvider(def) },
    { id: "opm-hillshade", name: "OPM Mars hillshade (MOLA)",     src: "proxy", credit: "OpenPlanetaryMap / CARTO · NASA MGS", make: (def) => proxyProvider(def) },
    { id: "mola-color-gen",name: "MOLA elevation (generated)",    src: "gen",   credit: "Generated from MOLA MEGDR 4 ppd · NASA PDS", make: () => singleImageLayer(heightmapImg.elev, "Generated from MOLA MEGDR · NASA PDS") },
  ];
  const OVERLAY_DEFS = [
    { id: "mola-roughness", name: "MOLA footprint roughness", src: "gen",   credit: "MOLA roughness · Neumann et al. 2003", make: () => singleImageLayer(heightmapImg.rough, "MOLA roughness · NASA PDS", 0.7), alpha: 0.7 },
    { id: "terrain-hazard", name: "Terrain hazard (engine)",  src: "gen",   credit: "mars3d cruncher hazard from MOLA", make: () => singleImageLayer(heightmapImg.hazard, "NAM terrain engine"), alpha: 0.6 },
    { id: "slope-map",      name: "Regional slope map",       src: "gen",   credit: "Derived from MOLA MEGDR", make: () => singleImageLayer(heightmapImg.slope, "Derived from MOLA MEGDR"), alpha: 0.5 },
  ];
  const ENTITY_OVERLAYS = ["sites", "targets", "water", "shelters", "presence", "storms", "nodes", "grid"];

  function makeProviderFor(def) {
    if (def.make) return def.make(def);
    // registry-driven (proxy) layers not in BASE_DEFS
    return proxyProvider(def);
  }
  function findDef(id) {
    return BASE_DEFS.find(d => d.id === id)
        || OVERLAY_DEFS.find(d => d.id === id)
        || LAYER_REGISTRY.find(d => d.id === id);
  }
  function setBaseLayer(id) {
    const def = findDef(id);
    if (!def || !viewer || !heightmapImg) return;
    if (baseLayer) viewer.imageryLayers.remove(baseLayer, true);
    const provider = makeProviderFor(def);
    baseLayer = viewer.imageryLayers.addImageryProvider(provider, 0);
    baseLayerId = id;
    if (compareOn && compareLayerObj) {
      baseLayer.splitDirection = C.SplitDirection.LEFT;
      compareLayerObj.imagery.splitDirection = C.SplitDirection.RIGHT;
    }
    $("credit").textContent = def.name + " · " + def.credit;
    renderLayerPanel();
    attachProviderErrors(provider, def);
    probeTile(def);
  }
  function attachProviderErrors(provider, def) {
    provider.errorEvent.addEventListener((err) => {
      baseTileErrors++;
      console.warn("tile error:", def.id, err && err.message);
      if (baseTileErrors >= 4 && !usingFallback && def.id === "viking") {
        baseTileErrors = 0; usingFallback = true;
        setBaseLayer("viking");
        connState("live", "Viking mosaic · Esri cache fallback");
        toast("Basemap fallback", "Primary NASA tile service failing — switched to the Esri-cached Viking mosaic.");
      } else if (baseTileErrors >= 4) {
        connState("error", "Some base tiles failed — see layers panel");
      }
    });
  }
  function probeTile(def) {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => { connState("live", "Imagery connected"); };
    img.onerror = () => { connState("error", "Base imagery did not respond"); };
    let probeUrl;
    if (def.make && def.src === "gen") probeUrl = heightmapImg.elev;
    else if (def.src === "proxy") probeUrl = `${API}/layers/${def.id}/tiles/0/0/0`;
    else probeUrl = `${TREK}/${def.tileId}/1.0.0/default/default028mm/0/0/0.${def.format}`;
    img.src = probeUrl;
  }
  function addOverlay(id) {
    const def = findDef(id);
    if (!def || overlays.has(id) || !viewer || !heightmapImg) return;
    let imagery;
    if (ENTITY_OVERLAYS.includes(id)) { setEntityOverlay(id, true); return; }
    imagery = viewer.imageryLayers.addImageryProvider(makeProviderFor(def));
    imagery.alpha = def.alpha || 0.7;
    if (compareOn) imagery.splitDirection = C.SplitDirection.RIGHT;
    overlays.set(id, { imagery, def });
  }
  function removeOverlay(id) {
    if (ENTITY_OVERLAYS.includes(id)) { setEntityOverlay(id, false); return; }
    const o = overlays.get(id);
    if (!o) return;
    viewer.imageryLayers.remove(o.imagery, true);
    overlays.delete(id);
  }
  function setOverlayAlpha(id, a) {
    const o = overlays.get(id); if (o) o.imagery.alpha = a;
  }

  // ------------------------------------------------------ entity data sources
  function getDS(id) {
    if (!entitySets.has(id)) entitySets.set(id, new C.CustomDataSource(id));
    return entitySets.get(id);
  }
  function showDS(id, on) {
    const ds = getDS(id);
    if (!viewer.dataSources.contains(ds)) viewer.dataSources.add(ds);
    ds.show = on;
  }
  function pinColor(kind) { return C.Color.fromCssColorString(NODE_COLORS[kind] || "#ff6a2b"); }

  async function loadEntitySet(id) {
    const ds = getDS(id);
    ds.entities.removeAll();
    if (id === "sites") {
      const { sites } = await jget(`${API}/missions/sites`);
      for (const s of sites) {
        ds.entities.add({
          position: C.Cartesian3.fromDegrees(s.lon, s.lat, 2000, MARS),
          point: { pixelSize: 11, color: pinColor("shelter"), outlineColor: C.Color.WHITE, outlineWidth: 1.5 },
          label: { text: s.name, font: "12px 'Segoe UI'", fillColor: C.Color.WHITE, outlineColor: C.Color.BLACK, outlineWidth: 2, pixelOffset: new C.Cartesian2(0, -16), distanceDisplayCondition: new C.DistanceDisplayCondition(0, 9e6), disableDepthTestDistance: Number.POSITIVE_INFINITY },
          properties: { kind: "site", data: s },
        });
      }
    } else if (id === "targets") {
      const { targets } = await jget(`${API}/targets`);
      for (const t of targets) {
        ds.entities.add({
          position: C.Cartesian3.fromDegrees(t.lon, t.lat, 2000, MARS),
          point: { pixelSize: 9, color: C.Color.fromCssColorString("#c792ea"), outlineColor: C.Color.WHITE, outlineWidth: 1 },
          label: { text: t.name.split(/ (Fe|Mg|Opaline|Chloride|Hydrated)/)[0], font: "11px 'Segoe UI'", fillColor: C.Color.fromCssColorString("#d9c9f2"), outlineColor: C.Color.BLACK, outlineWidth: 2, pixelOffset: new C.Cartesian2(0, -14), distanceDisplayCondition: new C.DistanceDisplayCondition(0, 6e6), disableDepthTestDistance: Number.POSITIVE_INFINITY },
          properties: { kind: "target", data: t },
        });
      }
    } else if (id === "nodes") {
      const { nodes } = await jget(`${API}/nodes`);
      for (const n of nodes) {
        ds.entities.add({
          position: C.Cartesian3.fromDegrees(n.lon, n.lat, 1500, MARS),
          point: { pixelSize: 10, color: pinColor(n.type), outlineColor: C.Color.BLACK, outlineWidth: 1 },
          label: { text: n.name, font: "11px 'Segoe UI'", fillColor: C.Color.WHITE, outlineColor: C.Color.BLACK, outlineWidth: 2, pixelOffset: new C.Cartesian2(0, -14), distanceDisplayCondition: new C.DistanceDisplayCondition(0, 5e6), disableDepthTestDistance: Number.POSITIVE_INFINITY },
          properties: { kind: "node", data: n },
        });
      }
    } else if (id === "water" || id === "shelters") {
      const c = selected || viewCenter();
      const r = await jget(`${API}/${id}?lat=${c.lat}&lon=${c.lon}&max_radius_km=2500&limit=25`);
      const arr = r.candidates || r.shelters || r.water || [];
      for (const w of arr) {
        const col = id === "water" ? "#3ec9dc" : "#3fd68f";
        ds.entities.add({
          position: C.Cartesian3.fromDegrees(w.lon, w.lat, 1500, MARS),
          point: { pixelSize: 10, color: C.Color.fromCssColorString(col), outlineColor: C.Color.BLACK, outlineWidth: 1 },
          label: { text: w.name || w.id || id, font: "11px 'Segoe UI'", fillColor: C.Color.WHITE, outlineColor: C.Color.BLACK, outlineWidth: 2, pixelOffset: new C.Cartesian2(0, -14), distanceDisplayCondition: new C.DistanceDisplayCondition(0, 4e6), disableDepthTestDistance: Number.POSITIVE_INFINITY },
          properties: { kind: id, data: w },
        });
      }
    } else if (id === "presence") {
      const { agents } = await jget(`${API}/presence`);
      for (const a of agents) {
        const col = a.kind === "habitat" ? "#3fd68f" : a.kind === "rover" ? "#ffb02e" : "#ffd54f";
        ds.entities.add({
          position: C.Cartesian3.fromDegrees(a.lon, a.lat, 1500, MARS),
          point: { pixelSize: 12, color: C.Color.fromCssColorString(col), outlineColor: C.Color.BLACK, outlineWidth: 1.5 },
          label: { text: a.name, font: "11px 'Segoe UI'", fillColor: C.Color.WHITE, outlineColor: C.Color.BLACK, outlineWidth: 2, pixelOffset: new C.Cartesian2(0, -16), disableDepthTestDistance: Number.POSITIVE_INFINITY },
          properties: { kind: "presence", data: a },
        });
      }
    } else if (id === "storms") {
      const { events } = await jget(`${API}/env/storms`);
      for (const e of events) {
        if (!e.footprint || !e.footprint.length) continue;
        const coords = e.footprint.map(p => p.lon).length
          ? e.footprint.map(p => C.Cartesian3.fromDegrees(p.lon, p.lat, 0, MARS)) : [];
        if (!coords.length) continue;
        ds.entities.add({
          polyline: { positions: coords, width: 2, material: new C.PolylineDashMaterialProperty({ color: C.Color.fromCssColorString("#ff5d5d") }), clampToGround: true },
          properties: { kind: "storm", data: e },
        });
      }
    }
    showDS(id, true);
  }
  function setEntityOverlay(id, on) {
    if (on) loadEntitySet(id).catch(e => console.warn("overlay load failed", id, e));
    else { const ds = getDS(id); ds.show = false; }
  }
  function refreshEntitySet(id) {
    if (overlays.has(id)) loadEntitySet(id).catch(() => {});
  }

  // -------------------------------------------------------------- viewer
  function createStarSkyBox() {
    // Local six-face star cube (marswalk recipe — no external assets needed).
    const size = 512, faces = {};
    ["positiveX", "negativeX", "positiveY", "negativeY", "positiveZ", "negativeZ"].forEach(n => faces[n] = document.createElement("canvas"));
    const ctxs = {};
    for (const [n, cv] of Object.entries(faces)) { cv.width = cv.height = size; const x = cv.getContext("2d"); x.fillStyle = "#03070b"; x.fillRect(0, 0, size, size); ctxs[n] = x; }
    let seed = 739102 >>> 0;
    const rand = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
    for (let i = 0; i < 5200; i++) {
      const z = rand() * 2 - 1, th = rand() * Math.PI * 2, rr = Math.sqrt(1 - z * z);
      const x = rr * Math.cos(th), y = rr * Math.sin(th);
      const ax = Math.abs(x), ay = Math.abs(y), az = Math.abs(z);
      let f, u, v, dom;
      if (ax >= ay && ax >= az) { dom = ax; if (x > 0) { f = "positiveX"; u = -z / dom; v = -y / dom; } else { f = "negativeX"; u = z / dom; v = -y / dom; } }
      else if (ay >= ax && ay >= az) { dom = ay; if (y > 0) { f = "positiveY"; u = x / dom; v = z / dom; } else { f = "negativeY"; u = x / dom; v = -z / dom; } }
      else { dom = az; if (z > 0) { f = "positiveZ"; u = x / dom; v = -y / dom; } else { f = "negativeZ"; u = -x / dom; v = -y / dom; } }
      const px = (u + 1) * .5 * size, py = (v + 1) * .5 * size;
      const m = rand(), r = m > .994 ? 1.6 : m > .95 ? 1.05 : .5 + rand() * .4;
      const al = m > .994 ? .95 : m > .95 ? .7 : .2 + rand() * .25;
      ctxs[f].fillStyle = `rgba(235,239,242,${al})`;
      ctxs[f].beginPath(); ctxs[f].arc(px, py, r, 0, Math.PI * 2); ctxs[f].fill();
    }
    const sources = {};
    for (const [n, cv] of Object.entries(faces)) sources[n] = cv.toDataURL("image/png");
    return new C.SkyBox({ sources });
  }

  function flyTo(lat, lon, height = 400000, duration = 1.8) {
    viewer.camera.flyTo({
      destination: C.Cartesian3.fromDegrees(lon, lat, height, MARS),
      orientation: { heading: 0, pitch: C.Math.toRadians(-55), roll: 0 },
      duration,
    });
  }
  function viewCenter() {
    // NB: camera.positionCartographic converts via the default WGS84
    // ellipsoid — wrong on Mars (heights off by ~2600 km). Convert manually.
    const cg = MARS.cartesianToCartographic(viewer.camera.positionWC);
    return { lat: C.Math.toDegrees(cg.latitude),
             lon: ((C.Math.toDegrees(cg.longitude) % 360) + 360) % 360,
             height: cg.height };
  }

  function camHeightM() {
    const cg = MARS.cartesianToCartographic(viewer.camera.positionWC);
    return cg.height;
  }

  function installTrackpadPinchZoom() {
    const canvas = viewer.canvas;
    let queued = 0, raf = false;
    function apply() {
      raf = false;
      if (!viewer || viewer.isDestroyed()) return;
      const dy = queued; queued = 0;
      if (Math.abs(dy) < 0.01) return;
      const cam = viewer.camera;
      const cur = camHeightM();
      const next = C.Math.clamp(cur * Math.exp(dy * 0.0024), 900, 5e7);
      const dist = Math.abs(next - cur);
      if (dist < 0.5) return;
      if (next < cur) cam.zoomIn(dist); else cam.zoomOut(dist);
    }
    window.addEventListener("wheel", (ev) => {
      if (ev.target !== canvas) return;
      if (!ev.ctrlKey && !ev.metaKey) return;
      ev.preventDefault(); ev.stopPropagation(); ev.stopImmediatePropagation();
      const unit = ev.deltaMode === 1 ? 16 : ev.deltaMode === 2 ? window.innerHeight : 1;
      queued += ev.deltaY * unit;
      if (!raf) { raf = true; requestAnimationFrame(apply); }
    }, { capture: true, passive: false });
  }

  function updateReadout() {
    const c = viewCenter();
    $("readout-region").textContent =
      c.height > 4e6 ? "Global view" : c.height > 8e5 ? "Regional view" : c.height > 1.5e5 ? "Local view" : "Close range";
    $("readout-coords").textContent = `${fLat(c.lat)} ${fLon(c.lon)} · ${(c.height / 1000).toFixed(1)} km`;
  }

  function createViewer() {
    MARS = new C.Ellipsoid(MARS_A, MARS_A, MARS_B);
    const terrain = buildMarsTerrain();
    viewer = new C.Viewer("cesiumContainer", {
      animation: false, timeline: false, baseLayerPicker: false, geocoder: false,
      homeButton: false, sceneModePicker: false, navigationHelpButton: false,
      fullscreenButton: false, infoBox: false, selectionIndicator: false,
      shouldAnimate: false, skyBox: false, skyAtmosphere: false, baseLayer: false,
      requestRenderMode: false,
      contextOptions: { webgl: { alpha: false, antialias: true, powerPreference: "high-performance" } },
      globe: new C.Globe(MARS),
      terrainProvider: terrain,
    });
    const scene = viewer.scene;
    scene.logarithmicDepthBuffer = true;
    scene.backgroundColor = C.Color.fromCssColorString("#02060b");
    scene.skyBox = createStarSkyBox();
    scene.skyBox.show = true;
    scene.globe.baseColor = C.Color.fromCssColorString("#9a7b60");
    scene.globe.enableLighting = true;
    scene.globe.showGroundAtmosphere = true;
    scene.globe.depthTestAgainstTerrain = false;
    scene.globe.maximumScreenSpaceError = 2.0;
    scene.skyAtmosphere = new C.SkyAtmosphere(MARS);
    if (scene.sun) scene.sun.show = false;
    if (scene.moon) scene.moon.show = false;
    scene.fog.enabled = false;
    const ctl = scene.screenSpaceCameraController;
    ctl.enableCollisionDetection = true;
    ctl.minimumZoomDistance = 850;
    ctl.maximumZoomDistance = 5e7;
    ctl.zoomFactor = 5.0;
    ctl.inertiaZoom = 0.65; ctl.inertiaSpin = 0.84; ctl.inertiaTranslate = 0.84;
    ctl.maximumMovementRatio = 0.05;
    ctl.maximumTiltAngle = Math.PI / 2;
    setExaggeration(parseFloat($("exag").value));
    viewer.camera.setView({
      destination: C.Cartesian3.fromDegrees(18, 14, 7400000, MARS),
      orientation: { heading: C.Math.toRadians(-12), pitch: C.Math.toRadians(-82), roll: 0 },
    });
    viewer.camera.moveEnd.addEventListener(updateReadout);
    installTrackpadPinchZoom();
    installClicks();
    updateReadout();
  }

  function setExaggeration(v) {
    try { viewer.scene.verticalExaggeration = v; } catch (e) {}
    try { viewer.scene.globe.terrainExaggeration = v; } catch (e) {}
    $("exag-val").textContent = v.toFixed(1) + "×";
  }

  // ------------------------------------------------------------------ clicks
  function installClicks() {
    const h = new C.ScreenSpaceEventHandler(viewer.scene.canvas);
    h.setInputAction((movement) => {
      const pick = viewer.scene.pick(movement.position);
      const cart = viewer.camera.pickEllipsoid(movement.position, MARS);
      if (!cart) return;
      const cg = MARS.cartesianToCartographic(cart);
      const lat = C.Math.toDegrees(cg.latitude);
      const lon = ((C.Math.toDegrees(cg.longitude) % 360) + 360) % 360;

      if (measureMode) { addMeasurePoint(lat, lon); return; }
      if (nodePlaceMode) { placeNode(lat, lon); return; }

      if (pick && pick.id && pick.id.properties && pick.id.properties.kind) {
        openEntityCard(pick.id.properties);
        return;
      }
      selectPoint(lat, lon);
    }, C.ScreenSpaceEventType.LEFT_CLICK);
    // hover readout
    h.setInputAction((movement) => {
      const cart = viewer.camera.pickEllipsoid(movement.endPosition, MARS);
      if (!cart) return;
      const cg = MARS.cartesianToCartographic(cart);
      const lat = C.Math.toDegrees(cg.latitude);
      const lon = ((C.Math.toDegrees(cg.longitude) % 360) + 360) % 360;
      $("readout-coords").textContent = `${fLat(lat)} ${fLon(lon)}`;
    }, C.ScreenSpaceEventType.MOUSE_MOVE);
  }

  function openEntityCard(props) {
    const kind = props.kind.getValue ? props.kind.getValue() : props.kind;
    const data = (props.data.getValue ? props.data.getValue() : props.data);
    let html = "";
    if (kind === "site") {
      html = `<h3><span class="ins-title">${data.name}</span></h3>
        <div class="ins-coords">${fLat(data.lat)} ${fLon(data.lon)} · ${data.agency} ${data.kind} · ${data.date || ""}</div>
        <p class="note">${data.desc || ""}</p>
        <p class="note">Status: ${data.status || "—"}</p>`;
    } else if (kind === "target") {
      html = `<h3><span class="ins-title">${data.name}</span></h3>
        <div class="ins-coords">${fLat(data.lat)} ${fLon(data.lon)} · ${data.kind || ""}</div>
        <p class="note">${data.obs || ""}</p>
        ${(data.src && data.src.length) ? `<p class="note">Sources: ${data.src.slice(0, 3).join("; ")}</p>` : ""}`;
    } else if (kind === "node") {
      html = `<h3><span class="ins-title">${data.name}</span><span class="badge">${data.type}</span></h3>
        <div class="ins-coords">${fLat(data.lat)} ${fLon(data.lon)}${data.radius_m ? " · r=" + data.radius_m + " m" : ""}</div>
        <div class="ins-actions">
          <button class="mini-btn" data-act="fly" data-lat="${data.lat}" data-lon="${data.lon}">Fly</button>
          <button class="mini-btn danger" data-act="del-node" data-id="${data.id}">Delete</button>
        </div>`;
    } else if (kind === "water" || kind === "shelters") {
      html = `<h3><span class="ins-title">${data.name || data.id}</span><span class="badge">${kind}</span></h3>
        <div class="ins-coords">${fLat(data.lat)} ${fLon(data.lon)}</div>
        <p class="note">${data.note || data.desc || data.evidence || ""}</p>
        <p class="note">${data.certainty ? "Ice certainty: " + data.certainty : ""} ${data.depth_to_ice_m != null ? "· depth ≈ " + data.depth_to_ice_m + " m" : ""}</p>`;
    } else if (kind === "presence") {
      html = `<h3><span class="ins-title">${data.name}</span><span class="badge">sim</span></h3>
        <p class="note">${data.kind} · status ${data.status} · sol ${data.sol}</p>`;
    } else if (kind === "storm") {
      html = `<h3><span class="ins-title">${data.kind === "sep" ? "Solar particle event" : "Dust storm"}</span><span class="badge">sim</span></h3>
        <p class="note">Severity: ${data.severity} · status ${data.status || "active"} · started ${data.started || "—"}</p>`;
    }
    const ins = $("inspector");
    ins.innerHTML = html + `<div class="ins-actions">
      <button class="mini-btn" data-act="inspect" data-lat="${data.lat}" data-lon="${data.lon}">Terrain dossier</button>
      <button class="mini-btn" data-act="fly" data-lat="${data.lat}" data-lon="${data.lon}">Fly here</button>
    </div>`;
    ins.classList.remove("hidden");
    bindInspector();
  }

  async function selectPoint(lat, lon, fly = false) {
    selected = { lat, lon };
    routeStart = null; routeEnd = null;
    if (fly) flyTo(lat, lon, 250000);
    const ins = $("inspector");
    ins.classList.remove("hidden");
    ins.innerHTML = `<h3><span class="ins-title">${fLat(lat)} ${fLon(lon)}</span></h3>
      <div class="facts"><div class="fact"><div class="fv">…</div><div class="fk">loading</div></div></div>`;
    bindInspector();
    try {
      const [el, hz, rad] = await Promise.all([
        jget(`${API}/elevation?lat=${lat}&lon=${lon}`),
        jget(`${API}/hazard?lat=${lat}&lon=${lon}`),
        jget(`${API}/radiation?lat=${lat}&lon=${lon}`).catch(() => null),
      ]);
      const hzCol = hz.hazard_score >= 0.6 ? "var(--bad)" : hz.hazard_score >= 0.35 ? "var(--warn)" : "var(--ok)";
      ins.innerHTML = `
        <h3><span class="ins-title">Location dossier</span>
            <span class="ins-coords">${fLat(lat)} ${fLon(lon)}</span></h3>
        <div class="facts">
          <div class="fact"><div class="fv">${el.elev_m >= 0 ? "+" : ""}${el.elev_m} m</div><div class="fk">Elevation MOLA</div></div>
          <div class="fact"><div class="fv">${el.slope_deg ?? "—"}°</div><div class="fk">Slope (~30 km)</div></div>
          <div class="fact"><div class="fv">${el.roughness_m ?? "—"} m</div><div class="fk">Roughness</div></div>
          <div class="fact"><div class="fv">${el.pressure_mbar} mbar</div><div class="fk">Pressure est.</div></div>
          <div class="fact"><div class="fv"><span class="hz"><span class="hz-dot" style="background:${hzCol}"></span>${hz.hazard_class} ${(hz.hazard_score ?? 0).toFixed(2)}</span></div><div class="fk">Hazard</div></div>
          <div class="fact"><div class="fv">${rad && rad.dose_mSv_day != null ? rad.dose_mSv_day + " mSv/d" : (rad && rad.dose_mSv_sol != null ? rad.dose_mSv_sol + " mSv/sol" : "—")}</div><div class="fk">Dose [est]</div></div>
        </div>
        <div class="ins-actions">
          <button class="mini-btn" data-act="route-start" data-lat="${lat}" data-lon="${lon}">Route start</button>
          <button class="mini-btn" data-act="route-end" data-lat="${lat}" data-lon="${lon}">Route end</button>
          <button class="mini-btn" data-act="node-here" data-lat="${lat}" data-lon="${lon}">Node here</button>
          <button class="mini-btn" data-act="walk-here" data-lat="${lat}" data-lon="${lon}">Walk here</button>
          <button class="mini-btn" data-act="water-here" data-lat="${lat}" data-lon="${lon}">Water nearby</button>
          <button class="mini-btn" data-act="shelter-here" data-lat="${lat}" data-lon="${lon}">Shelters nearby</button>
        </div>
        <p class="note">${(hz.notes || []).slice ? hz.notes.slice(0, 2).join(" · ") : ""}</p>`;
      bindInspector();
    } catch (e) {
      ins.innerHTML = `<h3><span class="ins-title">${fLat(lat)} ${fLon(lon)}</span></h3><p class="note">Terrain lookup failed: ${e.message}</p>`;
      bindInspector();
    }
  }

  function bindInspector() {
    $("inspector").querySelectorAll("[data-act]").forEach(b => {
      b.onclick = () => {
        const act = b.dataset.act;
        if (act === "fly") flyTo(parseFloat(b.dataset.lat), parseFloat(b.dataset.lon), 220000);
        else if (act === "inspect") selectPoint(parseFloat(b.dataset.lat), parseFloat(b.dataset.lon));
        else if (act === "route-start") { routeStart = { lat: +b.dataset.lat, lon: +b.dataset.lon }; toast("Route start set", `${fLat(routeStart.lat)} ${fLon(routeStart.lon)} — now set the end`, "ok", 3500); }
        else if (act === "route-end") { routeEnd = { lat: +b.dataset.lat, lon: +b.dataset.lon }; planQuickRoute(); }
        else if (act === "node-here") { openPanel("nodes"); placeNode(+b.dataset.lat, +b.dataset.lon); }
        else if (act === "walk-here") startWalk(+b.dataset.lat, +b.dataset.lon);
        else if (act === "water-here") { setEntityOverlay("water", true); openPanel("layers"); toast("Water overlay", "Candidates within 2500 km loaded around the selected point.", "ok"); }
        else if (act === "shelter-here") { setEntityOverlay("shelters", true); openPanel("layers"); toast("Shelter overlay", "Candidates within 2500 km loaded around the selected point.", "ok"); }
        else if (act === "del-node") deleteNode(b.dataset.id);
      };
    });
  }

  async function planQuickRoute() {
    if (!routeStart || !routeEnd) return;
    toast("Planning A* route…", "Terrain-weighted global grid search");
    try {
      const r = await jpost(`${API}/route`, {
        start_lat: routeStart.lat, start_lon: routeStart.lon,
        end_lat: routeEnd.lat, end_lon: routeEnd.lon, preset: "balanced",
      });
      drawRoutePolyline("quick-route", r.waypoints, "#ff9257");
      const s = r.stats || {};
      toast("Route ready",
        `${s.length_km ?? "—"} km · +${s.ascent_m ?? 0}/-${s.descent_m ?? 0} m · max slope ${s.max_slope_deg ?? "—"}° · ≈${s.est_sols ?? "—"} sols · preset: balanced`, "ok", 9000);
      showProfile(r.waypoints.map(w => w.elev_m ?? 0), "A* route elevation profile");
    } catch (e) { toast("Route failed", e.message, "bad"); }
  }

  function drawRoutePolyline(setId, waypoints, color) {
    const ds = getDS(setId);
    if (!viewer.dataSources.contains(ds)) viewer.dataSources.add(ds);
    ds.entities.removeAll();
    ds.show = true;
    const positions = waypoints.map(w => C.Cartesian3.fromDegrees(w.lon, w.lat, 500, MARS));
    ds.entities.add({
      polyline: { positions, width: 3.5, clampToGround: true,
        material: new C.PolylineGlowMaterialProperty({ color: C.Color.fromCssColorString(color), glowPower: 0.25 }) },
    });
    waypoints.forEach((w, i) => {
      if (i % Math.ceil(waypoints.length / 40) !== 0 && i !== waypoints.length - 1) return;
      ds.entities.add({ position: C.Cartesian3.fromDegrees(w.lon, w.lat, 300, MARS),
        point: { pixelSize: 5, color: C.Color.fromCssColorString(color) } });
    });
  }

  // ------------------------------------------------------------------ search
  const COORD_RE = /^\s*(-?\d+(?:\.\d+)?)\s*[,\s]\s*(-?\d+(?:\.\d+)?)\s*$/;
  let searchTimer = null, searchSel = -1, searchItems = [];

  function bindSearch() {
    const input = $("search-input"), box = $("search-results");
    input.addEventListener("input", () => {
      clearTimeout(searchTimer);
      const q = input.value.trim();
      if (!q) { box.classList.add("hidden"); return; }
      searchTimer = setTimeout(() => runSearch(q), 160);
    });
    input.addEventListener("keydown", (ev) => {
      if (ev.key === "Enter") {
        const it = searchItems[searchSel >= 0 ? searchSel : 0];
        if (it) { chooseSearchItem(it); input.blur(); }
        else if (COORD_RE.test(input.value)) { const m = input.value.match(COORD_RE); selectPoint(+m[1], ((+m[2]) % 360 + 360) % 360, true); box.classList.add("hidden"); input.blur(); }
      } else if (ev.key === "ArrowDown" || ev.key === "ArrowUp") {
        ev.preventDefault();
        searchSel = Math.min(searchItems.length - 1, Math.max(0, searchSel + (ev.key === "ArrowDown" ? 1 : -1)));
        highlightSearch();
      } else if (ev.key === "Escape") { box.classList.add("hidden"); input.blur(); }
    });
    document.addEventListener("keydown", (ev) => {
      if (ev.key === "/" && document.activeElement.tagName !== "INPUT" && document.activeElement.tagName !== "TEXTAREA") {
        ev.preventDefault(); input.focus();
      }
    });
    document.addEventListener("click", (ev) => {
      if (!ev.target.closest(".searchbar")) box.classList.add("hidden");
    });
  }

  async function runSearch(q) {
    const box = $("search-results");
    searchSel = -1; searchItems = [];
    const cm = q.match(COORD_RE);
    if (cm) {
      box.innerHTML = `<button class="sr-item" data-i="0"><span class="sr-name">Coordinates ${fLat(+cm[1])} ${fLon(+cm[2])}</span>
        <span class="sr-meta">Jump to location · dossier</span></button>`;
      box.classList.remove("hidden");
      searchItems = [{ coord: true, lat: +cm[1], lon: ((+cm[2]) % 360 + 360) % 360 }];
      box.querySelectorAll(".sr-item").forEach(b => b.onclick = () => chooseSearchItem(searchItems[0]));
      return;
    }
    let items = [];
    try {
      const r = await jget(`/search?q=${encodeURIComponent(q)}`);
      if (r && r.ok) items.push({ name: r.name, meta: `${r.type || "feature"} · conf ${r.confidence != null ? (r.confidence * 100).toFixed(0) + "%" : "—"}`, lat: r.lat, lon: r.lon, elev: r.elev_m, tag: "matcher", raw: r });
    } catch (e) { /* matcher offline */ }
    try {
      const g = await jget(`${API}/gazetteer?q=${encodeURIComponent(q)}&limit=8`);
      for (const f of (g.features || [])) {
        if (items.some(i => i.name === f.name)) continue;
        items.push({ name: f.name, meta: `${f.type || "feature"}${f.desc ? " · " + f.desc.slice(0, 60) : ""}`, lat: f.lat, lon: f.lon, tag: "gazetteer" });
        if (items.length >= 9) break;
      }
    } catch (e) { /* gazetteer offline */ }
    if (!items.length) {
      box.innerHTML = `<div class="sr-empty">No confident match — the matcher refuses to guess. Try “Gale”, “Jezero”, “Olympus Mons”, a feature type like “crater”, or lat, lon.</div>`;
      box.classList.remove("hidden");
      return;
    }
    searchItems = items;
    box.innerHTML = items.map((it, i) => `
      <button class="sr-item" data-i="${i}">
        <span class="sr-name">${it.name}</span>
        <span class="sr-meta"><span class="sr-tag">${it.tag}</span>${it.meta || ""}${it.elev != null ? ` · ${it.elev} m` : ""}</span>
      </button>`).join("");
    box.classList.remove("hidden");
    box.querySelectorAll(".sr-item").forEach(b => b.onclick = () => chooseSearchItem(searchItems[+b.dataset.i]));
  }
  function highlightSearch() {
    $("search-results").querySelectorAll(".sr-item").forEach((b, i) => b.classList.toggle("sel", i === searchSel));
  }
  async function chooseSearchItem(it) {
    $("search-results").classList.add("hidden");
    if (it.coord) { selectPoint(it.lat, it.lon, true); return; }
    flyTo(it.lat, it.lon, 320000);
    $("readout-coords").textContent = `${it.name} · ${fLat(it.lat)} ${fLon(it.lon)}`;
    selectPoint(it.lat, it.lon);
  }

  // --------------------------------------------------------------- measuring
  function setMeasureMode(on) {
    measureMode = on;
    $("rail-measure").classList.toggle("active", on);
    $("measure-card").classList.toggle("hidden", !on);
    if (!on) { clearMeasure(); return; }
    toast("Measure", "Click points on the globe — distance + elevation profile.", "", 4200);
  }
  function addMeasurePoint(lat, lon) {
    measurePts.push({ lat, lon });
    const ds = getDS("measure");
    if (!viewer.dataSources.contains(ds)) viewer.dataSources.add(ds);
    ds.show = true;
    ds.entities.add({ position: C.Cartesian3.fromDegrees(lon, lat, 500, MARS),
      point: { pixelSize: 8, color: C.Color.fromCssColorString("#3ec9dc"), outlineColor: C.Color.WHITE, outlineWidth: 1 } });
    if (measurePts.length > 1) {
      const a = measurePts[measurePts.length - 2], b = measurePts[measurePts.length - 1];
      ds.entities.add({ polyline: {
        positions: [C.Cartesian3.fromDegrees(a.lon, a.lat, 500, MARS), C.Cartesian3.fromDegrees(b.lon, b.lat, 500, MARS)],
        width: 2.5, clampToGround: true, material: new C.PolylineDashMaterialProperty({ color: C.Color.fromCssColorString("#3ec9dc") }) } });
    }
    updateMeasureCard();
  }
  async function updateMeasureCard() {
    const facts = $("measure-facts");
    if (measurePts.length < 2) { facts.innerHTML = `<div class="fact"><div class="fv">${measurePts.length}</div><div class="fk">points</div></div>`; return; }
    const a = measurePts[measurePts.length - 2], b = measurePts[measurePts.length - 1];
    const d = haversineKm(a.lat, a.lon, b.lat, b.lon);
    let total = 0;
    for (let i = 1; i < measurePts.length; i++) total += haversineKm(measurePts[i - 1].lat, measurePts[i - 1].lon, measurePts[i].lat, measurePts[i].lon);
    facts.innerHTML = `
      <div class="fact"><div class="fv">${d.toFixed(2)} km</div><div class="fk">last segment</div></div>
      <div class="fact"><div class="fv">${total.toFixed(2)} km</div><div class="fk">total path</div></div>`;
    const pts = measurePts.map(p => `${p.lat},${p.lon}`).join(",");
    try {
      const r = await jget(`${API}/elevation/profile?points=${pts}`);
      drawProfileChart(r.profile.map(p => p.elev_m != null ? p.elev_m : (p.elevation_m ?? 0)));
    } catch (e) { console.warn("profile failed", e); }
  }
  function drawProfileChart(elevs) {
    const cv = $("measure-chart"), ctx = cv.getContext("2d");
    const W = cv.width, H = cv.height;
    ctx.clearRect(0, 0, W, H);
    if (elevs.length < 2) return;
    const min = Math.min(...elevs), max = Math.max(...elevs);
    ctx.strokeStyle = "#ff6a2b"; ctx.lineWidth = 2; ctx.beginPath();
    elevs.forEach((v, i) => {
      const x = 8 + i / (elevs.length - 1) * (W - 16);
      const y = 12 + (1 - (v - min) / Math.max(1, max - min)) * (H - 30);
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    });
    ctx.stroke();
    ctx.fillStyle = "#98a4b3"; ctx.font = "11px monospace";
    ctx.fillText(`${(max / 1000).toFixed(1)} km`, 10, 14);
    ctx.fillText(`${(min / 1000).toFixed(1)} km`, 10, H - 6);
  }
  function showProfile(elevs, title) {
    if (!elevs || elevs.length < 2) return;
    setMeasureMode(true);
    drawProfileChart(elevs);
    $("measure-facts").innerHTML = `<div class="fact"><div class="fv">${title}</div><div class="fk">${elevs.length} samples · min ${(Math.min(...elevs) / 1000).toFixed(2)} · max ${(Math.max(...elevs) / 1000).toFixed(2)} km</div></div>`;
  }
  function clearMeasure() {
    measurePts = [];
    const ds = entitySets.get("measure");
    if (ds) ds.entities.removeAll();
    $("measure-facts").innerHTML = "";
    const ctx = $("measure-chart").getContext("2d");
    ctx.clearRect(0, 0, 600, 140);
  }

  // ----------------------------------------------------------- layer panel UI
  function renderLayerPanel() {
    const baseList = $("base-layer-list");
    const overlayList = $("overlay-list");
    baseList.replaceChildren();
    overlayList.replaceChildren();
    for (const def of BASE_DEFS) {
      const row = document.createElement("label");
      row.className = "layer-row";
      const srcTag = { live: "LIVE", proxy: "PROXY", gen: "GEN" }[def.src] || "REG";
      row.innerHTML = `<input type="radio" name="base" ${def.id === baseLayerId ? "checked" : ""}>
        <span class="layer-name">${def.name}</span><span class="layer-src ${def.src}">${srcTag}</span>`;
      row.querySelector("input").onchange = () => setBaseLayer(def.id);
      baseList.appendChild(row);
    }
    const allOverlays = [...OVERLAY_DEFS.map(d => ({ id: d.id, name: d.name, src: d.src })),
      { id: "sites", name: "Mission sites (13)", src: "api" },
      { id: "targets", name: "Scientific targets (16)", src: "api" },
      { id: "water", name: "Water-ice candidates (SWIM proxy)", src: "api" },
      { id: "shelters", name: "Shelter candidates (12)", src: "api" },
      { id: "presence", name: "Simulated presence", src: "api" },
      { id: "storms", name: "Storm footprints", src: "api" },
      { id: "nodes", name: "User nodes", src: "api" }];
    for (const def of allOverlays) {
      const on = ENTITY_OVERLAYS.includes(def.id) ? (entitySets.get(def.id) ? entitySets.get(def.id).show : false) : overlays.has(def.id);
      const row = document.createElement("div");
      row.className = "layer-row";
      row.innerHTML = `<input type="checkbox" ${on ? "checked" : ""}>
        <span class="layer-name">${def.name}</span><span class="layer-src ${def.src === "api" ? "live" : def.src}">${def.src.toUpperCase()}</span>
        ${!ENTITY_OVERLAYS.includes(def.id) ? `<input type="range" class="layer-alpha" min="0.1" max="1" step="0.05" value="${(overlays.get(def.id) ? overlays.get(def.id).imagery.alpha : (findDef(def.id).alpha || 0.7))}">` : ""}`;
      row.querySelector("input[type=checkbox]").onchange = (ev) => {
        const checked = ev.target.checked;
        if (!ENTITY_OVERLAYS.includes(def.id)) { checked ? addOverlay(def.id) : removeOverlay(def.id); }
        else setEntityOverlay(def.id, checked);
        renderLayerPanel();
      };
      const rng = row.querySelector(".layer-alpha");
      if (rng) rng.oninput = (ev) => setOverlayAlpha(def.id, parseFloat(ev.target.value));
      overlayList.appendChild(row);
    }
    const sel = $("compare-layer");
    sel.replaceChildren();
    for (const def of BASE_DEFS.filter(d => d.id !== baseLayerId)) {
      const o = document.createElement("option"); o.value = def.id; o.textContent = def.name; sel.appendChild(o);
    }
  }
  function setCompare(on) {
    compareOn = on;
    $("compare-divider").classList.toggle("hidden", !on);
    if (!on) {
      if (baseLayer) baseLayer.splitDirection = C.SplitDirection.NONE;
      if (compareLayerObj) { viewer.imageryLayers.remove(compareLayerObj.imagery, true); compareLayerObj = null; }
      const ds = getDS("grid"); ds.show = false;
      return;
    }
    const id = $("compare-layer").value;
    const def = findDef(id);
    if (!def) return;
    const imagery = viewer.imageryLayers.addImageryProvider(makeProviderFor(def));
    imagery.splitDirection = C.SplitDirection.RIGHT;
    if (baseLayer) baseLayer.splitDirection = C.SplitDirection.LEFT;
    compareLayerObj = { imagery, def };
    viewer.scene.splitPosition = 0.5;
    toast("Compare mode", `Left: ${findDef(baseLayerId).name} · right: ${def.name}. Drag the orange divider.`, "ok", 7000);
  }

  // ---------------------------------------------------------------- missions
  // Delegated handlers on #mission-detail — the detail re-renders after every
  // mutation, so per-node onclick assignments would orphan buttons mid-click.
  function bindMissions() {
    $("mission-new").onclick = () => { $("mission-form").classList.toggle("hidden"); };
    $("mission-cancel").onclick = () => $("mission-form").classList.add("hidden");
    $("mission-form").onsubmit = async (ev) => {
      ev.preventDefault();
      try {
        const r = await jpost(`${API}/plans`, {
          name: $("mission-name").value.trim() || "Untitled traverse",
          objective: $("mission-objective").value.trim(),
          kind: $("mission-kind").value,
        });
        $("mission-form").classList.add("hidden");
        $("mission-name").value = ""; $("mission-objective").value = "";
        toast("Mission created", r.mission.name, "ok");
        refreshMissions(r.mission.id);
      } catch (e) { toast("Create failed", e.message, "bad"); }
    };
    $("mission-detail").addEventListener("click", missionDetailClick);
    refreshMissions();
  }

  async function missionDetailClick(ev) {
    const el = ev.target.closest("[data-role], [data-fly]");
    if (!el) return;
    if (el.dataset.fly) {
      const [la, lo] = el.dataset.fly.split(",").map(Number);
      flyTo(la, lo, 160000);
      return;
    }
    if (!currentMission) return;
    const m = currentMission;
    const act = el.dataset.role;
    if (act === "add-wp") {
      if (!selected) return toast("No selection", "Click the globe first to pick a location.", "warn");
      const r = await jpost(`${API}/plans/${m.id}/waypoints`, { lat: selected.lat, lon: selected.lon, name: "WP" });
      toast("Waypoint added", `${fLat(r.waypoint.lat)} ${fLon(r.waypoint.lon)}`, "ok", 3000);
      refreshMissions(m.id);
    } else if (act === "add-stop") {
      if (!selected) return toast("No selection", "Click the globe first.", "warn");
      const reason = prompt("Stop reason (e.g. shelter, science, resupply):", "science") || "science";
      const r = await jpost(`${API}/plans/${m.id}/stops`, { lat: selected.lat, lon: selected.lon, reason, activity: "field ops" });
      toast("Stop added", r.stop.reason, "ok", 3000);
      refreshMissions(m.id);
    } else if (act === "plan") {
      planMissionRoute(m.id, $("m-preset").value);
    } else if (act === "kml") {
      exportMissionKML(m.id, m.name);
    } else if (act === "del") {
      await fetch(`${API}/plans/${m.id}`, { method: "DELETE" });
      $("mission-detail").classList.add("hidden");
      const ds = entitySets.get(`mission-${m.id}`);
      if (ds) { ds.entities.removeAll(); ds.show = false; }
      refreshMissions();
    }
  }

  async function refreshMissions(selectId) {
    try {
      const { missions } = await jget(`${API}/plans`);
      const list = $("mission-list");
      list.replaceChildren();
      for (const m of missions) {
        const item = document.createElement("button");
        item.className = "rl-item";
        item.innerHTML = `<span class="rl-main"><span class="rl-name">${m.name}</span>
          <span class="rl-sub">${m.kind} · ${(m.waypoints || []).length} wp · ${(m.stops || []).length} stops</span></span>
          <span class="rl-act"><span class="mini-btn">open</span></span>`;
        item.querySelector(".mini-btn").onclick = (ev) => { ev.stopPropagation(); openMission(m.id); };
        item.onclick = () => openMission(m.id);
        list.appendChild(item);
      }
      if (selectId) openMission(selectId);
    } catch (e) { console.warn("missions load failed", e); }
  }

  async function openMission(id) {
    try {
      currentMission = await jget(`${API}/plans/${id}`);
      const m = currentMission;
      const det = $("mission-detail");
      det.classList.remove("hidden");
      const wps = (m.waypoints || []).map((w, i) => `
        <button class="rl-item" data-fly="${w.lat},${w.lon}">
          <span class="rl-main"><span class="rl-name">WP${i + 1} ${w.name || ""}</span>
          <span class="rl-sub">${fLat(w.lat)} ${fLon(w.lon)}</span></span></button>`).join("");
      const stops = (m.stops || []).map((s, i) => `
        <div class="rl-item"><span class="rl-main"><span class="rl-name">Stop ${i + 1} ${s.reason ? "· " + s.reason : ""}</span>
        <span class="rl-sub">${fLat(s.lat)} ${fLon(s.lon)}${s.activity ? " · " + s.activity : ""}</span></span></div>`).join("");
      det.innerHTML = `
        <h3 class="psec">${m.name} <span class="badge">${m.kind}</span></h3>
        ${m.objective ? `<p class="note">${m.objective}</p>` : ""}
        <div class="form-row">
          <button class="btn" data-role="add-wp">＋ WP at selection</button>
          <button class="btn" data-role="add-stop">＋ Stop at selection</button>
        </div>
        <div class="form-row">
          <select id="m-preset"><option value="balanced">Balanced</option><option value="terrain">Terrain-aware</option><option value="speed">Speed</option></select>
          <button class="btn primary" data-role="plan">Plan route</button>
        </div>
        <div class="form-row">
          <button class="btn" data-role="kml">Export KML</button>
          <button class="btn danger" data-role="del">Delete</button>
        </div>
        <div id="m-stats" class="facts"></div>
        ${wps ? `<h3 class="psec">Waypoints</h3><div class="row-list small">${wps}</div>` : ""}
        ${stops ? `<h3 class="psec">Stops</h3><div class="row-list small">${stops}</div>` : ""}`;
      if ((m.route && m.route.waypoints) || (m.waypoints || []).length > 1) {
        const wp = (m.route && m.route.waypoints) || m.waypoints;
        drawRoutePolyline(`mission-${m.id}`, wp.map(w => ({ lat: w.lat, lon: w.lon, elev_m: 0 })), "#ff6a2b");
        if (m.route && m.route.stats) renderRouteStats(m.route.stats);
      }
    } catch (e) { toast("Mission load failed", e.message, "bad"); }
  }

  async function planMissionRoute(id, preset) {
    const m = currentMission;
    if (!m) return;
    const wps = m.waypoints || [];
    let start = routeStart, end = routeEnd;
    if (!start && wps.length) start = { lat: wps[0].lat, lon: wps[0].lon };
    if (!end && wps.length > 1) end = { lat: wps[wps.length - 1].lat, lon: wps[wps.length - 1].lon };
    if (!start && selected) start = selected;
    if (!end && selected && (!start || selected.lat !== start.lat || selected.lon !== start.lon)) end = selected;
    if (!start || !end) return toast("Need start and end", "Add waypoints or set route start/end from a location dossier.", "warn");
    toast("Planning A* route…", `preset: ${preset} — slope/roughness-weighted global grid`);
    try {
      const r = await jpost(`${API}/route`, { start_lat: start.lat, start_lon: start.lon, end_lat: end.lat, end_lon: end.lon, preset });
      drawRoutePolyline(`mission-${id}`, r.waypoints, "#ff6a2b");
      renderRouteStats(r.stats);
      // persist onto the mission so KML export includes the computed path
      await jpost(`${API}/plans/${id}/route`, { waypoints: r.waypoints, stats: r.stats, preset, notes: r.notes });
      showProfile(r.waypoints.map(w => w.elev_m ?? 0), `Route profile (${preset})`);
      refreshMissions(id);
    } catch (e) { toast("Route failed", e.message, "bad"); }
  }

  function renderRouteStats(s) {
    const box = $("m-stats");
    if (!box || !s) return;
    box.innerHTML = `
      <div class="fact"><div class="fv">${s.length_km ?? "—"}</div><div class="fk">km</div></div>
      <div class="fact"><div class="fv">+${s.ascent_m ?? 0} / -${s.descent_m ?? 0}</div><div class="fk">m ascent/descent</div></div>
      <div class="fact"><div class="fv">${s.max_slope_deg ?? "—"}°</div><div class="fk">max slope</div></div>
      <div class="fact"><div class="fv">${s.est_sols ?? "—"} sols</div><div class="fk">est. EVA time</div></div>`;
  }

  async function exportMissionKML(id, name) {
    try {
      const r = await jpost(`${API}/assistant/tool/export_mission`, { mission_id: id, format: "kml" });
      const res = r.result || r;
      if (res.kml) {
        const blob = new Blob([res.kml], { type: "application/vnd.google-earth.kml+xml" });
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = `${name.replace(/\W+/g, "_")}.kml`;
        a.click();
        toast("KML exported", res.kml.length + " bytes", "ok", 3000);
      } else {
        toast("Nothing to export", "Plan a route or add waypoints first.", "warn");
      }
    } catch (e) { toast("Export failed", e.message, "bad"); }
  }

  // ------------------------------------------------------------------- nodes
  function bindNodes() {
    $("node-type-chips").querySelectorAll(".chip").forEach(c => {
      c.onclick = () => {
        $("node-type-chips").querySelectorAll(".chip").forEach(x => x.classList.remove("active"));
        c.classList.add("active");
        nodeType = c.dataset.type;
      };
    });
    $("node-add-mode").onclick = () => {
      nodePlaceMode = nodeType;
      $("node-add-mode").textContent = `Placing ${nodeType} — click the globe (Esc to cancel)`;
      toast("Node placement", `Click the globe to place a ${nodeType} node.`, "", 3500);
    };
    $("node-filter").oninput = () => renderNodeList($("node-filter").value);
    renderNodeList();
  }
  async function renderNodeList(filter = "") {
    try {
      const { nodes } = await jget(`${API}/nodes`);
      const list = $("node-list");
      list.replaceChildren();
      for (const n of nodes.filter(n => !filter || (n.name + n.type).toLowerCase().includes(filter.toLowerCase()))) {
        const item = document.createElement("div");
        item.className = "rl-item";
        item.innerHTML = `<span class="rl-main"><span class="rl-name">${n.name}</span>
          <span class="rl-sub">${n.type} · ${fLat(n.lat)} ${fLon(n.lon)}</span></span>
          <span class="rl-act">
            <button class="mini-btn">fly</button>
            <button class="mini-btn danger">del</button>
          </span>`;
        const [fly, del] = item.querySelectorAll(".mini-btn");
        fly.onclick = () => flyTo(n.lat, n.lon, 120000);
        del.onclick = () => deleteNode(n.id);
        list.appendChild(item);
      }
      refreshEntitySet("nodes");
    } catch (e) { console.warn("nodes load failed", e); }
  }
  async function placeNode(lat, lon) {
    const type = nodePlaceMode || nodeType;
    const name = prompt(`Name for the new ${type} node:`, `${type[0].toUpperCase() + type.slice(1)} ${new Date().toISOString().slice(11, 16)}`);
    if (!name) { cancelNodePlace(); return; }
    try {
      const r = await jpost(`${API}/nodes`, { name, type, lat, lon, radius_m: 0, properties: { created_by: "unified-ui" } });
      toast("Node placed", `${r.node.name} · ${fLat(lat)} ${fLon(lon)}`, "ok", 3000);
      renderNodeList($("node-filter").value);
    } catch (e) { toast("Node failed", e.message, "bad"); }
    cancelNodePlace();
  }
  function cancelNodePlace() {
    nodePlaceMode = null;
    $("node-add-mode").textContent = "＋ Place node — click the globe";
  }
  async function deleteNode(id) {
    await fetch(`${API}/nodes/${id}`, { method: "DELETE" });
    renderNodeList($("node-filter").value);
    toast("Node deleted", id, "", 2500);
  }

  // ------------------------------------------------------------------ places
  let placesTab = "sites";
  function bindPlaces() {
    $("places-tabs").querySelectorAll(".tab").forEach(t => {
      t.onclick = () => {
        $("places-tabs").querySelectorAll(".tab").forEach(x => x.classList.remove("active"));
        t.classList.add("active");
        placesTab = t.dataset.tab;
        renderPlaces();
      };
    });
    $("places-filter").oninput = renderPlaces;
    renderPlaces();
  }
  async function renderPlaces() {
    const list = $("places-list");
    const q = $("places-filter").value.trim().toLowerCase();
    list.replaceChildren();
    try {
      if (placesTab === "sites") {
        const { sites, orbiters } = await jget(`${API}/missions/sites`);
        const arr = sites.filter(s => !q || (s.name + s.agency).toLowerCase().includes(q));
        for (const s of arr) {
          const item = document.createElement("button");
          item.className = "rl-item";
          item.innerHTML = `<span class="rl-main"><span class="rl-name">${s.name}</span>
            <span class="rl-sub">${s.agency} ${s.kind} · ${s.date || ""} · ${fLat(s.lat)} ${fLon(s.lon)}</span></span>
            <span class="rl-act"><span class="mini-btn">fly</span></span>`;
          item.querySelector(".mini-btn").onclick = (ev) => { ev.stopPropagation(); flyTo(s.lat, s.lon, 260000); selectPoint(s.lat, s.lon); };
          item.onclick = () => { flyTo(s.lat, s.lon, 260000); selectPoint(s.lat, s.lon); };
          list.appendChild(item);
        }
        for (const o of orbiters) {
          const item = document.createElement("div");
          item.className = "rl-item";
          item.innerHTML = `<span class="rl-main"><span class="rl-name">${o.name}</span>
            <span class="rl-sub">${o.agency} · ${o.years} · ${o.inst}</span></span>`;
          list.appendChild(item);
        }
      } else if (placesTab === "gaz") {
        const g = await jget(`${API}/gazetteer?q=${encodeURIComponent(q)}&limit=120`);
        $("places-filter").placeholder = `Filter ${g.count} features…`;
        for (const f of (g.features || [])) {
          const item = document.createElement("button");
          item.className = "rl-item";
          item.innerHTML = `<span class="rl-main"><span class="rl-name">${f.name}</span>
            <span class="rl-sub">${f.type || ""} · ${fLat(f.lat)} ${fLon(f.lon)}</span></span>
            <span class="rl-act"><span class="mini-btn">fly</span></span>`;
          const fly = item.querySelector(".mini-btn");
          fly.onclick = (ev) => { ev.stopPropagation(); flyTo(f.lat, f.lon, 300000); selectPoint(f.lat, f.lon); };
          item.onclick = () => { flyTo(f.lat, f.lon, 300000); selectPoint(f.lat, f.lon); };
          list.appendChild(item);
        }
      } else if (placesTab === "targets") {
        const { targets } = await jget(`${API}/targets`);
        for (const t of targets.filter(t => !q || (t.name + t.kind).toLowerCase().includes(q))) {
          const item = document.createElement("button");
          item.className = "rl-item";
          item.innerHTML = `<span class="rl-main"><span class="rl-name">${t.name}</span>
            <span class="rl-sub">${t.kind || ""} · ${fLat(t.lat)} ${fLon(t.lon)}</span></span>
            <span class="rl-act"><span class="mini-btn">fly</span></span>`;
          item.querySelector(".mini-btn").onclick = (ev) => { ev.stopPropagation(); flyTo(t.lat, t.lon, 300000); selectPoint(t.lat, t.lon); };
          item.onclick = () => { flyTo(t.lat, t.lon, 300000); selectPoint(t.lat, t.lon); };
          list.appendChild(item);
        }
      } else if (placesTab === "povs") {
        const { povs } = await jget(`${API}/walk/povs`);
        for (const p of povs.filter(p => !q || (p.caption + p.mission).toLowerCase().includes(q))) {
          const item = document.createElement("button");
          item.className = "rl-item";
          item.innerHTML = `<span class="rl-main"><span class="rl-name">${p.mission} — ${p.instrument}</span>
            <span class="rl-sub">sol ${p.sol} · ${fLat(p.lat)} ${fLon(p.lon)} · ${p.caption.slice(0, 42)}…</span></span>
            <span class="rl-act"><span class="mini-btn">view</span></span>`;
          item.querySelector(".mini-btn").onclick = (ev) => { ev.stopPropagation(); flyTo(p.lat, p.lon, 90000); startWalk(p.lat, p.lon); };
          item.onclick = () => { flyTo(p.lat, p.lon, 90000); startWalk(p.lat, p.lon); };
          list.appendChild(item);
        }
      }
    } catch (e) {
      list.innerHTML = `<div class="sr-empty">Load failed: ${e.message}</div>`;
    }
  }

  // --------------------------------------------------------------- walk view
  const Walk = { active: false, raf: 0, keys: {}, yaw: 0, pitch: 0, grid: null, cam: null };

  async function startWalk(lat, lon) {
    const radius = parseFloat($("walk-radius").value);
    const eye = parseFloat($("walk-eye").value);
    $("walk-start").textContent = `${fLat(lat)} ${fLon(lon)}`;
    toast("Walk view", "Building MOLA terrain patch…", "", 2500);
    let init, patch;
    try {
      [init, patch] = await Promise.all([
        jget(`${API}/walk/init?lat=${lat}&lon=${lon}`),
        jget(`${API}/walk/terrain?lat=${lat}&lon=${lon}&radius_m=${radius}&resolution_m=25`),
      ]);
    } catch (e) { toast("Walk failed", e.message, "bad"); return; }
    Walk.radius = radius;
    enterWalkScene(init, patch, eye);
  }

  function enterWalkScene(init, patch, eye) {
    if (typeof THREE === "undefined") { toast("Walk view", "Three.js failed to load from CDN — walk view unavailable.", "bad"); return; }
    const [nLat, nLon] = patch.grid_shape;
    const heights = patch.heights_m;
    const ext = patch.extent;
    Walk.grid = { nLat, nLon, heights, ext, cell: patch.cell_size_m };
    const minH = Math.min(...heights), maxH = Math.max(...heights);

    const canvas = $("walk-canvas");
    canvas.width = window.innerWidth; canvas.height = window.innerHeight;
    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight, false);
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x1a0f08);
    scene.fog = new THREE.Fog(0x1a0f08, 300, 2600);

    // sky dome tinted like a butterscotch Mars sky
    const skyGeo = new THREE.SphereGeometry(3000, 24, 16);
    const skyMat = new THREE.MeshBasicMaterial({ color: 0xc98a5a, side: THREE.BackSide });
    const sky = new THREE.Mesh(skyGeo, skyMat);
    scene.add(sky);
    const sunDir = new THREE.Vector3(0.6, 0.5, -0.3).normalize();
    const sun = new THREE.DirectionalLight(0xffd9b0, 1.1);
    sun.position.copy(sunDir); scene.add(sun);
    scene.add(new THREE.HemisphereLight(0xc98a5a, 0x3a2a1c, 0.55));

    // terrain mesh displaced by the patch heights
    const geo = new THREE.PlaneGeometry(2 * patch.radius_m, 2 * patch.radius_m, nLat - 1, nLon - 1);
    geo.rotateX(-Math.PI / 2);
    const pos = geo.attributes.position;
    const colors = new Float32Array(pos.count * 3);
    for (let i = 0; i < nLat; i++) {
      for (let j = 0; j < nLon; j++) {
        const idx = i * nLon + j;
        pos.setY(idx, heights[idx] - minH);
        const t = (heights[idx] - minH) / Math.max(1, maxH - minH);
        // rust → tan → pale elevation ramp
        const r = 0.42 + t * 0.35, g = 0.23 + t * 0.28, b = 0.14 + t * 0.18;
        colors[idx * 3] = r; colors[idx * 3 + 1] = g; colors[idx * 3 + 2] = b;
      }
    }
    geo.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    geo.computeVertexNormals();
    const mat = new THREE.MeshLambertMaterial({ vertexColors: true, side: THREE.DoubleSide });
    const mesh = new THREE.Mesh(geo, mat);
    scene.add(mesh);

    const cam = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.5, 6000);
    const cx = 0, cz = 0;
    const centerY = terrainHeightAt(0, 0, patch.radius_m);
    cam.position.set(cx, centerY + eye, cz);
    Walk.cam = cam;
    Walk.yaw = 0; Walk.pitch = -0.05;
    Walk.eye = eye;
    Walk.centerElev = init.elev_m;

    Walk.renderer = renderer; Walk.scene = scene;
    Walk.lastT = performance.now();
    Walk.pos = { x: 0, z: 0 };
    Walk.active = true;
    $("walk").classList.remove("hidden");
    $("walk-hud-pos").textContent = `${fLat(init.lat)} ${fLon(init.lon)} · ${init.elev_m} m MOLA`;
    bindWalkInput();
    showWalkPOV(init);
    walkLoop();
  }

  function terrainHeightAt(dx, dz, radius) {
    const g = Walk.grid;
    const u = (dx + radius) / (2 * radius) * (g.nLon - 1);
    const v = (dz + radius) / (2 * radius) * (g.nLat - 1);
    const i0 = Math.max(0, Math.min(g.nLat - 1, Math.floor(v)));
    const j0 = Math.max(0, Math.min(g.nLon - 1, Math.floor(u)));
    const i1 = Math.min(g.nLat - 1, i0 + 1), j1 = Math.min(g.nLon - 1, j0 + 1);
    const fu = u - j0, fv = v - i0;
    const h = (a, b) => g.heights[a * g.nLon + b];
    return h(i0, j0) * (1 - fu) * (1 - fv) + h(i0, j1) * fu * (1 - fv)
         + h(i1, j0) * (1 - fu) * fv + h(i1, j1) * fu * fv
         - Math.min(...g.heights);
  }

  function bindWalkInput() {
    const canvas = $("walk-canvas");
    let dragging = false, lastX = 0, lastY = 0;
    if (!Walk.bound) {
      Walk.bound = true;
      document.addEventListener("keydown", (ev) => {
        Walk.keys[ev.key.toLowerCase()] = true;
        if (ev.key === "Escape" && Walk.active) exitWalk();
      });
      document.addEventListener("keyup", (ev) => { Walk.keys[ev.key.toLowerCase()] = false; });
      window.addEventListener("resize", () => {
        if (!Walk.active) return;
        Walk.renderer.setSize(window.innerWidth, window.innerHeight, false);
        Walk.cam.aspect = window.innerWidth / window.innerHeight;
        Walk.cam.updateProjectionMatrix();
        $("walk-canvas").width = window.innerWidth; $("walk-canvas").height = window.innerHeight;
      });
      $("walk-exit").onclick = exitWalk;
    }
    canvas.onpointerdown = (ev) => { dragging = true; lastX = ev.clientX; lastY = ev.clientY; canvas.setPointerCapture(ev.pointerId); };
    canvas.onpointerup = (ev) => { dragging = false; };
    canvas.onpointermove = (ev) => {
      if (!dragging) return;
      Walk.yaw -= (ev.clientX - lastX) * 0.005;
      Walk.pitch -= (ev.clientY - lastY) * 0.004;
      Walk.pitch = Math.max(-1.2, Math.min(0.9, Walk.pitch));
      lastX = ev.clientX; lastY = ev.clientY;
    };
    canvas.onwheel = (ev) => {
      ev.preventDefault();
      const step = -ev.deltaY * 0.4;
      moveWalk(step);
    };
  }

  function moveWalk(dist) {
    const p = Walk.pos;
    p.x += Math.sin(Walk.yaw) * dist;
    p.z += Math.cos(Walk.yaw) * dist;
    const R = Walk.grid ? (Walk.grid.nLon * Walk.grid.cell.lon) / 2 : 400;
    const lim = R - 8;
    p.x = Math.max(-lim, Math.min(lim, p.x));
    p.z = Math.max(-lim, Math.min(lim, p.z));
  }

  function walkLoop() {
    if (!Walk.active) return;
    Walk.raf = requestAnimationFrame(walkLoop);
    const now = performance.now();
    const dt = Math.min(0.1, (now - Walk.lastT) / 1000);
    Walk.lastT = now;
    const speed = (Walk.keys["shift"] ? 42 : 10) * dt;
    if (Walk.keys["w"] || Walk.keys["arrowup"]) moveWalk(speed);
    if (Walk.keys["s"] || Walk.keys["arrowdown"]) moveWalk(-speed);
    if (Walk.keys["q"]) Walk.yaw += 1.6 * dt;
    if (Walk.keys["e"]) Walk.yaw -= 1.6 * dt;
    const dirDeg = ((-Walk.yaw * 180 / Math.PI) % 360 + 360) % 360;
    if (Walk.keys["a"]) Walk.yaw += 0.8 * dt;
    if (Walk.keys["d"]) Walk.yaw -= 0.8 * dt;

    const eye = Walk.eye;
    const y = terrainHeightAt(Walk.pos.x, Walk.pos.z, Walk.radius || parseFloat($("walk-radius").value)) + eye;
    Walk.cam.position.set(Walk.pos.x, y, Walk.pos.z);
    Walk.cam.rotation.order = "YXZ";
    Walk.cam.rotation.y = Walk.yaw;
    Walk.cam.rotation.x = Walk.pitch;
    Walk.renderer.render(Walk.scene, Walk.cam);
    $("walk-hud-head").textContent = `heading ${dirDeg.toFixed(0)}° · eye ${eye.toFixed(2)} m · fov 75°`;
  }

  function exitWalk() {
    Walk.active = false;
    cancelAnimationFrame(Walk.raf);
    $("walk").classList.add("hidden");
    if (Walk.renderer) { Walk.renderer.dispose(); Walk.renderer = null; }
  }

  async function showWalkPOV(init) {
    const card = $("walk-pov-card");
    card.innerHTML = `<div class="pov-cap">Searching the POV library…</div>`;
    try {
      const r = await jget(`${API}/walk/pov?lat=${init.lat}&lon=${init.lon}`);
      if (!r.found) {
        card.innerHTML = `<div class="pov-cap"><b>No rover imagery nearby.</b> ${r.note || ""}</div>`;
        return;
      }
      const p = r.pov;
      card.innerHTML = `<img src="${p.thumb_url}" alt="Rover POV ${p.mission}" referrerpolicy="no-referrer"
        onerror="this.style.display='none'; this.nextElementSibling.insertAdjacentHTML('afterbegin','<i>(imagery preview unreachable from this network — source link stays valid)</i><br>')">
        <div class="pov-cap"><b>${p.mission} · ${p.instrument}</b> · sol ${p.sol} (${r.distance_km} km from footprint centre)<br>${p.caption}<br>
        <span class="mono">${p.credit}</span></div>`;
    } catch (e) {
      card.innerHTML = `<div class="pov-cap">POV lookup failed (${e.message})</div>`;
    }
  }

  // --------------------------------------------------------------- assistant
  const AI_CHIPS = [
    "Take me to Olympus Mons",
    "Show me all major landing sites",
    "Compare Jezero and Gale crater",
    "Find regions with evidence of ancient water",
    "Show me Perseverance's route",
    "Explain what I am looking at",
    "Find interesting geological formations near this location",
    "Show me the highest mountains on Mars",
    "Find shelter near Valles Marineris",
    "Assess radiation at Gale crater",
    "Simulate a MY34 dust storm",
    "Plan an evacuation route from Jezero to a shelter",
  ];
  let aiBusy = false;

  function bindAssistant() {
    const log = $("ai-log");
    for (const c of AI_CHIPS) {
      const b = document.createElement("button");
      b.textContent = c;
      b.onclick = () => { $("ai-text").value = c; sendChat(c); };
      $("ai-chips").appendChild(b);
    }
    $("ai-form").onsubmit = (ev) => {
      ev.preventDefault();
      const t = $("ai-text").value.trim();
      if (t) { sendChat(t); $("ai-text").value = ""; }
    };
    $("ai-text").addEventListener("keydown", (ev) => {
      if (ev.key === "Enter" && !ev.shiftKey) { ev.preventDefault(); $("ai-form").requestSubmit(); }
    });
    jget("/ai/status").then(s => {
      $("ai-engine-badge").textContent = s.engine || "local";
      $("ai-engine-badge").title = `model: ${s.model || "rule-based"} · configured: ${s.configured ? "remote LLM" : "local only"}`;
    }).catch(() => {});
    jget(`${API}/assistant/tools`).then(({ tools }) => {
      const row = $("ai-tools-row");
      const list = Array.isArray(tools) ? tools : (tools.tools || []);
      row.replaceChildren();
      for (const t of list.slice(0, 24)) {
        const name = typeof t === "string" ? t : t.name;
        const chip = document.createElement("span");
        chip.className = "chip";
        chip.textContent = name;
        chip.title = (t && t.description) || name;
        row.appendChild(chip);
      }
    }).catch(() => {});
  }

  function aiAddMsg(cls, text) {
    const div = document.createElement("div");
    div.className = `msg ${cls}`;
    div.innerHTML = `<p></p>`;
    if (text) div.querySelector("p").textContent = text;
    $("ai-log").appendChild(div);
    $("ai-log").scrollTop = $("ai-log").scrollHeight;
    return div;
  }
  function aiToolBadge(tool, args) {
    const div = document.createElement("div");
    div.className = "tool-badge";
    div.innerHTML = `<span>⚙ ${tool}</span><span class="targs"></span>`;
    div.querySelector(".targs").textContent = JSON.stringify(args || {}).slice(0, 120);
    $("ai-log").appendChild(div);
    $("ai-log").scrollTop = $("ai-log").scrollHeight;
  }
  function aiSources(sources) {
    if (!sources || !sources.length) return;
    const div = document.createElement("div");
    div.className = "src-list";
    div.innerHTML = `<b>Sources:</b>`;
    for (const s of sources.slice(0, 5)) {
      const a = document.createElement("a");
      a.href = typeof s === "string" ? s : (s.url || "#");
      a.textContent = typeof s === "string" ? s : (s.title || s.url || "");
      a.target = "_blank"; a.rel = "noopener";
      div.appendChild(a);
    }
    $("ai-log").appendChild(div);
  }

  async function sendChat(message) {
    if (aiBusy) return;
    aiBusy = true;
    aiAddMsg("user", message);
    const reply = aiAddMsg("ai", "");
    const p = reply.querySelector("p");
    if (p) p.classList.add("cursor-blink");
    let text = "";
    try {
      const resp = await fetch(`${API}/assistant/chat`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message, mission_id: currentMission ? currentMission.id : null }),
      });
      const reader = resp.body.getReader();
      const dec = new TextDecoder();
      let buf = "";
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        let idx;
        while ((idx = buf.indexOf("\n\n")) >= 0) {
          const line = buf.slice(0, idx); buf = buf.slice(idx + 2);
          if (!line.startsWith("data: ")) continue;
          let ev; try { ev = JSON.parse(line.slice(6)); } catch (e) { continue; }
          if (ev.type === "token") { text += ev.text; p.innerHTML = text; $("ai-log").scrollTop = $("ai-log").scrollHeight; }
          else if (ev.type === "tool_call") aiToolBadge(ev.tool, ev.args);
          else if (ev.type === "tool_result") { const b = $("ai-log").querySelectorAll(".tool-badge"); const last = b[b.length - 1]; if (last) last.title = JSON.stringify(ev.result_summary || {}); }
          else if (ev.type === "fly_to") flyTo(ev.lat, ev.lon, 300000);
          else if (ev.type === "sources") aiSources(ev.sources);
          else if (ev.type === "result") applyAssistantResult(ev.result);
          else if (ev.type === "done") break;
        }
      }
    } catch (e) {
      if (p) p.textContent = `Assistant error: ${e.message}`;
      else aiAddMsg("ai", `Assistant error: ${e.message}`);
    }
    if (p) p.classList.remove("cursor-blink");
    if (p && !text) p.textContent = "(no text response)";
    aiBusy = false;
  }

  // Turn a tool result into globe actions: layers, markers, flights, routes.
  function applyAssistantResult(result) {
    if (!result || typeof result !== "object") return;
    // layer activation
    if (result.layer_id && result.activated) {
      const id = result.layer_id;
      if (BASE_DEFS.some(d => d.id === id)) setBaseLayer(id);
      else { addOverlay(id); renderLayerPanel(); }
    }
    // fly hint
    if (result.lat != null && result.lon != null && result.fly) flyTo(result.lat, result.lon, 280000);
    // route (generate_route / optimize_route)
    if (result.waypoints && result.waypoints.length) {
      drawRoutePolyline("ai-route", result.waypoints, "#3ec9dc");
      if (result.stats) showProfile(result.waypoints.map(w => w.elev_m ?? 0), "Assistant route profile");
    }
    // mission site listing
    if (result.sites && result.sites.length) { setEntityOverlay("sites", true); renderLayerPanel(); }
    if (result.targets && result.targets.length) { setEntityOverlay("targets", true); renderLayerPanel(); }
    // water / shelter candidates → markers
    const cands = result.candidates || result.water_candidates || result.shelters || result.water;
    if (Array.isArray(cands) && cands.length) {
      const ds = getDS("ai-candidates");
      if (!viewer.dataSources.contains(ds)) viewer.dataSources.add(ds);
      ds.entities.removeAll(); ds.show = true;
      for (const c of cands.slice(0, 30)) {
        ds.entities.add({
          position: C.Cartesian3.fromDegrees(c.lon, c.lat, 1200, MARS),
          point: { pixelSize: 10, color: C.Color.fromCssColorString("#3ec9dc"), outlineColor: C.Color.WHITE, outlineWidth: 1 },
          label: { text: c.name || c.id || "candidate", font: "11px 'Segoe UI'", fillColor: C.Color.WHITE, outlineColor: C.Color.BLACK, outlineWidth: 2, pixelOffset: new C.Cartesian2(0, -14), disableDepthTestDistance: Number.POSITIVE_INFINITY },
          properties: { kind: "water", data: c },
        });
      }
    }
    // storm sim → refresh storm overlay + toast
    if (result.event || result.simulated) refreshEntitySet("storms");
  }

  // ------------------------------------------------------------- websocket
  function bindWebSockets() {
    const proto = location.protocol === "https:" ? "wss" : "ws";
    let evWs;
    try {
      evWs = new WebSocket(`${proto}://${location.host}/ws/events`);
      evWs.onopen = () => connState("live", "Realtime events connected");
      evWs.onmessage = (m) => {
        let ev; try { ev = JSON.parse(m.data); } catch (e) { return; }
        if (ev.type === "storm.alert") {
          const e = ev.event || ev;
          toast(`Storm alert [SIM] — ${e.kind === "sep" ? "Solar particle event" : "Dust storm"}`,
            `severity ${e.severity || "?"} · ${e.center ? `${fLat(e.center.lat)} ${fLon(e.center.lon)}` : ""}`,
            e.severity === "global" || e.severity === "x" ? "bad" : "warn", 9000);
          refreshEntitySet("storms");
        } else if (ev.type === "presence.update" && entitySets.get("presence") && entitySets.get("presence").show) {
          updatePresenceEntities(ev.agents);
        } else if (ev.type === "telemetry.tick") {
          if (entitySets.get("presence") && entitySets.get("presence").show && ev.agents) updatePresenceEntities(ev.agents);
        } else if (ev.type === "mission.plan_changed") {
          refreshMissions();
        }
      };
      evWs.onerror = () => connState("error", "Events socket error");
      evWs.onclose = () => connState("live", "Events socket closed (REST still active)");
    } catch (e) { console.warn("ws events failed", e); }
    try {
      const pWs = new WebSocket(`${proto}://${location.host}/ws/presence`);
      pWs.onmessage = (m) => {
        let ev; try { ev = JSON.parse(m.data); } catch (e) { return; }
        if (ev.type === "presence.update" && entitySets.get("presence") && entitySets.get("presence").show) updatePresenceEntities(ev.agents);
      };
    } catch (e) { console.warn("ws presence failed", e); }
  }
  function updatePresenceEntities(agents) {
    const ds = entitySets.get("presence");
    if (!ds || !ds.show || !agents) return;
    ds.entities.removeAll();
    for (const a of agents) {
      const col = a.kind === "habitat" ? "#3fd68f" : a.kind === "rover" ? "#ffb02e" : "#ffd54f";
      ds.entities.add({
        position: C.Cartesian3.fromDegrees(a.lon, a.lat, 1500, MARS),
        point: { pixelSize: 12, color: C.Color.fromCssColorString(col), outlineColor: C.Color.BLACK, outlineWidth: 1.5 },
        label: { text: a.name, font: "11px 'Segoe UI'", fillColor: C.Color.WHITE, outlineColor: C.Color.BLACK, outlineWidth: 2, pixelOffset: new C.Cartesian2(0, -16), disableDepthTestDistance: Number.POSITIVE_INFINITY },
      });
    }
  }

  // ------------------------------------------------------------- view panel
  function bindViewPanel() {
    $("proj-seg").querySelectorAll(".seg-btn").forEach(b => {
      b.onclick = () => {
        $("proj-seg").querySelectorAll(".seg-btn").forEach(x => x.classList.remove("active"));
        b.classList.add("active");
        const p = b.dataset.proj;
        if (p === "3d") viewer.scene.morphTo3D(1.4);
        else if (p === "2d") viewer.scene.morphTo2D(1.4);
        else if (p === "cv") viewer.scene.morphToColumbusView(1.4);
        else if (p === "north") { viewer.scene.morphTo3D(0); flyTo(84, 0, 2600000); }
        else if (p === "south") { viewer.scene.morphTo3D(0); flyTo(-84, 0, 2600000); }
      };
    });
    $("exag").oninput = () => setExaggeration(parseFloat($("exag").value));
    $("lighting").onchange = () => { viewer.scene.globe.enableLighting = $("lighting").checked; };
    $("atmo").onchange = () => {
      viewer.scene.globe.showGroundAtmosphere = $("atmo").checked;
      if (viewer.scene.skyAtmosphere) viewer.scene.skyAtmosphere.show = $("atmo").checked;
    };
    $("grid-toggle").onchange = () => {
      const on = $("grid-toggle").checked;
      const ds = getDS("grid");
      if (on && !ds.entities.length) {
        // graticule: meridians + parallels
        for (let lon = -180; lon < 180; lon += 20) {
          const pts = [];
          for (let lat = -90; lat <= 90; lat += 5) pts.push(C.Cartesian3.fromDegrees(lon, lat, 2000, MARS));
          ds.entities.add({ polyline: { positions: pts, width: 1, material: C.Color.fromCssColorString("#4da3ff55") } });
        }
        for (let lat = -80; lat <= 80; lat += 20) {
          const pts = [];
          for (let lon = -180; lon <= 180; lon += 5) pts.push(C.Cartesian3.fromDegrees(lon, lat, 2000, MARS));
          ds.entities.add({ polyline: { positions: pts, width: 1, material: C.Color.fromCssColorString("#4da3ff55") } });
        }
      }
      ds.show = on;
    };
    $("storm-sim").onclick = async () => {
      const sev = $("storm-severity").value;
      const c = selected || viewCenter();
      try {
        const r = await jpost(`${API}/env/storms/simulate?kind=${sev.includes("SEP") || sev === "m" || sev === "x" || sev === "m-class" ? "sep" : "dust"}&lat=${c.lat.toFixed(3)}&lon=${c.lon.toFixed(3)}&severity=${sev}`);
        toast("Storm simulated [SIM]", `${r.event.id} · ${r.event.severity} · broadcast: ${r.alert_broadcast}`, "warn", 8000);
        renderStormList();
        refreshEntitySet("storms");
      } catch (e) { toast("Simulation failed", e.message, "bad"); }
    };
    renderStormList();
  }

  async function renderStormList() {
    try {
      const { events } = await jget(`${API}/env/storms`);
      const list = $("storm-list");
      list.replaceChildren();
      for (const e of events.slice(-8).reverse()) {
        const item = document.createElement("div");
        item.className = "rl-item";
        item.innerHTML = `<span class="rl-main"><span class="rl-name">${e.kind === "sep" ? "SEP" : "Dust"} · ${e.severity}</span>
          <span class="rl-sub">${e.id} · ${e.status || ""}</span></span>
          <span class="rl-act"><button class="mini-btn">plan</button></span>`;
        item.querySelector(".mini-btn").onclick = () => sendChat(`Plan a storm response for event ${e.id}`);
        list.appendChild(item);
      }
    } catch (e) { /* ignore */ }
  }

  // ------------------------------------------------------------ panel manager
  function openPanel(name) {
    document.querySelectorAll(".panel").forEach(p => p.classList.add("hidden"));
    document.querySelectorAll(".rail-btn[data-panel]").forEach(b => b.classList.remove("active"));
    const p = $(`panel-${name}`);
    if (p) p.classList.remove("hidden");
    const btn = $(`rail-${name}`);
    if (btn) btn.classList.add("active");
    if (name === "ai") { $("ai-text").focus(); }
    if (name === "layers") renderLayerPanel();
  }
  function closePanels() {
    document.querySelectorAll(".panel").forEach(p => p.classList.add("hidden"));
    document.querySelectorAll(".rail-btn[data-panel]").forEach(b => b.classList.remove("active"));
  }
  function bindPanels() {
    document.querySelectorAll(".rail-btn[data-panel]").forEach(b => {
      b.onclick = () => {
        const p = $(`panel-${b.dataset.panel}`);
        const isOpen = !p.classList.contains("hidden");
        closePanels();
        if (!isOpen) openPanel(b.dataset.panel);
      };
    });
    document.querySelectorAll(".rail-btn[data-action]").forEach(b => {
      b.onclick = () => {
        if (b.dataset.action === "home") {
          viewer.camera.flyTo({
            destination: C.Cartesian3.fromDegrees(18, 14, 7400000, MARS),
            orientation: { heading: C.Math.toRadians(-12), pitch: C.Math.toRadians(-82), roll: 0 }, duration: 1.6,
          });
        }
      };
    });
    document.querySelectorAll(".panel [data-close]").forEach(b => b.onclick = closePanels);
    document.addEventListener("keydown", (ev) => {
      if (ev.key === "Escape") { closePanels(); if (nodePlaceMode) cancelNodePlace(); }
    });
    $("zoom-in").onclick = () => viewer.camera.zoomIn(camHeightM() * 0.35);
    $("zoom-out").onclick = () => viewer.camera.zoomOut(camHeightM() * 0.45);
    $("proj-toggle").onclick = () => {
      const mode = viewer.scene.mode;
      if (mode === C.SceneMode.SCENE3D) { viewer.scene.morphTo2D(1.2); }
      else { viewer.scene.morphTo3D(1.2); }
    };
    $("compare-enable").onchange = () => setCompare($("compare-enable").checked);
    $("compare-layer").onchange = () => { if (compareOn) setCompare(true); };
    const div = $("compare-divider");
    let draggingDiv = false;
    div.addEventListener("pointerdown", (ev) => { draggingDiv = true; try { div.setPointerCapture(ev.pointerId); } catch (e) { /* synthetic or stale pointer */ } });
    div.addEventListener("pointermove", (ev) => {
      if (!draggingDiv) return;
      const x = Math.min(window.innerWidth - 20, Math.max(20, ev.clientX));
      div.style.left = x + "px";
      viewer.scene.splitPosition = x / window.innerWidth;
    });
    div.addEventListener("pointerup", () => { draggingDiv = false; });
    $("measure-close").onclick = () => setMeasureMode(false);
    $("measure-clear").onclick = clearMeasure;
    $("measure-undo").onclick = () => { measurePts.pop(); clearMeasureKeep(); measurePts.forEach(p => addMeasurePointQuiet(p)); };
    $("rail-measure").onclick = () => setMeasureMode(!measureMode);
    $("walk-start-btn").onclick = () => {
      const c = selected || viewCenter();
      startWalk(c.lat, c.lon);
    };
    $("walk-radius").oninput = () => { $("walk-radius-val").textContent = $("walk-radius").value + " m"; };
    $("walk-eye").oninput = () => { $("walk-eye-val").textContent = parseFloat($("walk-eye").value).toFixed(2) + " m"; };
  }
  function clearMeasureKeep() {
    const ds = entitySets.get("measure");
    if (ds) ds.entities.removeAll();
  }
  function addMeasurePointQuiet(p) { const m = measureMode; measureMode = true; addMeasurePoint(p.lat, p.lon); measureMode = m; }

  // ------------------------------------------------------------------- boot
  async function boot() {
    C = window.Cesium;
    if (!C) { connState("error", "Cesium failed to load — check CDN access"); return; }
    connState("live", "Cesium loaded");
    try {
      const hm = await jget("/globe/heightmap");
      const gl = await jget("/globe/layers");
      terrainData = hm;
      const w = hm.w, h = hm.h;
      let minE = Infinity, maxE = -Infinity;
      for (const v of hm.data) { if (v < minE) minE = v; if (v > maxE) maxE = v; }
      rasterData = { w, h, minE, maxE, elev: hm.data, slope: gl.slope, rough: gl.rough, hazard: gl.hazard };
      const canvases = {};
      for (const k of ["elev", "slope", "rough", "hazard"]) {
        const cv = document.createElement("canvas");
        cv.width = w; cv.height = h;
        paintRaster(cv, w, h, rasterColorizer(k));
        canvases[k] = cv.toDataURL("image/png");
      }
      heightmapImg = canvases;
    } catch (e) {
      console.warn("generated layers unavailable:", e);
    }
    try {
      const lr = await jget(`${API}/layers`);
      LAYER_REGISTRY = lr.layers || [];
    } catch (e) { LAYER_REGISTRY = []; }
    createViewer();
    // Default to the generated MOLA layer — it always renders (offline-safe,
    // painted from the embedded MEGDR). Live Viking/OPM tiles are one click
    // away in the layers panel; on networks that blackhole tile hosts the
    // globe must never be stuck blank.
    setBaseLayer("mola-color-gen");
    bindSearch(); bindPanels(); bindMissions(); bindNodes(); bindPlaces(); bindAssistant(); bindViewPanel(); bindWebSockets();
    setEntityOverlay("sites", true);
    renderLayerPanel();
    $("map-loading").classList.add("hidden");
    // hide loading overlay after first basemap tile probe
    setTimeout(() => $("map-loading").classList.add("hidden"), 2500);
    // debug/verification handle (used by the automated smoke checks too)
    window.NAM = { viewer, flyTo, selectPoint, setBaseLayer, setExaggeration,
                   startWalk, sendChat, openPanel, addMeasurePoint, setMeasureMode,
                   planQuickRoute, viewCenter, version: "unified-1.0" };
    const { features } = await jget(`${API}/gazetteer`).catch(() => ({ features: [] }));
    $("about-body").innerHTML = `
      <p class="note">NAM — Navigation Assistant of Mars. One minimalist field atlas combining the best of four packages: the nam-backend contract (REST + WebSocket), the mars3d terrain engine (C++ cruncher + MOLA rasters), the marswalk trained place-matcher and its field-atlas UI language, and the flagship globe experience.</p>
      <div class="facts">
        <div class="fact"><div class="fv">${(features || []).length}</div><div class="fk">gazetteer features</div></div>
        <div class="fact"><div class="fv">24</div><div class="fk">assistant tools</div></div>
        <div class="fact"><div class="fv">13</div><div class="fk">mission sites</div></div>
        <div class="fact"><div class="fv">16</div><div class="fk">spectral targets</div></div>
      </div>
      <p class="note">Data: MOLA MEGDR (NASA PDS), Viking MDIM 2.1 (NASA/JPL/USGS), OpenPlanetaryMap tiles (proxied + cached by the backend). Simulated values (storms, presence, dose estimates) are labelled [SIM]/[est]. Legacy views: <a href="/NAM.html" style="color:var(--acc2)">flagship NAM.html</a> · <a href="/marswalk/" style="color:var(--acc2)">marswalk</a> · <a href="/three" style="color:var(--acc2)">mars3d</a> · <a href="/docs" style="color:var(--acc2)">API docs</a>.</p>`;
  }

  document.addEventListener("DOMContentLoaded", boot);
})();
