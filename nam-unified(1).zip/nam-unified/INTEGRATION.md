# INTEGRATION — architecture and decision record

This document records exactly how the four packages were merged, what was
changed (and what deliberately was not), and why. It complements README.md.

## 1. Starting position (from the four analyses)

| Package | Kind | Backend calls it makes | Key constraint |
|---|---|---|---|
| `NAM.html` | 5.3 MB self-contained Cesium 1.132 app (embedded MOLA PNG b64, MDIM JPEG, catalogs, own 16-tool assistant) | **zero** — no fetch/XHR/WS at all | must be served **byte-identical**; its 5.09 MB `NAM.B64` line is parsed by JS string offsets |
| `mars3d` | FastAPI middle-end + C++ cruncher + hybrid AI + training pipeline | its own `frontend/index.html` (Three.js) calls `/globe/*`, `/terrain/*`, `/ai/ask` | already served NAM.html verbatim via `FileResponse` |
| `nam-backend` | FastAPI v2 with the richest REST+WS contract (openapi at `/api/v1`) | separate reference-ui | in-memory state; storm publisher dead code; CORS `*`+credentials invalid |
| `marswalk` | globe UI + trained matcher backend | its `app.js` gets **one serve-time patch** injecting `fetch("/search?q=…")` | refuses to boot if its frontend files' md5 changes |

Key insight from the NAM.html analysis: **the flagship frontend needs exactly
one thing from the backend — static byte-identical serving.** Every API below
therefore serves *other* clients (the marswalk UI, the Three.js viewer, curl,
and future work) while remaining one origin so the same server hosts
everything.

## 2. Composition strategy: compose, don't rewrite

The nam-backend tree was kept as the base (`app/` package). The mars3d engine
modules and the marswalk matcher were copied in as additional packages and
**adapted with minimal diffs**:

| Adapted file | Change |
|---|---|
| `app/intel/datasets.py` | data path `../data` → `../data/raw` (unified layout) |
| `app/intel/hybrid_ai.py` | same one-line path fix |
| `app/intel/cruncher.py` | none (loads `libterrain.so` from its own dir) |
| `app/match/matcher.py` | none (loads its pickle from `match/model/`) |
| `app/core/assistant.py` | added ML-first routing + alias bridge + matcher fallback in `_find_feature`; regex router untouched |
| `app/api/routes.py` | storm-alert wiring; new root-level router with mars3d + matcher endpoints; `/api/v1` contract unchanged |
| `app/main.py` | rewritten entrypoint: unified identity, byte-identity checks, marswalk serve-time patch, CORS fix, merged `/health` |
| `app/data/raw/` | nam-backend's three data files + mars3d's `mola_elev.npy`, `mola_elev_360x180.npy`, `gazetteer.json`, `nam_model.json` (both elevation grids are the same MOLA MEGDR 4 ppd product — int32 `.bin` for nam-backend's bilinear sampler, int16 `.npy` for the C++ cruncher) |
| `frontend/` | `NAM.html` (byte-identical), `reference-ui/`, `three.html` (mars3d legacy viewer), `marswalk/` (original 4 files, md5-checked), **`unified/` (new default UI — see §7)** |

Nothing in the original contracts was renamed, re-shaped, or re-versioned:
`/api/v1/*` answers exactly what nam-backend answered (plus the storm-fix
field), the mars3d endpoints answer exactly what mars3d answered, `/search`
answers exactly what marswalk answered — with clearly-marked additive
enrichment (`elev_m`, `pressure_mbar`, `lon_180`, `engine`).

## 3. The assistant pipeline (after integration)

```
user text
  │
  ├─ 1. regex intents (nam-backend, unchanged, first-match-wins)
  │      action verbs → tool + extracted args (coords, features, from/to)
  │
  ├─ 2. ML intent classifier (mars3d nam-nlp-1.0, 9 languages)   [regex missed]
  │      conf ≥ 0.55 → map via intel/intents.json → tool
  │      ├─ location tools → coords | gazetteer | matcher | 9-language
  │      │   alias bridge (nam_model.json entities) → matcher
  │      ├─ generate_route → from/to extraction (matcher-tolerant)
  │      ├─ navigate/search → matcher fly-to (conf-correct, lon→east-positive)
  │      └─ informational intents → hybrid retrieval-grounded answer
  │
  └─ 3. deterministic fallback help text (unchanged)
```

Every path returns the same `{tool, args}` / `{tool: null, text, fly_to, src}`
shape, so the SSE chat contract (`role → token → tool_call → tool_result →
result → sources → done`) is untouched.

## 4. Byte-identity guarantees

- `NAM.html`: served via `FileResponse` (raw bytes). Boot-time md5 check
  against the contract value; `/health` exposes
  `components.nam_html_byte_identical`. Never templated, never minified.
- marswalk frontend: original files md5-checked at boot against the values
  from its own server; the **only** difference is the in-memory app.js patch
  (async searchLocation + matcher fetch), identical to the patch marswalk's
  own server applied. `MARSWALK_PURE=1` serves the untouched original.

## 5. Deliberate non-merges (recorded honestly)

- **One elevation grid per engine.** nam-backend's `geo.py` bilinear sampler
  keeps its int32 `elev.bin`; the C++ cruncher keeps its int16 `.npy`. They
  are the same MOLA product; forcing one format through both codepaths would
  have meant rewriting verified numeric code for zero behavioural gain.
- **marswalk's straight-line "route" tool was not merged.** Its README itself
  warns it is distance sketching, not terrain-aware routing; the platform has
  two real A* planners (`/api/v1/route` presets, `/route/plan` weights).
- **`/ai/ask` does not execute tools.** mars3d's contract classifies + grounds
  only; tool *execution* stays in the assistant chat where the confirmation
  semantics live.
- **No persistence was added** to nodes/plans — in-memory state is the source
  packages' documented behaviour; changing it silently would break the
  contract.

## 6. Test evidence (50 tests, all passing)

- 15 legacy smoke tests (nam-backend's own suite, still green against the
  unified app).
- 35 unified tests covering: byte-identity over HTTP shapes, the six-layer
  registry, catalogs (13/8/16/13 counts), MOLA spot checks (Olympus ≈ +21 km,
  Hellas < −4000 m), hazard bands, shelters/water/radiation, storms simulate +
  broadcast, preset A*, nodes/plans lifecycle, Walk View (7 POV entries),
  tool catalogue ≥ 24, SSE chat (regex + ML + multilingual), the eight
  flagship assistant phrases, C++ terrain sample/tile/route/landing, globe
  layers (64800 cells), matcher typo/paraphrase/anti-hallucination, WS
  hello/tick/presence/storm.alert, mission-route persistence + KML export,
  global (stride-adaptive) A* routing.

## 7. The unified frontend (v3 — "compose the best parts")

The user's directive for v3: nothing is sacred — build ONE minimalist app
from the best parts of all four frontends. What was taken from where:

| Part | Taken from | How it ships |
|---|---|---|
| Field-atlas chrome (panels, icon rail, tooltips, status/readout) | **marswalk** | re-authored in `unified/style.css` in marswalk's design language |
| Globe recipe (custom Mars ellipsoid `Globe`, star skybox, trackpad pinch, tile fallback ladder, lighting) | **marswalk** | `unified/app.js` `createViewer()` + `createStarSkyBox()` + `installTrackpadPinchZoom()` |
| Cesium 1.132 CDN pin | **NAM.html** | same jsDelivr URL, so the two apps share the browser cache |
| MOLA relief terrain | **mars3d** `/globe/heightmap` | a real `HeightmapTerrainData` provider (65×65 samples, level ≤ 6) → vertical exaggeration + camera collision work |
| Generated imagery layers (elevation/slope/roughness/hazard) | **mars3d** `/globe/layers` | painted client-side to canvases → `SingleTileImageryProvider`; offline-guaranteed (the default base layer) |
| Live imagery (Viking MDIM 2.1, MOLA hillshade) | **marswalk** Trek WMTS + fallback | optional base layers; OPM layers go through the backend's cached tile proxy |
| Search UX | **marswalk matcher** (`/search`) | typo/paraphrase results + gazetteer fallback + `lat, lon` parsing |
| Walk View | **nam-backend** `/api/v1/walk/*` | Three.js terrain mesh from the patch heights, WASD/drag controls, eye-height + radius sliders, rover POV card from the 7-entry library |
| Assistant UI | **nam-backend** SSE contract | streaming panel with tool badges, sources, quick chips, and globe actions (`fly_to`, layer activation, candidate markers) |
| Missions / nodes / measure | **nam-backend** REST | mission CRUD → waypoints → 3-preset A* → stats → profile chart → KML; node types waypoint/cache/shelter/water/hazard/poi/person/area; click-measure with surface distance + elevation profile |
| Realtime | **nam-backend** WS | `/ws/events` storm alerts → toasts; `/ws/presence` 1 Hz agent updates → map markers |

Bugs found and fixed while click-testing in a headless browser:
1. Relative asset URLs break when the app is served at `/` → absolute
   `/unified/*` paths.
2. Cesium ≥1.131 moved `TerrainProvider.getLevelMaximumGeometricError` →
   computed fallback with a runtime feature check.
3. Tile hosts that *hang* (not fail) keep root imagery tiles pending forever
   → the default base layer is now the offline generated MOLA imagery; live
   layers stay one click away.
4. Cesium's `camera.positionCartographic` silently uses WGS84 → on Mars the
   readout height was ~2,600 km underground; all camera height math now
   converts through the Mars ellipsoid explicitly.
5. Empty assistant replies died silently (missing `<p>` in the message node)
   → always create the paragraph node; `aiBusy` can no longer wedge.
6. Mission detail re-render orphaned per-node click handlers → delegated
   event handling on the detail container.

One backend addition serves the UI: `POST /api/v1/plans/{id}/route`
(persists a computed route on a mission; additive, contract-preserving) and
`mission.plan_changed` broadcasts. The deterministic assistant's regex table
gained six trained patterns (sites list, site comparison, highest mountains,
rover traverses, ancient water) that run BEFORE the generic route verb so
"Show me Perseverance's route" is not misrouted to `generate_route`.
