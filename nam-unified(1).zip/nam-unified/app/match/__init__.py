"""marswalk trained place matcher (integrated module)."""
