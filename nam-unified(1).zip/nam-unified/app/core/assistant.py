"""Deterministic assistant — 16 v1 tools + 8 new tools.

This is the deterministic intent router + tool dispatcher ported from
NAM.ASSISTANT in v1. It does NOT call an LLM — the response is rule-based.
The chat endpoint (/api/v1/assistant/chat) wraps this with an OpenAI-compatible
SSE shape so a real LLM can be dropped in later without breaking the UI.

Tool list (matches v1 verbatim, plus 8 new):
  v1 (16): search_planetary_location, get_current_map_context,
    search_nasa_datasets, get_location_observations, activate_map_layer,
    compare_geological_layers, get_elevation_profile, analyze_terrain,
    identify_hazards, find_scientific_targets, create_mission,
    generate_route, optimize_route, add_waypoint, explain_route, export_mission
  new (8): add_node, add_stop, plan_area, plan_storm_response,
    find_water, find_shelter, assess_radiation, simulate_storm
"""
from __future__ import annotations
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from ..data import load_json_data, normalize_lat, normalize_lon
from .geo import (
    sample_elevation, slope_at, sample_roughness, hazard_at,
    elevation_profile, terrain_analyze,
)
from .router import plan_route, PRESETS
from .environment import find_shelters, find_water, assess_radiation, assess_radiation_along_path
from .walk import walk_init, walk_pov_lookup


# ---------------------------------------------------------------------------
# Tool registry — name -> (description, schema, handler)
# ---------------------------------------------------------------------------

@dataclass
class ToolDef:
    name: str
    description: str
    input_schema: dict
    output_schema: dict
    handler: Callable[[dict], dict]


_REGISTRY: dict[str, ToolDef] = {}


def register_tool(name: str, description: str, input_schema: dict, output_schema: dict):
    def deco(fn: Callable[[dict], dict]) -> Callable[[dict], dict]:
        _REGISTRY[name] = ToolDef(name, description, input_schema, output_schema, fn)
        return fn
    return deco


def list_tools() -> list[dict]:
    return [
        {"name": t.name, "description": t.description,
         "input_schema": t.input_schema, "output_schema": t.output_schema}
        for t in _REGISTRY.values()
    ]


def invoke_tool(name: str, args: dict) -> dict:
    if name not in _REGISTRY:
        return {"error": f"unknown tool: {name}", "available": list(_REGISTRY.keys())}
    try:
        return _REGISTRY[name].handler(args or {})
    except Exception as e:
        return {"error": str(e), "tool": name, "args": args}


# ---------------------------------------------------------------------------
# v1 tools (16)
# ---------------------------------------------------------------------------

@register_tool(
    "search_planetary_location",
    "Search the IAU Mars gazetteer (102 features) by name or type.",
    {"query": "str", "limit": "int, default 10"},
    {"results": "list of {id,name,type,lat,lon,desc,tags}"},
)
def t_search_planetary_location(args):
    q = (args.get("query") or "").strip().lower()
    limit = int(args.get("limit", 10))
    feats = load_json_data()["FEATURES"]
    if not q:
        return {"results": feats[:limit]}
    matches = [f for f in feats
               if q in f.get("name", "").lower()
               or q in f.get("id", "").lower()
               or q in " ".join(f.get("tags", [])).lower()
               or q in f.get("type", "").lower()]
    return {"results": matches[:limit], "count": len(matches)}


@register_tool(
    "get_current_map_context",
    "Summarize what's near a (lat, lon) on Mars: gazetteer features, mission sites, terrain.",
    {"lat": "float", "lon": "float", "radius_km": "float, default 500"},
    {"lat": "float", "lon": "float", "features": "list", "sites": "list", "terrain": "dict"},
)
def t_get_current_map_context(args):
    import math
    lat = float(args["lat"]); lon = float(args["lon"])
    radius = float(args.get("radius_km", 500))
    R = 3389500.0
    feats = load_json_data()["FEATURES"]
    sites = load_json_data()["SITES"]
    def haversine(a_lat, a_lon, b_lat, b_lon):
        dlat = math.radians(b_lat - a_lat)
        dlon = math.radians(b_lon - a_lon)
        x = math.sin(dlat/2)**2 + math.cos(math.radians(a_lat))*math.cos(math.radians(b_lat))*math.sin(dlon/2)**2
        return R * 2 * math.atan2(math.sqrt(x), math.sqrt(1-x)) / 1000.0
    nearby_feats = sorted(
        [{"id": f["id"], "name": f["name"], "type": f["type"],
          "lat": f["lat"], "lon": f["lon"],
          "distance_km": round(haversine(lat, lon, f["lat"], f["lon"]), 1)}
         for f in feats],
        key=lambda x: x["distance_km"]
    )[:5]
    nearby_sites = sorted(
        [{"id": s["id"], "name": s["name"], "agency": s["agency"], "kind": s["kind"],
          "lat": s["lat"], "lon": s["lon"], "date": s["date"],
          "distance_km": round(haversine(lat, lon, s["lat"], s["lon"]), 1)}
         for s in sites],
        key=lambda x: x["distance_km"]
    )[:3]
    elev = sample_elevation(lat, lon)
    slope = slope_at(lat, lon)
    return {
        "lat": round(lat, 5), "lon": round(lon, 5),
        "radius_km": radius,
        "elev_m": round(elev, 1),
        "slope_deg": (None if slope is None else round(slope, 2)),
        "features_nearby": nearby_feats,
        "mission_sites_nearby": nearby_sites,
    }


@register_tool(
    "search_nasa_datasets",
    "Search the curated catalog of NASA/USGS Mars datasets + instruments.",
    {"query": "str"},
    {"instruments": "list", "registry": "list", "orbiters": "list"},
)
def t_search_nasa_datasets(args):
    q = (args.get("query") or "").strip().lower()
    d = load_json_data()
    def match(item):
        if not q: return True
        text = json.dumps(item, default=str).lower()
        return q in text
    return {
        "instruments": [i for i in d["INSTRUMENTS"] if match(i)],
        "orbiters": [o for o in d["ORBITERS"] if match(o)],
        "registry": [r for r in d["REGISTRY"] if match(r)],
    }


@register_tool(
    "get_location_observations",
    "Get available observations (instruments, datasets) for a (lat, lon).",
    {"lat": "float", "lon": "float"},
    {"elev_m": "float", "instruments_with_coverage": "list", "layers": "list"},
)
def t_get_location_observations(args):
    lat = float(args["lat"]); lon = float(args["lon"])
    d = load_json_data()
    elev = sample_elevation(lat, lon)
    return {
        "lat": round(lat, 5), "lon": round(lon, 5),
        "elev_m": round(elev, 1),
        "instruments_with_coverage": d["INSTRUMENTS"][:5],
        "layers": d["LAYERS"],
    }


@register_tool(
    "activate_map_layer",
    "Get the URL template for a specific layer in the registry.",
    {"layer_id": "str"},
    {"layer": "dict"},
)
def t_activate_map_layer(args):
    layer_id = args.get("layer_id")
    d = load_json_data()
    for l in d["LAYERS"]:
        if l["id"] == layer_id:
            return {"layer": l, "activated": True}
    return {"error": f"unknown layer: {layer_id}", "available": [l["id"] for l in d["LAYERS"]]}


@register_tool(
    "compare_geological_layers",
    "Compare available map layers by coverage, resolution, source.",
    {},
    {"comparison": "list of layer dicts"},
)
def t_compare_geological_layers(args):
    d = load_json_data()
    return {
        "comparison": [
            {"id": l["id"], "name": l["name"], "kind": l["kind"],
             "coverage": l.get("coverage"), "resolution": l.get("resolution"),
             "credit": l.get("credit")}
            for l in d["LAYERS"]
        ]
    }


@register_tool(
    "get_elevation_profile",
    "Trace an elevation profile along a path of (lat, lon) points.",
    {"points": "list of [lat, lon]"},
    {"profile": "list of {lat, lon, elev_m, slope_deg, pressure_mbar}"},
)
def t_get_elevation_profile(args):
    pts = [(float(p[0]), float(p[1])) for p in args["points"]]
    return {"profile": elevation_profile(pts), "count": len(pts)}


@register_tool(
    "analyze_terrain",
    "Compute a local terrain grid (elevation, slope, hazard) around a point.",
    {"lat": "float", "lon": "float", "radius_km": "float, default 50", "resolution_deg": "float, optional"},
    {"grid": "dict"},
)
def t_analyze_terrain(args):
    lat = float(args["lat"]); lon = float(args["lon"])
    radius = float(args.get("radius_km", 50))
    res = args.get("resolution_deg")
    if res is not None: res = float(res)
    return terrain_analyze(lat, lon, radius, res)


@register_tool(
    "identify_hazards",
    "Composite hazard readout (slope + roughness + elevation) at a point.",
    {"lat": "float", "lon": "float"},
    {"hazard": "HazardReadout"},
)
def t_identify_hazards(args):
    h = hazard_at(float(args["lat"]), float(args["lon"]))
    return {
        "lat": h.lat, "lon": h.lon, "elev_m": h.elev_m,
        "slope_deg": h.slope_deg, "roughness_m": h.roughness_m,
        "pressure_mbar": h.pressure_mbar,
        "hazard_class": h.hazard_class, "hazard_score": h.hazard_score,
        "notes": h.notes, "provenance": h.provenance,
    }


@register_tool(
    "find_scientific_targets",
    "Find curated literature-cited spectral/science targets near a (lat, lon).",
    {"lat": "float", "lon": "float", "max_radius_km": "float, default 1000"},
    {"targets": "list"},
)
def t_find_scientific_targets(args):
    import math
    lat = float(args["lat"]); lon = float(args["lon"])
    max_r = float(args.get("max_radius_km", 1000))
    R = 3389500.0
    def haversine(a_lat, a_lon, b_lat, b_lon):
        dlat = math.radians(b_lat - a_lat); dlon = math.radians(b_lon - a_lon)
        x = math.sin(dlat/2)**2 + math.cos(math.radians(a_lat))*math.cos(math.radians(b_lat))*math.sin(dlon/2)**2
        return R * 2 * math.atan2(math.sqrt(x), math.sqrt(1-x)) / 1000.0
    d = load_json_data()
    res = []
    for t in d["TARGETS"]:
        dist = haversine(lat, lon, t["lat"], t["lon"])
        if dist <= max_r:
            res.append({**t, "distance_km": round(dist, 1)})
    res.sort(key=lambda x: x["distance_km"])
    return {"query": {"lat": lat, "lon": lon, "max_radius_km": max_r},
            "count": len(res), "targets": res}


@register_tool(
    "create_mission",
    "Create a new mission in the plans store (server-side state).",
    {"name": "str", "objective": "str", "kind": "str (route|area|evacuation|survey)"},
    {"mission_id": "str", "name": "str"},
)
def t_create_mission(args):
    from .state import create_mission as _cm
    m = _cm(args.get("name", "Untitled"), args.get("objective", ""), args.get("kind", "route"))
    return {"mission_id": m["id"], "name": m["name"], "kind": m["kind"]}


@register_tool(
    "generate_route",
    "Plan an A* route between two points on the MOLA grid.",
    {"start_lat": "float", "start_lon": "float", "end_lat": "float", "end_lon": "float",
     "preset": "str (balanced|terrain|speed)"},
    {"route": "RouteResult"},
)
def t_generate_route(args):
    r = plan_route(
        float(args["start_lat"]), float(args["start_lon"]),
        float(args["end_lat"]), float(args["end_lon"]),
        preset=args.get("preset", "balanced"),
    )
    return {
        "ok": r.ok, "preset": r.preset,
        "start": r.start, "end": r.end,
        "waypoints": r.waypoints,
        "stats": (r.stats.__dict__ if r.stats else None),
        "path_cells": r.path_cells,
        "notes": r.notes, "provenance": r.provenance,
    }


@register_tool(
    "optimize_route",
    "Re-plan an existing route with a different preset.",
    {"mission_id": "str", "preset": "str"},
    {"route": "RouteResult"},
)
def t_optimize_route(args):
    from .state import get_mission, update_mission_route
    m = get_mission(args["mission_id"])
    if not m:
        return {"error": "mission not found"}
    if "start" not in m or "end" not in m:
        return {"error": "mission has no start/end"}
    r = plan_route(m["start"]["lat"], m["start"]["lon"],
                   m["end"]["lat"], m["end"]["lon"],
                   preset=args.get("preset", "terrain"))
    update_mission_route(m["id"], r)
    return {
        "ok": r.ok, "preset": r.preset,
        "waypoints": r.waypoints,
        "stats": (r.stats.__dict__ if r.stats else None),
        "notes": r.notes,
    }


@register_tool(
    "add_waypoint",
    "Add a waypoint to an existing mission.",
    {"mission_id": "str", "lat": "float", "lon": "float", "name": "str"},
    {"mission_id": "str", "waypoint": "dict"},
)
def t_add_waypoint(args):
    from .state import add_waypoint
    wp = {"lat": float(args["lat"]), "lon": float(args["lon"]),
          "name": args.get("name", f"WP")}
    added = add_waypoint(args["mission_id"], wp)
    if added is None:
        return {"error": "mission not found"}
    return {"mission_id": args["mission_id"], "waypoint": added}


@register_tool(
    "explain_route",
    "Generate a human-readable explanation of a route plan.",
    {"mission_id": "str"},
    {"explanation": "str"},
)
def t_explain_route(args):
    from .state import get_mission
    m = get_mission(args["mission_id"])
    if not m:
        return {"error": "mission not found"}
    r = m.get("route")
    if not r:
        return {"error": "mission has no route yet"}
    stats = r.get("stats") or {}
    parts = []
    parts.append(f"Route planned from ({r['start']['lat']:.3f}, {r['start']['lon']:.3f}) to ({r['end']['lat']:.3f}, {r['end']['lon']:.3f}) using the '{r['preset']}' preset.")
    if stats:
        parts.append(f"Total length {stats.get('length_km', 0):.1f} km ({stats.get('length_m', 0):.0f} m), ascending {stats.get('ascent_m', 0):.0f} m and descending {stats.get('descent_m', 0):.0f} m.")
        parts.append(f"Maximum slope encountered: {stats.get('max_slope_deg', 0):.1f}° (mean {stats.get('mean_slope_deg', 0):.1f}°).")
        parts.append(f"Estimated traverse time at 100 m/sol EVA pace: {stats.get('est_sols', 0):.1f} sols.")
    if r.get("waypoints"):
        parts.append(f"Path contains {len(r['waypoints'])} sampled waypoints.")
    return {"explanation": " ".join(parts), "provenance": r.get("provenance", {})}


@register_tool(
    "export_mission",
    "Export a mission as a JSON object (downloadable).",
    {"mission_id": "str", "format": "str (json|csv|kml), default json"},
    {"mission": "dict", "format": "str"},
)
def t_export_mission(args):
    from .state import get_mission
    m = get_mission(args["mission_id"])
    if not m:
        return {"error": "mission not found"}
    fmt = args.get("format", "json")
    if fmt == "json":
        return {"format": "json", "mission": m}
    elif fmt == "csv" and m.get("route", {}).get("waypoints"):
        rows = ["lat,lon,elev_m,slope_deg"]
        for wp in m["route"]["waypoints"]:
            rows.append(f"{wp['lat']},{wp['lon']},{wp['elev_m']},{wp['slope_deg']}")
        return {"format": "csv", "csv": "\n".join(rows)}
    elif fmt == "kml" and m.get("route", {}).get("waypoints"):
        coords = " ".join(f"{wp['lon']},{wp['lat']},{wp['elev_m']}" for wp in m["route"]["waypoints"])
        kml = f"""<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>{m['name']}</name>
<Placemark><LineString><coordinates>{coords}</coordinates></LineString></Placemark>
</Document></kml>"""
        return {"format": "kml", "kml": kml}
    return {"error": f"unsupported format: {fmt}"}


# ---------------------------------------------------------------------------
# New tools (8)
# ---------------------------------------------------------------------------

@register_tool(
    "add_node",
    "Create a named node at coordinates (any type).",
    {"name": "str", "type": "str (waypoint|cache|shelter|water|hazard|poi|person|area)",
     "lat": "float", "lon": "float", "radius_m": "float, optional"},
    {"node": "dict"},
)
def t_add_node(args):
    from .state import create_node
    node = create_node(
        name=args["name"],
        type=args["type"],
        lat=float(args["lat"]),
        lon=float(args["lon"]),
        radius_m=float(args.get("radius_m", 0)),
        properties=args.get("properties", {}),
    )
    return {"node": node}


@register_tool(
    "add_stop",
    "Insert an ordered stop into an existing mission plan with a stated reason.",
    {"mission_id": "str", "lat": "float", "lon": "float", "reason": "str", "activity": "str"},
    {"mission_id": "str", "stop": "dict"},
)
def t_add_stop(args):
    from .state import add_stop_to_mission
    stop = {"lat": float(args["lat"]), "lon": float(args["lon"]),
            "reason": args.get("reason", ""), "activity": args.get("activity", "")}
    res = add_stop_to_mission(args["mission_id"], stop)
    if res is None:
        return {"error": "mission not found"}
    return {"mission_id": args["mission_id"], "stop": stop}


@register_tool(
    "plan_area",
    "Define and score a survey/operations area for stated objectives.",
    {"lat": "float", "lon": "float", "radius_km": "float", "objectives": "list of str"},
    {"area": "dict"},
)
def t_plan_area(args):
    lat = float(args["lat"]); lon = float(args["lon"])
    radius = float(args["radius_km"])
    objectives = args.get("objectives", [])
    ta = terrain_analyze(lat, lon, radius)
    # Score per objective (rule-based)
    scores = {}
    for obj in objectives:
        o = obj.lower()
        if "geolog" in o or "rock" in o:
            scores[obj] = 0.7 if ta["cells"][0]["rough_m"] and ta["cells"][0]["rough_m"] > 5 else 0.4
        elif "water" in o or "ice" in o:
            scores[obj] = 0.6 if abs(lat) > 30 else 0.2
        elif "image" in o or "photo" in o:
            scores[obj] = 0.9  # always possible
        elif "shelter" in o:
            scores[obj] = 0.5
        else:
            scores[obj] = 0.5
    return {
        "center": {"lat": lat, "lon": lon},
        "radius_km": radius,
        "objectives": objectives,
        "scores": scores,
        "terrain_summary": {
            "grid_shape": ta["grid_shape"],
            "extent": ta["extent"],
            "min_elev_m": min(c["elev_m"] for c in ta["cells"]),
            "max_elev_m": max(c["elev_m"] for c in ta["cells"]),
            "max_slope_deg": max((c["slope_deg"] or 0) for c in ta["cells"]),
        },
        "provenance": ta["provenance"],
    }


@register_tool(
    "plan_storm_response",
    "Plan an evacuation response to a storm/SEP event: shelters, water, route, dose.",
    {"event_id": "str", "current_lat": "float", "current_lon": "float"},
    {"plan": "dict"},
)
def t_plan_storm_response(args):
    from .sim import get_event
    event = get_event(args["event_id"])
    if not event:
        return {"error": f"event not found: {args['event_id']}"}
    cur_lat = float(args["current_lat"]); cur_lon = float(args["current_lon"])
    # Find nearest shelter
    shelters = find_shelters(cur_lat, cur_lon, max_radius_km=1000, limit=3)
    # Find water near the shelter
    evac_plan = {
        "event": {
            "id": event["id"], "kind": event["kind"], "severity": event["severity"],
            "duration_sols": event["duration_sols"],
        },
        "current_position": {"lat": cur_lat, "lon": cur_lon},
        "shelters_within_reach": shelters["shelters"],
        "recommended_shelter": shelters["shelters"][0] if shelters["shelters"] else None,
        "provenance": {
            "engine": "JEV deterministic storm-response planner (v2)",
            "advisory": "Advisory only; field judgement required.",
        },
    }
    if shelters["shelters"]:
        sh = shelters["shelters"][0]
        r = plan_route(cur_lat, cur_lon, sh["lat"], sh["lon"], preset="terrain")
        evac_plan["route_to_shelter"] = {
            "ok": r.ok, "preset": r.preset,
            "stats": (r.stats.__dict__ if r.stats else None),
            "waypoints_count": len(r.waypoints),
            "notes": r.notes,
        }
        # Dose along the path
        if r.waypoints:
            dose = assess_radiation_along_path([(w["lat"], w["lon"]) for w in r.waypoints[:20]])
            evac_plan["dose_estimate"] = dose
    return evac_plan


@register_tool(
    "find_water",
    "Find water-ice candidates near a point (SWIM-derived proxy).",
    {"lat": "float", "lon": "float", "max_radius_km": "float, default 500"},
    {"water_candidates": "list"},
)
def t_find_water(args):
    return find_water(float(args["lat"]), float(args["lon"]),
                      max_radius_km=float(args.get("max_radius_km", 500)))


@register_tool(
    "find_shelter",
    "Find shelter candidates near a point, scored on 4 axes.",
    {"lat": "float", "lon": "float", "max_radius_km": "float, default 500"},
    {"shelters": "list"},
)
def t_find_shelter(args):
    return find_shelters(float(args["lat"]), float(args["lon"]),
                         max_radius_km=float(args.get("max_radius_km", 500)))


@register_tool(
    "assess_radiation",
    "Estimate radiation dose at a point or along a path.",
    {"lat": "float, optional", "lon": "float, optional",
     "path": "list of [lat, lon], optional"},
    {"dose": "dict"},
)
def t_assess_radiation(args):
    if "path" in args:
        pts = [(float(p[0]), float(p[1])) for p in args["path"]]
        return assess_radiation_along_path(pts)
    return assess_radiation(float(args["lat"]), float(args["lon"]))


@register_tool(
    "simulate_storm",
    "Generate a synthetic dust or SEP event for drills.",
    {"kind": "str (dust|sep)", "lat": "float", "lon": "float", "severity": "str (regional|planet_encircling|X-flare-class)"},
    {"event": "dict"},
)
def t_simulate_storm(args):
    from .sim import create_event
    e = create_event(
        kind=args.get("kind", "dust"),
        lat=float(args.get("lat", 0)), lon=float(args.get("lon", 0)),
        severity=args.get("severity", "regional"),
    )
    return {"event": e}


# ---------------------------------------------------------------------------
# Walk view (extra tool — not in v1's 16, but useful for the chat)
# ---------------------------------------------------------------------------

@register_tool(
    "enter_walk_view",
    "Initialize a first-person Walk View at a location.",
    {"lat": "float", "lon": "float", "heading_deg": "float, default 0"},
    {"walk": "dict"},
)
def t_enter_walk_view(args):
    return walk_init(float(args["lat"]), float(args["lon"]),
                    heading_deg=float(args.get("heading_deg", 0)))


# ---------------------------------------------------------------------------
# Deterministic intent router — matches user phrases to tools
# ---------------------------------------------------------------------------

INTENT_PATTERNS: list[tuple[re.Pattern, str, dict]] = [
    (re.compile(r"\b(hi|hello|hey|help|what can you do)\b", re.I), "_help", {}),
    # Site listing / comparison / historical traverses / highest mountains —
    # these MUST run before the generic route pattern below, otherwise
    # "Show me Perseverance's route" is misrouted to generate_route.
    (re.compile(r"\b(landing ?sites?|mission sites?)\b", re.I), "_sites", {}),
    (re.compile(r"\bcompare\b.{0,50}\b(jezero|gale)\b|\b(jezero|gale)\b.{0,50}\bcompare\b", re.I), "_compare_sites", {}),
    (re.compile(r"\b(highest|tallest|biggest) (mountains?|volcanoes?|peaks?)\b|\ball mons\b", re.I), "_mons_list", {}),
    (re.compile(r"\b(perseverance|curiosity|spirit|opportunity)\b.{0,30}\b(route|traverse|path|journey|track)\b"
                r"|\b(route|traverse|path) (of|for)\b.{0,30}\b(perseverance|curiosity|spirit|opportunity)\b", re.I),
     "_rover_route", {}),
    (re.compile(r"\b(ancient water|evidence of (ancient )?water|water evidence|habitability|habitab)\b", re.I),
     "find_water", {"lat": 22.0, "lon": 74.5, "max_radius_km": 1500, "limit": 8}),
    # Explicit action verbs first — "find shelters near X" must beat "X" alone.
    (re.compile(r"\b(route|path|plan (a route|the route)|navigate|drive|from .+ to .+)\b", re.I), "generate_route", {}),
    (re.compile(r"\b(plan )?(storm|sep|dust|solar particle) (response|evac|evacuation|plan|drill)\b", re.I),
     "plan_storm_response", {}),
    (re.compile(r"\b(storm|dust|sep|solar particle|space weather)\b", re.I), "simulate_storm", {"kind": "dust", "severity": "regional"}),
    (re.compile(r"\b(water|ice|h2o|waters?)\b", re.I), "find_water", {}),
    (re.compile(r"\b(shelters?|hide|cave|lava tubes?|crater shelters?)\b", re.I), "find_shelter", {}),
    (re.compile(r"\b(radiation|dose|rad|sievert|msv)\b", re.I), "assess_radiation", {}),
    (re.compile(r"\b(walk|first person|3d view|street view|look around)\b", re.I), "enter_walk_view", {}),
    # Only AFTER explicit action verbs do we match named features (so a feature
    # mention alone triggers a fly-to, but "find shelters near Olympus Mons"
    # already matched find_shelter above).
    (re.compile(r"\b(deepest|lowest (point|place)|hellas)\b", re.I), "_fly_and_say",
     {"text": "The deepest point is in <b>Hellas Planitia</b>: ≈-8.1 km in the MEGDR grid (typical floor ≈-7.1 km), inside a ~2,300 km impact basin.",
      "lat": -42.4, "lon": 70.0, "src": ["MEGDR 4 ppd (embedded)", "IAU Gazetteer"]}),
    (re.compile(r"\b(tallest|highest (point|place|volcano)|olympus)\b", re.I), "_fly_and_say",
     {"text": "The tallest volcano is <b>Olympus Mons</b>: ~21 km above the MOLA areoid, ~600 km wide.",
      "lat": 18.65, "lon": 226.2, "src": ["IAU Gazetteer", "MOLA: Smith et al. (2001)"]}),
    (re.compile(r"\b(jezero|perseverance)\b", re.I), "_fly_and_say",
     {"text": "<b>Jezero crater</b> at 18.4°N, 77.7°E — Perseverance landing site. Delta deposits, hydrated minerals, carbonate-bearing formations.",
      "lat": 18.4447, "lon": 77.4508, "src": ["NASA/JPL Perseverance mission"]}),
    (re.compile(r"\b(gale|curiosity|mount sharp|aeolis)\b", re.I), "_fly_and_say",
     {"text": "<b>Gale crater</b> at 5.4°S, 137.4°E — Curiosity rover's exploration site since 2012. Mount Sharp (Aeolis Mons) rises 5.5 km above the crater floor.",
      "lat": -5.4, "lon": 137.4, "src": ["NASA/JPL Curiosity mission"]}),
    (re.compile(r"\b(valles marineris|canyon)\b", re.I), "_fly_and_say",
     {"text": "<b>Valles Marineris</b> — 4,000 km canyon system up to 7 km deep. Tectonic origin, possible RSL.",
      "lat": -14.0, "lon": 301.0, "src": ["IAU Gazetteer", "MEGDR 4 ppd"]}),
]


def route_intent(text: str) -> dict:
    """Match the text to a tool call. Returns {tool, args, text}."""
    for pat, tool, default_args in INTENT_PATTERNS:
        m = pat.search(text)
        if not m:
            continue
        if tool == "_help":
            return {
                "tool": None,
                "text": ("I'm NAM's assistant. I can search Mars features, plan routes, analyze terrain, "
                         "find shelters and water, estimate radiation, and initialize a first-person "
                         "Walk View. Try: 'plan a route from Jezero to Nili Patera', "
                         "'find shelters near Olympus Mons', 'walk view at Gale crater'."),
            }
        if tool == "_fly_and_say":
            return {"tool": None, "text": default_args["text"],
                    "fly_to": {"lat": default_args["lat"], "lon": default_args["lon"]},
                    "src": default_args["src"]}
        if tool == "_sites":
            sites = load_json_data()["SITES"]
            lines = "<br>".join(
                f"· <b>{s['name']}</b> — {s['agency']} {s['kind']}{', ' + s['date'] if s.get('date') else ''} "
                f"({s['lat']:.2f}°, {s['lon']:.2f}°)"
                for s in sites)
            return {"tool": None,
                    "text": f"All {len(sites)} curated mission sites:<br>{lines}",
                    "result": {"sites": [s["name"] for s in sites]},
                    "src": ["NAM curated mission-site catalogue (13 entries)"]}
        if tool == "_compare_sites":
            return {"tool": None,
                    "text": ("<b>Jezero vs Gale.</b> Jezero crater (18.4°N 77.7°E, ~45 km wide) preserves an "
                             "exposed river delta with Fe/Mg-smectite and carbonate exposures — an ancient lake "
                             "environment now sampled by Perseverance. Gale crater (5.4°S 137.4°E, ~154 km wide) "
                             "hosts the ~5.5 km Mount Sharp layered mound — ancient lakebeds recorded by Curiosity "
                             "since 2012. In short: Jezero has the stronger fluvial/deltaic signatures, Gale the "
                             "longer stratigraphic record."),
                    "fly_to": {"lat": 18.4447, "lon": 77.4508},
                    "src": ["NASA/JPL Perseverance & Curiosity missions", "IAU Gazetteer"]}
        if tool == "_mons_list":
            from .geo import sample_elevation
            wanted = ["Olympus Mons", "Ascraeus Mons", "Pavonis Mons", "Arsia Mons", "Elysium Mons"]
            rows = []
            for f in load_json_data()["FEATURES"]:
                if f["name"] in wanted:
                    try:
                        e = float(sample_elevation(f["lat"], f["lon"]))
                    except Exception:
                        e = None
                    if e is not None:
                        rows.append((e, f["name"], f["lat"], f["lon"]))
            rows.sort(reverse=True)
            if not rows:
                return {"tool": None, "text": "No mons found in the gazetteer."}
            listing = "<br>".join(f"{i + 1}. <b>{n}</b> — {int(e):+d} m grid elevation ({la:.2f}°, {lo:.2f}°)"
                                  for i, (e, n, la, lo) in enumerate(rows))
            return {"tool": None,
                    "text": f"Highest mountains on Mars (sampled live from the embedded MOLA MEGDR grid):<br>{listing}",
                    "fly_to": {"lat": rows[0][2], "lon": rows[0][3]},
                    "src": ["MOLA MEGDR 4 ppd (embedded)", "IAU Gazetteer"]}
        if tool == "_rover_route":
            return {"tool": None,
                    "text": ("<b>Rover traverses (documented, not live telemetry).</b> Perseverance landed in "
                             "Jezero crater in Feb 2021 and has traversed the crater floor toward the western "
                             "delta — tens of km over its mission. Curiosity has climbed Mount Sharp in Gale "
                             "crater since 2012 (~30 km driven). This build embeds the landing-site references "
                             "and enables the mission-sites overlay rather than day-by-day GPS tracks; I've "
                             "flown you to the rover's landing region."),
                    "fly_to": {"lat": 18.4447, "lon": 77.4508},
                    "result": {"sites": ["Jezero Crater", "Gale Crater"]},
                    "src": ["NASA/JPL Perseverance & Curiosity missions"]}
        # Try to extract lat/lon from the text
        args = dict(default_args)
        lat_m = re.search(r"(-?\d+(?:\.\d+)?)\s*(?:°\s*)?[NS]\b", text, re.I)
        lon_m = re.search(r"(-?\d+(?:\.\d+)?)\s*(?:°\s*)?[EW]\b", text, re.I)
        if lat_m and lon_m:
            args["lat"] = float(lat_m.group(1)) * (-1 if re.search(r"\bS\b", text, re.I) else 1)
            args["lon"] = float(lon_m.group(1)) * (-1 if re.search(r"\bW\b", text, re.I) else 1)
        # If tool needs lat/lon and we don't have them, try to find a feature name
        if "lat" not in args or "lon" not in args:
            for f in load_json_data()["FEATURES"]:
                if f["name"].lower() in text.lower():
                    args["lat"] = f["lat"]
                    args["lon"] = f["lon"]
                    break
        if ("lat" not in args or "lon" not in args) and tool in (
            "find_water", "find_shelter", "assess_radiation", "enter_walk_view"
        ):
            return {"tool": None,
                    "text": ("I need a location for that. Try mentioning a feature like 'Jezero', "
                             "'Gale crater', or 'Olympus Mons', or give me a lat/lon like '18.4N, 77.7E'." )}
        # For generate_route we need a start and end
        if tool == "generate_route":
            # Look for "from X to Y" patterns
            m2 = re.search(r"from\s+(.+?)\s+to\s+(.+?)(?:$|[.,;])", text, re.I)
            if m2:
                start_name, end_name = m2.group(1).strip(), m2.group(2).strip()
                start_feat = _find_feature(start_name)
                end_feat = _find_feature(end_name)
                if start_feat and end_feat:
                    args["start_lat"] = start_feat["lat"]
                    args["start_lon"] = start_feat["lon"]
                    args["end_lat"] = end_feat["lat"]
                    args["end_lon"] = end_feat["lon"]
                    args["preset"] = "balanced"
                else:
                    return {"tool": None,
                            "text": f"Could not find both endpoints ('{start_name}' -> '{end_name}'). Try IAU feature names."}
            else:
                return {"tool": None,
                        "text": "To plan a route, tell me start and end like: 'plan a route from Jezero to Nili Patera'."}
        if tool == "plan_storm_response":
            # Extract event id from text (format event-XXXXXXXXXX)
            eid = re.search(r"event-([a-f0-9]{6,})", text, re.I)
            if eid:
                args["event_id"] = "event-" + eid.group(1)
            else:
                # No event id given — create one on the fly
                from .sim import create_event
                e = create_event(kind="sep", lat=args.get("lat", 18.4447),
                                lon=args.get("lon", 77.4508), severity="X-flare-class")
                args["event_id"] = e["id"]
                # Use the user's current position if they gave one
            if "lat" in args:
                args["current_lat"] = args.pop("lat")
                args["current_lon"] = args.pop("lon")
            else:
                args["current_lat"] = 18.4447  # default to Jezero
                args["current_lon"] = 77.4508
        return {"tool": tool, "args": args}
    # Regex missed — try the trained multilingual classifier (mars3d hybrid
    # model) before giving up. It routes paraphrases and non-English asks.
    try:
        ml = ml_route_intent(text)
    except Exception:
        ml = None
    if ml is not None:
        return ml
    return {
        "tool": None,
        "text": ("I didn't catch that. Try: 'find shelters near Olympus Mons', 'plan a route from "
                 "Jezero to Nili Patera', 'show radiation at Gale crater', or 'walk view at 18.4N 77.7E'."),
    }


# ---------------------------------------------------------------------------
# ML-first intent routing (integrated from the mars3d hybrid-AI package).
# The trained model (nam_model.json, tfidf-l1-logreg) classifies utterances in
# 9 languages into 26+ intents; intents.json maps each intent to one of this
# assistant's registered tools. The regex patterns above run FIRST (proven,
# deterministic behaviour); the classifier catches everything they miss —
# multilingual queries ("带我去奥林匹斯山"), paraphrases ("tallest volcano"),
# and phrasings the keyword list never anticipated. A confidence gate plus the
# anti-hallucination place matcher keep routing honest.
# ---------------------------------------------------------------------------
_INTEL_DIR = Path(__file__).resolve().parent.parent / "intel"
_ML_CONF_GATE = 0.55
_INFO_INTENTS = {"planet_fact", "feature_info", "mission_site_info", "instrument_info",
                 "tallest_deepest", "help", "model_info", "greet", "thanks", "compare_layers",
                 "current_context", "search_datasets", "observations_nearby", "elevation_here",
                 "elevation_profile", "analyze_terrain", "identify_hazards", "find_targets"}
_INTENT_TOOL_MAP: dict[str, str] = {}


def _intent_tool_map() -> dict[str, str]:
    """intent name -> registered tool name (from intel/intents.json)."""
    global _INTENT_TOOL_MAP
    if not _INTENT_TOOL_MAP:
        try:
            data = json.loads((_INTEL_DIR / "intents.json").read_text(encoding="utf-8"))
            _INTENT_TOOL_MAP = {
                intent: tool for intent, tool, _needs in data.get("intents", [])
                if not tool.startswith("_")
            }
        except Exception:
            _INTENT_TOOL_MAP = {}
    return _INTENT_TOOL_MAP


def _ml_classifier():
    try:
        from ..intel import hybrid_ai
        return hybrid_ai if hybrid_ai.ready() else None
    except Exception:
        return None


def _locate_in_text(text: str) -> tuple[float, float] | None:
    """Shared location extraction: explicit coords first, then gazetteer,
    then the trained place matcher (typo/paraphrase tolerant)."""
    lat_m = re.search(r"(-?\d+(?:\.\d+)?)\s*(?:°\s*)?[NS]\b", text, re.I)
    lon_m = re.search(r"(-?\d+(?:\.\d+)?)\s*(?:°\s*)?[EW]\b", text, re.I)
    if lat_m and lon_m:
        lat = float(lat_m.group(1)) * (-1 if re.search(r"\bS\b", text, re.I) else 1)
        lon = float(lon_m.group(1)) * (-1 if re.search(r"\bW\b", text, re.I) else 1)
        return normalize_lat(lat), normalize_lon(lon)
    feat = _find_feature(text)
    if feat:
        return feat["lat"], feat["lon"]
    return None


_ALIAS_CACHE: dict | None = None


def _model_alias_resolve(text: str) -> str | None:
    """Map a multilingual feature mention to its canonical English name using
    nam_model.json's entities.feature_aliases (9 languages). This bridges the
    mars3d ML model's vocabulary to the marswalk matcher's English aliases —
    so '带我去奥林匹斯山' resolves to Olympus Mons and '海拉斯附近的避难所'
    finds shelters near Hellas."""
    global _ALIAS_CACHE
    try:
        if _ALIAS_CACHE is None:
            path = _INTEL_DIR.parent / "data" / "raw" / "nam_model.json"
            m = json.loads(path.read_text(encoding="utf-8"))
            _ALIAS_CACHE = m.get("entities", {}).get("feature_aliases", {})
        t = text.lower()
        best = None  # (feature_id, alias_len)
        for fid, langs in _ALIAS_CACHE.items():
            for names in langs.values():
                for n in names:
                    if n.lower() in t and (best is None or len(n) > best[1]):
                        best = (fid, len(n))
        if best:
            en = _ALIAS_CACHE[best[0]].get("en", [])
            return en[0] if en else best[0].replace("-", " ")
    except Exception:
        return None
    return None


def ml_route_intent(text: str) -> dict | None:
    """Classify with the trained multilingual model and route to a tool.
    Returns the same shape as route_intent, or None to fall through."""
    ha = _ml_classifier()
    if ha is None:
        return None
    cls = ha.classify(text)
    intent, conf = cls.get("intent"), float(cls.get("conf") or 0.0)
    if not intent or conf < _ML_CONF_GATE:
        return None

    tool = _intent_tool_map().get(intent)

    # Informational intents -> grounded answer from the hybrid engine
    # (retrieval over the embedded catalog; never invented).
    if intent in _INFO_INTENTS or tool is None:
        ans = ha.answer(text)
        fly = None
        for d in ans.get("retrieved", []):
            if d.get("lat") is not None:
                fly = {"lat": d["lat"], "lon": d["lon"]}
                break
        return {"tool": None, "text": ans.get("answer") or cls.get("intent"),
                "fly_to": fly, "src": ans.get("sources", [])[:4], "via": "ml"}

    # Location-needing tools: find_water / find_shelter / assess_radiation /
    # enter_walk_view / analyze_terrain / identify_hazards / get_current_map_context
    loc_tools = {"find_water", "find_shelter", "assess_radiation", "enter_walk_view",
                 "analyze_terrain", "identify_hazards"}
    if tool in loc_tools:
        loc = _locate_in_text(text)
        if not loc:
            # multilingual mention? resolve via the model's feature aliases
            canon = _model_alias_resolve(text)
            if canon:
                feat = _find_feature(canon)
                if feat:
                    loc = (feat["lat"], feat["lon"])
        if not loc:
            return {"tool": None, "via": "ml",
                    "text": ("I need a location for that — mention a feature like 'Jezero' or "
                             "'Olympus Mons', or give coordinates like '18.4N 77.7E'.")}
        return {"tool": tool, "args": {"lat": loc[0], "lon": loc[1]}, "via": "ml"}

    if tool == "generate_route":
        m2 = re.search(r"from\s+(.+?)\s+to\s+(.+?)(?:$|[.,;!?，。])", text, re.I)
        if not m2:
            return None  # let the regex fallback message handle it
        start_feat = _find_feature(m2.group(1).strip())
        end_feat = _find_feature(m2.group(2).strip())
        if not (start_feat and end_feat):
            return {"tool": None, "via": "ml",
                    "text": (f"Could not find both route endpoints ('{m2.group(1).strip()}' → "
                             f"'{m2.group(2).strip()}'). Try IAU feature names like 'Jezero' or 'Gale'.")}
        return {"tool": tool, "via": "ml", "args": {
            "start_lat": start_feat["lat"], "start_lon": start_feat["lon"],
            "end_lat": end_feat["lat"], "end_lon": end_feat["lon"], "preset": "balanced"}}

    if tool == "search_planetary_location":
        # Prefer the trained place matcher for the fly-to experience; for
        # non-English mentions, resolve through the model's feature aliases
        # (9 languages) and retry the matcher with the canonical name.
        from ..match.matcher import get_matcher
        r = get_matcher().search(text)
        if not r.get("ok"):
            canon = _model_alias_resolve(text)
            if canon:
                r = get_matcher().search(canon)
        if r.get("ok"):
            lon_e = r["lon"] % 360.0
            detail = r.get("detail") or r.get("type") or ""
            return {"tool": None, "via": "ml",
                    "text": f"<b>{r['name']}</b>" + (f" — {detail}" if detail else "") +
                            f" · {r['lat']:.2f}°, {lon_e:.2f}° (east-positive)",
                    "fly_to": {"lat": r["lat"], "lon": lon_e},
                    "src": ["marswalk trained place matcher"]}
        return {"tool": tool, "via": "ml", "args": {"q": text}}

    if tool == "create_mission":
        return {"tool": tool, "via": "ml", "args": {"name": text[:80], "objective": text}}

    # Remaining simple tools (activate_map_layer, optimize_route, ...)
    return {"tool": tool, "via": "ml", "args": {}}


def _find_feature(name: str) -> dict | None:
    n = name.lower().strip()
    for f in load_json_data()["FEATURES"]:
        if n in f["name"].lower() or n in f["id"].lower():
            return f
    for s in load_json_data()["SITES"]:
        if n in s["name"].lower():
            return s
    # Trained place matcher fallback (typo/paraphrase tolerant, gated):
    try:
        from ..match.matcher import get_matcher
        r = get_matcher().search(n)
        if r.get("ok"):
            return {"name": r["name"], "lat": r["lat"], "lon": r["lon"]}
    except Exception:
        pass
    return None


def chat_respond(user_text: str, mission_id: str | None = None) -> dict:
    """Process a user message and return a chat turn (no LLM)."""
    routed = route_intent(user_text)
    if routed.get("tool") is None:
        return {
            "text": routed["text"],
            "fly_to": routed.get("fly_to"),
            "sources": routed.get("src", []),
            "result": routed.get("result"),
            "tool_calls": [],
        }
    tool = routed["tool"]
    args = routed["args"]
    if mission_id and "mission_id" not in args:
        args["mission_id"] = mission_id
    result = invoke_tool(tool, args)
    # Compose a natural-language summary of the result
    summary = _summarize(tool, args, result)
    return {
        "text": summary,
        "tool_calls": [{
            "tool": tool,
            "args": args,
            "result_summary": (str(result)[:500] + "...") if len(str(result)) > 500 else str(result),
        }],
        "result": result,
        "sources": _extract_sources(result),
    }


def _summarize(tool: str, args: dict, result: dict) -> str:
    if "error" in result:
        return f"⚠️ {result['error']}"
    if tool == "search_planetary_location":
        n = result.get("count", 0)
        names = [r["name"] for r in result.get("results", [])[:5]]
        return f"Found {n} matching features: {', '.join(names) if names else 'none'}."
    if tool == "find_shelter":
        n = result.get("count", 0)
        if n == 0:
            return "No shelter candidates within range. Try a wider search radius."
        top = result["shelters"][0]
        return (f"Found {n} shelter candidates. Nearest: <b>{top['name']}</b> "
                f"({top['kind']}, {top['distance_km']} km away, "
                f"sheltering index {top['scores']['sheltering_index']}).")
    if tool == "find_water":
        n = result.get("count", 0)
        if n == 0:
            return "No water-ice candidates within range."
        top = result["water_candidates"][0]
        return (f"Found {n} water-ice candidates. Best: certainty <b>{top['ice_certainty']}</b> "
                f"at {top['lat']:.2f}°, {top['lon']:.2f}° "
                f"(estimated depth to ice: {top['est_depth_to_ice_m']} m). "
                f"Distance from query: {top['distance_km']} km.")
    if tool == "assess_radiation":
        d = result.get("dose_mSv_per_day", 0)
        y = result.get("dose_mSv_per_year", 0)
        return (f"Radiation at this location: <b>{d} mSv/day</b> "
                f"(~{y} mSv/year). That's "
                f"{result.get('annual_career_limit_fraction_pct', 0):.1f}% of NASA's 1 Sv career limit per year.")
    if tool == "generate_route":
        if not result.get("ok"):
            return "Could not plan a route with that preset. Try a different preset or move endpoints off extreme terrain."
        s = result.get("stats") or {}
        return (f"Route planned ({result['preset']} preset): "
                f"<b>{s.get('length_km', 0):.1f} km</b>, "
                f"max slope {s.get('max_slope_deg', 0):.1f}°, "
                f"est. {s.get('est_sols', 0):.1f} sols at 100 m/sol EVA pace.")
    if tool == "simulate_storm":
        e = result.get("event", {})
        return (f"Simulated <b>{e.get('kind', 'dust')}</b> event created (id: {e.get('id')}). "
                f"Severity: {e.get('severity')}, duration {e.get('duration_sols')} sols. "
                f"Use plan_storm_response with this event_id for evacuation planning.")
    if tool == "enter_walk_view":
        w = result
        return (f"Walk View initialized at {w['lat']:.4f}, {w['lon']:.4f}. "
                f"Eye elevation: {w['eye_elev_m']} m (terrain {w['elev_m']} m + 1.7 m suit). "
                f"Local slope: {w.get('slope_deg', 'unknown')}°. "
                + (f"Nearby POV: {w['nearby_pov']['pov']['caption']}" if w.get("nearby_pov", {}).get("found") else "No pre-cached POV imagery nearby."))
    if tool == "plan_storm_response":
        return ("Storm-response plan ready. See the route_to_shelter and dose_estimate fields in the result. "
                "The recommended shelter has the highest composite sheltering index.")
    if tool == "analyze_terrain":
        cells = result.get("cells", [])
        if not cells:
            return "No terrain cells in the requested area."
        slopes = [c["slope_deg"] or 0 for c in cells]
        elevs = [c["elev_m"] for c in cells]
        return (f"Terrain grid {result['grid_shape']} over {result['extent']}. "
                f"Elevation range {min(elevs)}..{max(elevs)} m, "
                f"max slope {max(slopes):.1f}°.")
    if tool == "add_node":
        n = result.get("node", {})
        return f"Node '{n.get('name')}' (type {n.get('type')}) created at ({n.get('lat')}, {n.get('lon')}). ID: {n.get('id')}."
    if tool == "add_stop":
        return f"Stop added to mission {result.get('mission_id')} at ({result['stop']['lat']}, {result['stop']['lon']}). Reason: {result['stop'].get('reason', '—')}."
    if tool == "plan_area":
        scores = result.get("scores", {})
        score_str = "; ".join(f"{k}: {v:.2f}" for k, v in scores.items())
        return f"Area scored over {result['radius_km']} km. Objectives: {score_str}."
    return f"Tool <b>{tool}</b> executed. See the result field for details."


def _extract_sources(result: dict) -> list[str]:
    if isinstance(result, dict):
        prov = result.get("provenance", {})
        if isinstance(prov, dict):
            url = prov.get("url")
            if url:
                return [url]
            ref = prov.get("reference") or prov.get("catalogue") or prov.get("model")
            if ref:
                return [ref]
    return []
