"""A* route planner over the MOLA 4 ppd grid.

Port of NAM.ROUTER from v1, extended with adaptive multi-resolution planning:
short routes use the full 0.25° grid; long routes are planned on a strided
view of the same grid (2×/4×/8×) so GLOBAL traverses stay inside the step
budget while still honouring the same cost function.

Same cost function and three presets:
  - balanced   : distance + slope² + roughness penalty
  - terrain    : heavy slope/roughness penalty (terrain-averse)
  - speed      : distance-dominated (fastest traverse)

Cost formula (matches v1 NAM.ROUTER):
  cost = distance_km * (1 + (slope_deg/6)^2 * w_slope + rough/5 * w_rough)
        - science_bonus * 0.05

The grid resolution is 0.25 deg (~14.8 km at the equator), so the planner is
advisory, not certified safe.
"""
from __future__ import annotations
import heapq
import math
from dataclasses import dataclass, field

from ..data import (
    ELEV_H, ELEV_W, load_elevation, load_roughness,
    mars_radius_m, normalize_lat, normalize_lon,
)
from .geo import sample_elevation, slope_at, sample_roughness


PRESETS = {
    "balanced": {"w_slope": 1.0, "w_rough": 1.0, "science_bonus": 0.0},
    "terrain":  {"w_slope": 3.0, "w_rough": 2.5, "science_bonus": 0.0},
    "speed":    {"w_slope": 0.5, "w_rough": 0.3, "science_bonus": 0.0},
}

# 8-connected neighbours (row, col, diagonal?) — diagonals cost sqrt(2)
_NEIGHBOURS = [
    (-1, 0, False), (1, 0, False), (0, -1, False), (0, 1, False),
    (-1, -1, True), (-1, 1, True), (1, -1, True), (1, 1, True),
]

# Straight-line distance thresholds (km) → grid stride. Keeps global routes
# inside the A* step budget while short routes keep full 4 ppd fidelity.
_STRIDE_BANDS = [(250, 1), (700, 2), (1600, 4), (float("inf"), 8)]


@dataclass
class RouteStats:
    length_m: float = 0.0
    length_km: float = 0.0
    ascent_m: float = 0.0
    descent_m: float = 0.0
    max_slope_deg: float = 0.0
    mean_slope_deg: float = 0.0
    est_sols: float = 0.0  # rough traversal-time estimate at 100 m/sol EVA


@dataclass
class RouteResult:
    ok: bool
    preset: str
    start: dict
    end: dict
    waypoints: list[dict] = field(default_factory=list)  # [{lat, lon, elev_m, slope_deg}]
    stats: RouteStats | None = None
    path_cells: int = 0
    notes: list[str] = field(default_factory=list)
    provenance: dict = field(default_factory=dict)


def _latlon_to_grid(lat: float, lon: float, ppd: float = 4.0,
                    h: int = ELEV_H, w: int = ELEV_W) -> tuple[int, int]:
    """Return (row, col) into a (h, w) grid of `ppd` pixels-per-degree."""
    la = normalize_lat(lat)
    lo = normalize_lon(lon)
    r = int(round((90.0 - la) * ppd))
    c = int(round(lo * ppd))
    r = max(0, min(h - 1, r))
    c = c % w
    return r, c


def _grid_to_latlon(r: int, c: int, ppd: float = 4.0) -> tuple[float, float]:
    """Inverse of _latlon_to_grid (returns centre of cell)."""
    la = 90.0 - r / ppd
    lo = (c / ppd) % 360.0
    return la, lo


def _km_per_cell_at(lat: float, ppd: float = 4.0) -> tuple[float, float]:
    """Return (km_per_col, km_per_row) at this latitude for a `ppd` grid."""
    R = mars_radius_m()
    km_per_deg_lat = R * math.pi / 180.0 / 1000.0
    km_per_deg_lon = km_per_deg_lat * max(0.05, math.cos(math.radians(lat)))
    return km_per_deg_lon / ppd, km_per_deg_lat / ppd


def _slope_at_grid(elev, r: int, c: int, ppd: float = 4.0) -> float:
    """Slope (degrees) at a grid cell using ±1 cell of the given grid."""
    h, w = elev.shape
    c0 = c % w
    cn = (c + 1) % w
    cs = (c - 1) % w
    rn = min(h - 1, r + 1)
    rs = max(0, r - 1)
    e0 = float(elev[r, c0])
    en = float(elev[rs, c0])
    es = float(elev[rn, c0])
    ee = float(elev[r, cn])
    ew = float(elev[r, cs])
    dpx = 1.0 / ppd  # degrees per cell
    R = mars_radius_m()
    km_per_deg_lat = R * math.pi / 180.0 / 1000.0
    lat = 90.0 - r / ppd
    km_per_deg_lon = km_per_deg_lat * max(0.05, math.cos(math.radians(lat)))
    dz_n = (en - es) / (2 * dpx)
    dz_e = (ee - ew) / (2 * dpx)
    s_n = dz_n / (km_per_deg_lat * 1000.0)
    s_e = dz_e / (km_per_deg_lon * 1000.0)
    return math.degrees(math.atan(math.sqrt(s_n * s_n + s_e * s_e)))


def _choose_stride(dist_km: float) -> int:
    for limit, stride in _STRIDE_BANDS:
        if dist_km < limit:
            return stride
    return 8


def plan_route(start_lat: float, start_lon: float,
               end_lat: float, end_lon: float,
               preset: str = "balanced",
               max_steps: int = 6000,
               blocked_cells: set[tuple[int, int]] | None = None) -> RouteResult:
    """A* over the MOLA grid (adaptive stride for long routes).

    blocked_cells : optional set of FULL-RESOLUTION (r, c) cells to avoid.
    """
    if preset not in PRESETS:
        preset = "balanced"
    w = PRESETS[preset]

    start = (normalize_lat(start_lat), normalize_lon(start_lon))
    end = (normalize_lat(end_lat), normalize_lon(end_lon))

    elev_full = load_elevation()  # (720, 1440)

    R = mars_radius_m()

    def haversine_km(a_lat, a_lon, b_lat, b_lon):
        dlat = math.radians(b_lat - a_lat)
        dlon = math.radians(b_lon - a_lon)
        x = (math.sin(dlat / 2) ** 2
             + math.cos(math.radians(a_lat)) * math.cos(math.radians(b_lat))
             * math.sin(dlon / 2) ** 2)
        return R * 2 * math.atan2(math.sqrt(x), math.sqrt(1 - x)) / 1000.0

    dist_km = haversine_km(start[0], start[1], end[0], end[1])
    stride = _choose_stride(dist_km)
    ppd = 4.0 / stride
    cell_km = 14.8 * stride
    # Longer budget on the coarser grids (they have far fewer cells total).
    budget = max_steps if stride == 1 else max_steps * 8

    elev = elev_full[::stride, ::stride]
    gh, gw = elev.shape

    sr, sc = _latlon_to_grid(start[0], start[1], ppd, gh, gw)
    er, ec = _latlon_to_grid(end[0], end[1], ppd, gh, gw)

    if (sr, sc) == (er, ec):
        return RouteResult(
            ok=True, preset=preset,
            start={"lat": start[0], "lon": start[1]},
            end={"lat": end[0], "lon": end[1]},
            waypoints=[{"lat": start[0], "lon": start[1],
                        "elev_m": float(elev_full[sr * stride, sc * stride]), "slope_deg": 0.0}],
            stats=RouteStats(),
            path_cells=1,
            notes=["Start and end are the same grid cell."],
            provenance={"engine": "A* on MOLA MEGDR 4 ppd grid", "advisory": "Regional slopes; advisory only."},
        )

    blocked: set[tuple[int, int]] = set()
    if blocked_cells:
        for (r0, c0) in blocked_cells:
            blocked.add((r0 // stride, c0 // stride))

    def heuristic(r, c):
        la, lo = _grid_to_latlon(r, c, ppd)
        return haversine_km(la, lo, end[0], end[1]) / cell_km

    # Slope cache — small LRU-ish dict (we re-visit few cells)
    slope_cache: dict[tuple[int, int], float] = {}

    def cell_cost(r, c, nr, nc):
        la, lo = _grid_to_latlon(r, c, ppd)
        km_per_col, km_per_row = _km_per_cell_at(la, ppd)
        diag = math.sqrt(km_per_col ** 2 + km_per_row ** 2)
        step_km = diag if (abs(nr - r) + abs(nc - c) == 2) else max(km_per_col, km_per_row)
        if (nr, nc) not in slope_cache:
            slope_cache[(nr, nc)] = _slope_at_grid(elev, nr, nc, ppd)
        slope = slope_cache[(nr, nc)]
        rough_arr = load_roughness()
        rr = min(ROUGH_H - 1, max(0, int(round((90.0 - la)))))
        rc = int(round(lo)) % ROUGH_W
        rough = float(rough_arr[rr, rc])
        if math.isnan(rough):
            rough = 5.0
        cost = step_km * (1 + (slope / 6.0) ** 2 * w["w_slope"] + rough / 5.0 * w["w_rough"])
        if slope > 30.0:
            return None
        return cost

    # A*
    open_heap: list[tuple[float, int, int, int]] = []
    came_from: dict[tuple[int, int], tuple[int, int]] = {}
    g_score: dict[tuple[int, int], float] = {(sr, sc): 0.0}
    closed: set[tuple[int, int]] = set()
    counter = 0  # tie-breaker
    heapq.heappush(open_heap, (heuristic(sr, sc), counter, sr, sc))

    found = False
    steps = 0
    while open_heap and steps < budget:
        _, _, r, c = heapq.heappop(open_heap)
        if (r, c) in closed:
            continue
        closed.add((r, c))
        steps += 1
        if (r, c) == (er, ec):
            found = True
            break
        for dr, dc, _diag in _NEIGHBOURS:
            nr, nc = r + dr, (c + dc) % gw
            if nr < 0 or nr >= gh:
                continue
            if (nr, nc) in closed:
                continue
            if (nr, nc) in blocked:
                continue
            cost = cell_cost(r, c, nr, nc)
            if cost is None:
                continue
            tentative = g_score[(r, c)] + cost
            if tentative < g_score.get((nr, nc), float("inf")):
                g_score[(nr, nc)] = tentative
                came_from[(nr, nc)] = (r, c)
                counter += 1
                heapq.heappush(open_heap, (tentative + heuristic(nr, nc), counter, nr, nc))

    if not found:
        return RouteResult(
            ok=False, preset=preset,
            start={"lat": start[0], "lon": start[1]},
            end={"lat": end[0], "lon": end[1]},
            notes=[f"A* did not find a path within {budget} steps "
                   f"(stride {stride}×, {dist_km:.0f} km straight-line).",
                   "Try a less terrain-averse preset, or move endpoints to less extreme terrain."],
            provenance={"engine": f"A* on MOLA MEGDR grid (stride {stride}×)",
                        "advisory": "Regional slopes; advisory only."},
        )

    # Reconstruct
    path = []
    cur = (er, ec)
    while cur != (sr, sc):
        path.append(cur)
        cur = came_from[cur]
    path.append((sr, sc))
    path.reverse()

    # Stats
    waypoints = []
    ascent = 0.0
    descent = 0.0
    total_km = 0.0
    max_slope = 0.0
    slopes = []
    prev_latlon = None
    for (r, c) in path:
        la, lo = _grid_to_latlon(r, c, ppd)
        e = float(elev[r, c])
        s = _slope_at_grid(elev, r, c, ppd)
        slopes.append(s)
        if s > max_slope:
            max_slope = s
        if prev_latlon is not None:
            d = haversine_km(prev_latlon[0], prev_latlon[1], la, lo)
            total_km += d
            prev_e = waypoints[-1]["elev_m"]
            if e > prev_e:
                ascent += (e - prev_e)
            else:
                descent += (prev_e - e)
        prev_latlon = (la, lo)
        waypoints.append({"lat": round(la, 5), "lon": round(lo, 5),
                          "elev_m": round(e, 1), "slope_deg": round(s, 2)})

    # Subsample waypoints to keep payload reasonable (max ~80)
    if len(waypoints) > 80:
        step = max(1, len(waypoints) // 80)
        sampled = waypoints[::step]
        if sampled[-1] != waypoints[-1]:
            sampled.append(waypoints[-1])
        if sampled[0] != waypoints[0]:
            sampled.insert(0, waypoints[0])
        waypoints = sampled

    # Rough sol estimate: 100 m/sol EVA traverse (per v1)
    est_sols = total_km * 1000.0 / 100.0

    return RouteResult(
        ok=True, preset=preset,
        start={"lat": start[0], "lon": start[1]},
        end={"lat": end[0], "lon": end[1]},
        waypoints=waypoints,
        stats=RouteStats(
            length_m=round(total_km * 1000.0, 1),
            length_km=round(total_km, 2),
            ascent_m=round(ascent, 1),
            descent_m=round(descent, 1),
            max_slope_deg=round(max_slope, 2),
            mean_slope_deg=round(sum(slopes) / len(slopes), 2),
            est_sols=round(est_sols, 1),
        ),
        path_cells=len(path),
        notes=[
            f"Planned over {len(path)} cells at {1 / ppd:.2f}° (~{cell_km:.1f} km each at the equator"
            + (f", stride {stride}× for this {dist_km:.0f} km traverse)" if stride > 1 else ")") + ".",
            f"Max slope {max_slope:.1f}° — anything > 20° is major traverse risk (advisory).",
            f"Estimated traverse time {est_sols:.1f} sols at 100 m/sol EVA pace.",
        ],
        provenance={
            "engine": f"A* on MOLA MEGDR grid, 8-connected, stride {stride}×",
            "preset": preset,
            "cost_function": "distance × (1 + (slope/6)² × w_slope + rough/5 × w_rough) − science_bonus",
            "advisory": "Regional MOLA slopes cannot resolve meter-scale obstacles — treat as advisory only.",
            "elevation_source": "MOLA MEGDR 4 px/deg (NASA PDS urn-nasa-pds-mgs_mola_topography_derived)",
            "url": "https://pds-geosciences.wustl.edu/missions/mgs/megdr.html",
        },
    )


# re-export ROUGH constants used internally
from ..data import ROUGH_W, ROUGH_H  # noqa: E402
