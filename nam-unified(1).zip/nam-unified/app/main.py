"""NAM Unified — single FastAPI app integrating the best of all four packages:

  - nam-backend  : the full /api/v1 REST + WebSocket contract (catalogs, terrain
                   analysis, hazard, shelters/water/radiation, storms, presence,
                   preset A* routing, missions/nodes, Walk View, 25-tool
                   deterministic assistant with SSE chat)
  - mars3d       : the C++ terrain cruncher (libterrain.so + numpy fallback),
                   terrain-weighted A*, landing-site scoring, globe JSON layers,
                   the honest dataset registry, and the hybrid multilingual AI
                   (trained 9-language intent classifier + retrieval grounding +
                   optional remote LLM phrasing) — now ALSO powering the
                   assistant's intent routing for queries the regex misses
  - marswalk     : the trained, anti-hallucination place matcher (char-ngram
                   TF-IDF + cosine NN, 115 curated places) served at /search and
                   used by the assistant + gazetteer for typo/paraphrase-tolerant
                   lookups; plus its own globe UI served (with one surgical,
                   md5-verified serve-time patch) at /marswalk/
  - NAM.html     : the flagship self-contained Cesium app, kept BYTE-IDENTICAL
                   (md5-checked at startup) and served at /NAM.html; the root
                   experience is the new unified minimalist app in
                   frontend/unified/ (marswalk field-atlas chrome + MOLA
                   terrain engine + full backend wiring)

Run:  uvicorn app.main:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

import hashlib
import time
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles

from .api.routes import router as api_router, root_router
from .ws.handlers import ws_router
from .data import load_elevation, load_json_data

APP_DIR = Path(__file__).resolve().parent
ROOT_DIR = APP_DIR.parent
FRONTEND_DIR = ROOT_DIR / "frontend"

NAM_HTML = FRONTEND_DIR / "NAM.html"
NAM_HTML_MD5 = "77a7f8febad5d2287be79b4ad876cf1d"  # byte-identity contract

THREE_HTML = FRONTEND_DIR / "three.html"
REFERENCE_UI = FRONTEND_DIR / "reference-ui" / "index.html"
MARSWALK_DIR = FRONTEND_DIR / "marswalk"
MARSWALK_MD5 = {
    "index.html": "5dd743614311a076d47e59d6b2232a8e",
    "app.js": "e168d1d801b976e4adaa72f9053c99a4",
    "styles.css": "9d96c59e3a61f5f7e6efd7f38049b237",
    "README.md": "99f49a2347b6f3292dfd29072dd50b55",
}
MARSWALK_PURE = False  # set True at import if MARSWALK_PURE=1
import os as _os
if _os.environ.get("MARSWALK_PURE", "0") == "1":
    MARSWALK_PURE = True

_INTEGRATION_REPORT: dict = {}


def _md5(data: bytes) -> str:
    return hashlib.md5(data).hexdigest()


# --- marswalk serve-time patch (one surgical edit, disk files untouched) -----
_SEARCH_FN = b"  function searchLocation(query) {"
_SEARCH_FN_ASYNC = b"  async function searchLocation(query) {"
_PLACE_NOT_FOUND = b'    ui.coordinate.textContent = "Place not found \xc2\xb7 try Gale, Jezero or coordinates";'
_MATCHER_FALLBACK = (
    b'    try {\n'
    b'      const _r = await (await fetch("/search?q=" + encodeURIComponent(normalized))).json();\n'
    b'      if (_r && _r.ok) {\n'
    b'        closePanel("search-panel");\n'
    b'        viewer.camera.flyTo({ destination: CesiumLib.Cartesian3.fromDegrees(normalizeLongitude(_r.lon), _r.lat, 690000, MARS), orientation: { heading: 0, pitch: CesiumLib.Math.toRadians(-48), roll: 0 }, duration: 1.7, complete: () => selectLocation(_r.lat, normalizeLongitude(_r.lon)) });\n'
    b'        ui.coordinate.textContent = _r.name + (_r.type ? " \xc2\xb7 " + _r.type : "");\n'
    b'        return;\n'
    b'      }\n'
    b'    } catch (_e) { console.warn("marswalk search backend unavailable", _e); }\n'
    b'    '
)


def _build_boosted_app_js(raw: bytes) -> bytes:
    """The exact surgical patch marswalk's server applies: after the frontend's
    own five hardcoded places and coordinate parser miss, ask the trained
    matcher at /search and fly there with the app's own flyTo."""
    if _SEARCH_FN not in raw:
        raise RuntimeError("searchLocation signature not found in marswalk app.js — refusing to patch")
    if _PLACE_NOT_FOUND not in raw:
        raise RuntimeError("searchLocation fallback line not found in marswalk app.js — refusing to patch")
    out = raw.replace(_SEARCH_FN, _SEARCH_FN_ASYNC, 1)
    out = out.replace(_PLACE_NOT_FOUND, _MATCHER_FALLBACK + _PLACE_NOT_FOUND.strip(), 1)
    return out


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Load every data + engine asset once, verify byte-identity contracts."""
    t0 = time.time()
    report = _INTEGRATION_REPORT

    # 1) nam-backend data layer (MOLA grids + JSON catalogs)
    load_elevation()
    load_json_data()

    # 2) NAM.html byte-identity verification (the flagship contract)
    nam_bytes = NAM_HTML.read_bytes()
    nam_md5 = _md5(nam_bytes)
    report["nam_html"] = {
        "path": str(NAM_HTML), "bytes": len(nam_bytes),
        "md5": nam_md5, "byte_identical": nam_md5 == NAM_HTML_MD5,
    }
    print(f"[NAM unified] NAM.html {len(nam_bytes)} bytes md5={nam_md5} "
          f"{'OK (byte-identical)' if nam_md5 == NAM_HTML_MD5 else 'MISMATCH vs contract'}")

    # 3) marswalk frontend verification + serve-time patch
    mw = {}
    try:
        raw = {}
        for name, expected in MARSWALK_MD5.items():
            p = MARSWALK_DIR / name
            if not p.exists():
                mw[name] = {"present": False}
                continue
            b = p.read_bytes()
            raw[name] = b
            mw[name] = {"present": True, "bytes": len(b),
                        "md5_ok": _md5(b) == expected}
        if raw.get("app.js") and mw["app.js"]["md5_ok"]:
            mw["app_js_served"] = ("original (MARSWALK_PURE=1)" if MARSWALK_PURE
                                   else "surgical matcher patch applied in memory")
            app.state.marswalk = {"raw": raw, "patched": None if MARSWALK_PURE
                                  else _build_boosted_app_js(raw["app.js"])}
        else:
            app.state.marswalk = {"raw": raw, "patched": None}
        mw["enabled"] = bool(raw.get("index.html"))
    except Exception as e:
        mw["error"] = str(e)
        mw["enabled"] = False
        app.state.marswalk = {"raw": {}, "patched": None}
    report["marswalk_frontend"] = mw

    # 4) mars3d engines: C++ cruncher grid warm + hybrid AI model
    cruncher_ok = False
    try:
        from .intel import cruncher, datasets as intel_datasets, hybrid_ai
        intel_datasets.mola()
        z = intel_datasets.mola_small()
        cruncher.compute_grid(z, m_per_px=14820.0 * 4.0, rad=1)  # warm small grid
        cruncher_ok = cruncher.ready()
        hybrid_ai.ready()
        report["intel"] = {
            "cruncher": cruncher.version(), "cruncher_ready": cruncher_ok,
            "ai_model_loaded": hybrid_ai.ready(),
            "ai_engine": hybrid_ai.status()["engine"],
        }
    except Exception as e:
        report["intel"] = {"error": str(e), "cruncher_ready": False}

    # 5) marswalk trained matcher
    try:
        from .match.matcher import get_matcher
        m = get_matcher()
        report["matcher"] = {"places": len(m.places), "aliases": len(m.alias_index),
                             "precision_gate": 0.55}
    except Exception as e:
        report["matcher"] = {"error": str(e)}

    report["boot_seconds"] = round(time.time() - t0, 2)
    print(f"[NAM unified] all engines loaded in {report['boot_seconds']}s -> {report}")
    yield


app = FastAPI(
    title="NAM — Navigation Assistant of Mars (unified)",
    description=(
        "Best-of-all-worlds integration: the nam-backend REST/WebSocket contract "
        "(/api/v1/*), the mars3d terrain cruncher + hybrid AI (/terrain/*, "
        "/route/plan, /landing/score, /globe/*, /ai/*, /datasets, /metrics), the "
        "marswalk trained place matcher (/search) and its globe UI (/marswalk/), "
        "the unified minimalist front-end at /, and the flagship NAM.html "
        "byte-identical at /NAM.html. All scientific "
        "values carry provenance; all simulated values are labelled [SIM]."
    ),
    version="3.0.0-unified",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan,
)

# CORS fix: "*" with allow_credentials=True is invalid per the CORS spec
# (browsers reject credentialed requests against "*"). The unified app uses
# credentials=False so the wildcard is honoured for every origin.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router)      # /api/v1/*
app.include_router(root_router)     # /terrain/*, /route/plan, /ai/*, /search, ...
app.include_router(ws_router)       # /ws/events, /ws/presence


# ---------------------------------------------------------------------------
# Frontend serving — the unified minimalist app is the root experience. The
# legacy frontends stay reachable: NAM.html (byte-identical, md5-checked),
# marswalk (serve-time patched), three.html, reference-ui.
# ---------------------------------------------------------------------------
UNIFIED_DIR = FRONTEND_DIR / "unified"


@app.get("/", response_class=HTMLResponse)
async def root():
    unified = UNIFIED_DIR / "index.html"
    if unified.exists():
        return FileResponse(unified, media_type="text/html; charset=utf-8")
    return FileResponse(NAM_HTML, media_type="text/html; charset=utf-8")


if UNIFIED_DIR.exists():
    app.mount("/unified", StaticFiles(directory=str(UNIFIED_DIR)), name="unified")


@app.get("/NAM.html", response_class=HTMLResponse)
async def nam_html():
    return FileResponse(NAM_HTML, media_type="text/html; charset=utf-8")


@app.get("/three", response_class=HTMLResponse)
async def three():
    """mars3d's legacy Three.js globe (consumes /globe/heightmap + /globe/layers)."""
    if not THREE_HTML.exists():
        raise HTTPException(404, "not found")
    return FileResponse(THREE_HTML, media_type="text/html; charset=utf-8")


@app.get("/reference-ui", response_class=HTMLResponse)
async def reference_ui():
    """nam-backend's endpoint-reference page (self-contained)."""
    if not REFERENCE_UI.exists():
        return HTMLResponse("<h1>NAM unified</h1><p>Reference UI missing.</p>")
    return HTMLResponse(REFERENCE_UI.read_text(encoding="utf-8"))


# --- marswalk UI (original files + one serve-time patch) --------------------
@app.get("/marswalk/", response_class=HTMLResponse)
@app.get("/marswalk", response_class=HTMLResponse)
@app.get("/marswalk/index.html", response_class=HTMLResponse)
async def marswalk_index():
    state = getattr(app.state, "marswalk", None)
    raw = (state or {}).get("raw", {})
    if not raw.get("index.html"):
        raise HTTPException(404, "not found")
    return Response(raw["index.html"], media_type="text/html; charset=utf-8")


@app.get("/marswalk/app.js")
async def marswalk_app_js():
    state = getattr(app.state, "marswalk", None)
    patched = (state or {}).get("patched")
    raw = (state or {}).get("raw", {})
    data = patched if patched is not None else raw.get("app.js")
    if not data:
        raise HTTPException(404, "not found")
    return Response(data, media_type="application/javascript; charset=utf-8")


@app.get("/marswalk/styles.css")
async def marswalk_styles():
    raw = (getattr(app.state, "marswalk", None) or {}).get("raw", {})
    if not raw.get("styles.css"):
        raise HTTPException(404, "not found")
    return Response(raw["styles.css"], media_type="text/css; charset=utf-8")


# --- static data (parity with mars3d's /data mount) -------------------------
app.mount("/data", StaticFiles(directory=str(APP_DIR / "data" / "raw")), name="data")


@app.get("/health")
async def health():
    """Unified liveness: version + every engine's status + the integration report."""
    from .intel import cruncher, hybrid_ai
    from .match.matcher import get_matcher
    try:
        matcher = get_matcher()
        matcher_info = {"places": len(matcher.places), "loaded": True}
    except Exception:
        matcher_info = {"loaded": False}
    return {
        "status": "ok",
        "service": "nam-unified",
        "version": "3.0.0-unified",
        "data_loaded": True,
        "integration": _INTEGRATION_REPORT,
        "components": {
            "nam_backend_api": True,           # /api/v1/* REST + WS + assistant
            "terrain_cruncher": {"ready": cruncher.ready(), "version": cruncher.version()},
            "hybrid_ai": {"ready": hybrid_ai.ready(), "engine": hybrid_ai.status()["engine"]},
            "place_matcher": matcher_info,
            "nam_html_byte_identical": _INTEGRATION_REPORT.get("nam_html", {}).get("byte_identical", False),
        },
        "endpoints": [
            "GET  /                — NAM.html (byte-identical flagship UI)",
            "GET  /NAM.html        — same file, explicit path",
            "GET  /marswalk/       — marswalk globe UI (matcher-augmented search)",
            "GET  /three           — mars3d Three.js globe",
            "GET  /reference-ui    — endpoint reference page",
            "GET  /docs /redoc /openapi.json",
            "GET  /health /healthz /metrics",
            "GET  /api/v1/layers|gazetteer|missions/sites|instruments|targets",
            "GET  /api/v1/layers/{id}/tiles/{z}/{x}/{y} — cached tile proxy",
            "GET  /api/v1/elevation|elevation/profile|terrain/analyze|hazard",
            "GET  /api/v1/shelters|water|radiation|env/storms|presence",
            "POST /api/v1/route|nodes|plans|env/storms/simulate",
            "GET  /api/v1/walk/init|terrain|pov|povs — Walk View feed",
            "GET  /api/v1/assistant/tools — typed tool catalogue",
            "POST /api/v1/assistant/tool/{name} — direct tool invocation",
            "POST /api/v1/assistant/chat — SSE streaming chat (regex + ML intents)",
            "GET  /terrain/sample|terrain/tile|landing/score|route/plan(POST)",
            "GET  /globe/heightmap|globe/layers|datasets|ai/status|ai/ask",
            "GET  /search?q= — trained place matcher (typo + paraphrase tolerant)",
            "WS   /ws/events — storm.alert (now actually broadcast) + presence + telemetry",
            "WS   /ws/presence — 1 Hz agent updates",
        ],
        "provenance": {
            "nam_backend": "REST/WS/assistant/walk/storms — v2.0.0-hack codebase",
            "terrain_engine": "mars3d C++ cruncher (libterrain.so, numpy fallback)",
            "hybrid_ai": "mars3d nam-nlp-1.0 model (9 languages, 26 intents) + retrieval",
            "place_matcher": "marswalk char-ngram TF-IDF + cosine NN, 115 places",
            "flagship_ui": "NAM.html (self-contained Cesium, served byte-identical)",
            "elevation_grid": "MOLA MEGDR 4 px/deg, 1440×720, embedded (NASA PDS)",
            "roughness_grid": "MOLA roughness 1 px/deg, 360×180 (NASA PDS)",
        },
    }


@app.exception_handler(Exception)
async def global_exc_handler(request: Request, exc: Exception):
    import traceback
    return JSONResponse(
        status_code=500,
        content={"error": str(exc), "traceback": traceback.format_exc()[-2000:]},
    )
