"""mars3d terrain cruncher + hybrid AI engine (integrated modules)."""
