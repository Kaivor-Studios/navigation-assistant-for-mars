"""Unified integration tests — exercise every endpoint group of the merged
system (nam-backend contract + mars3d engine + marswalk matcher + frontend
byte-identity) against the app in-process.

Run:  cd nam-unified && python -m pytest tests/test_unified.py -v
"""
import hashlib
import json

import pytest
from fastapi.testclient import TestClient

from app.main import app, NAM_HTML_MD5

EXPECTED_NAM_MD5 = NAM_HTML_MD5


@pytest.fixture(scope="module")
def client():
    # lifespan runs: loads grids, warms cruncher, loads AI model + matcher,
    # verifies NAM.html + marswalk frontend byte-identity
    with TestClient(app) as c:
        yield c


# ---------------------------------------------------------------------------
# Frontend serving contracts
# ---------------------------------------------------------------------------

def test_nam_html_byte_identical(client):
    # The legacy flagship stays byte-identical at /NAM.html (root now serves
    # the unified minimalist app).
    r2 = client.get("/NAM.html")
    assert r2.status_code == 200
    assert hashlib.md5(r2.content).hexdigest() == EXPECTED_NAM_MD5


def test_root_serves_unified_frontend(client):
    r = client.get("/")
    assert r.status_code == 200
    assert b"NAM" in r.content and b"cesiumContainer" in r.content
    js = client.get("/unified/app.js")
    assert js.status_code == 200 and b"createViewer" in js.content
    css = client.get("/unified/style.css")
    assert css.status_code == 200 and b"--acc" in css.content


def test_reference_ui_and_three(client):
    assert client.get("/reference-ui").status_code == 200
    r = client.get("/three")
    assert r.status_code == 200 and b"three" in r.content.lower() or b"THREE" in r.content


def test_marswalk_frontend_served_and_patched(client):
    r = client.get("/marswalk/")
    assert r.status_code == 200
    js = client.get("/marswalk/app.js")
    assert js.status_code == 200
    # the surgical patch must be present in the SERVED bytes...
    assert b'fetch("/search?q=" + encodeURIComponent(normalized))' in js.content
    # ...while the app must still contain its own original five places
    assert b"Gale" in js.content
    css = client.get("/marswalk/styles.css")
    assert css.status_code == 200 and b"body" in css.content


def test_health_unified(client):
    r = client.get("/health")
    assert r.status_code == 200
    body = r.json()
    assert body["service"] == "nam-unified"
    assert body["components"]["nam_html_byte_identical"] is True
    assert body["components"]["terrain_cruncher"]["ready"] in (True, False)
    assert body["components"]["hybrid_ai"]["ready"] is True
    assert body["components"]["place_matcher"]["places"] >= 100


def test_healthz_mars3d_contract(client):
    r = client.get("/healthz")
    assert r.status_code == 200
    body = r.json()
    assert body["grid"]["w"] == 1440 and body["grid"]["h"] == 720
    assert body["ai_model"] is True


# ---------------------------------------------------------------------------
# nam-backend /api/v1 contract
# ---------------------------------------------------------------------------

def test_layers_and_tile_proxy(client):
    r = client.get("/api/v1/layers")
    assert r.status_code == 200
    layers = r.json()["layers"]
    assert len(layers) == 6
    opm = [l for l in layers if l["id"].startswith("opm-")]
    assert len(opm) == 3 and all(l["url"] for l in opm)


def test_catalogs(client):
    assert len(client.get("/api/v1/missions/sites").json()["sites"]) == 13
    assert len(client.get("/api/v1/instruments").json()["instruments"]) == 13
    assert len(client.get("/api/v1/targets").json()["targets"]) == 16
    g = client.get("/api/v1/gazetteer", params={"q": "olympus"}).json()
    assert g["count"] >= 1 and any("Olympus" in f["name"] for f in g["features"])


def test_elevation_olympus(client):
    r = client.get("/api/v1/elevation", params={"lat": 18.65, "lon": 226.2})
    assert r.status_code == 200
    elev = r.json()["elev_m"]
    assert 19000 < elev < 23000, f"Olympus Mons elevation implausible: {elev}"


def test_elevation_profile(client):
    r = client.get("/api/v1/elevation/profile",
                   params={"points": "18.65,226.2,-42.4,70.0"})
    assert r.status_code == 200
    body = r.json()
    assert body["count"] > 1 and len(body["profile"]) == body["count"]


def test_hazard_and_terrain_analyze(client):
    h = client.get("/api/v1/hazard", params={"lat": 18.65, "lon": 226.2}).json()
    assert h["hazard_class"] in ("low", "moderate", "high", "extreme")
    assert 0 <= h["hazard_score"] <= 100
    t = client.get("/api/v1/terrain/analyze",
                   params={"lat": 18.65, "lon": 226.2, "radius_km": 100}).json()
    assert t["grid_shape"][0] > 1 and len(t["elev_grid"]) > 1


def test_shelters_water_radiation(client):
    s = client.get("/api/v1/shelters", params={"lat": 18.44, "lon": 77.45}).json()
    assert s["count"] >= 1 and "scores" in s["shelters"][0]
    w = client.get("/api/v1/water", params={"lat": 70.0, "lon": 0.0}).json()
    assert w["count"] >= 1
    r = client.get("/api/v1/radiation", params={"lat": 18.44, "lon": 77.45}).json()
    assert r["dose_mSv_per_day"] > 0
    rp = client.get("/api/v1/radiation", params={"path": "18.44,77.45,18.6,77.7"}).json()
    assert rp["total_dose_mSv"] > 0 and rp["path_length_km"] > 0


def test_storms_simulate_and_broadcast(client):
    r = client.post("/api/v1/env/storms/simulate",
                    params={"kind": "dust", "severity": "regional", "lat": 18.4, "lon": 77.4})
    assert r.status_code == 200
    body = r.json()
    event = body["event"]
    assert event["kind"] == "dust" and event["id"]
    # integration fix: the alert is now really broadcast
    assert body["alert_broadcast"] is True
    got = client.get("/api/v1/env/storms", params={"kind": "dust"}).json()
    assert any(e["id"] == event["id"] for e in got["events"])
    one = client.get(f"/api/v1/env/storms/{event['id']}").json()
    assert one["id"] == event["id"]


def test_route_presets(client):
    req = {"start_lat": 18.4447, "start_lon": 77.4508,
           "end_lat": -5.4, "end_lon": 137.4, "preset": "balanced"}
    r = client.post("/api/v1/route", json=req)
    assert r.status_code == 200
    body = r.json()
    assert body["stats"] is not None or body["ok"] is False
    if body["stats"]:
        assert body["stats"]["length_km"] > 1000


def test_nodes_crud(client):
    n = client.post("/api/v1/nodes", json={
        "name": "Cache A", "type": "cache", "lat": 18.44, "lon": 77.45,
        "radius_m": 50, "properties": {"contents": "spare battery"}}).json()["node"]
    nid = n["id"]
    assert client.get(f"/api/v1/nodes/{nid}").json()["name"] == "Cache A"
    assert len(client.get("/api/v1/nodes", params={"type": "cache"}).json()["nodes"]) >= 1
    client.patch(f"/api/v1/nodes/{nid}", json={"name": "Cache A2"})
    assert client.get(f"/api/v1/nodes/{nid}").json()["name"] == "Cache A2"
    assert client.delete(f"/api/v1/nodes/{nid}").json()["deleted"] is True


def test_plans_lifecycle(client):
    m = client.post("/api/v1/plans", json={
        "name": "Delta traverse", "objective": "Sample the Jezero delta",
        "kind": "route"}).json()["mission"]
    mid = m["id"]
    wp = client.post(f"/api/v1/plans/{mid}/waypoints",
                     json={"lat": 18.4447, "lon": 77.4508, "name": "Landing"}).json()["waypoint"]
    st = client.post(f"/api/v1/plans/{mid}/stops",
                     json={"lat": 18.47, "lon": 77.5, "reason": "science",
                           "activity": "drill"}).json()["stop"]
    assert wp["id"] and st["activity"] == "drill"
    assert len(client.get("/api/v1/plans").json()["missions"]) >= 1
    # persist a computed route onto the mission (UI planner contract), then
    # export it as KML — the KML must contain the planned path coordinates
    rr = client.post("/api/v1/route", json={
        "start_lat": 18.4447, "start_lon": 77.4508,
        "end_lat": 20.0, "end_lon": 80.0, "preset": "speed"}).json()
    assert rr["ok"] is True and len(rr["waypoints"]) > 1
    pr = client.post(f"/api/v1/plans/{mid}/route", json={
        "waypoints": rr["waypoints"], "stats": rr["stats"], "preset": "speed"})
    assert pr.status_code == 200 and pr.json()["mission"]["route"]["waypoints"]
    ex = client.post("/api/v1/assistant/tool/export_mission",
                     json={"mission_id": mid, "format": "kml"}).json()["result"]
    # planned-path waypoints snap to MOLA cell centres (0.25° grid), so the
    # KML LineString must contain the snapped end cell of the planned route
    assert "<kml" in ex["kml"] and "80.0,20.0" in ex["kml"]
    assert client.delete(f"/api/v1/plans/{mid}").json()["deleted"] is True


def test_walk_view(client):
    w = client.get("/api/v1/walk/init", params={"lat": 18.4447, "lon": 77.4508}).json()
    assert w["eye_height_m"] == 1.7 and w["fov_deg"] == 75.0
    t = client.get("/api/v1/walk/terrain",
                   params={"lat": 18.4447, "lon": 77.4508, "radius_m": 500}).json()
    n = t["grid_shape"][0]
    assert n >= 3 and len(t["heights_m"]) == n * n
    p = client.get("/api/v1/walk/povs").json()
    assert p["count"] == 7


def test_assistant_tools_catalogue(client):
    r = client.get("/api/v1/assistant/tools").json()
    names = [t["name"] for t in r["tools"]]
    assert len(names) >= 24
    for expected in ("search_planetary_location", "generate_route", "find_shelter",
                     "plan_storm_response", "simulate_storm", "enter_walk_view"):
        assert expected in names


def test_direct_tool_invocation(client):
    r = client.post("/api/v1/assistant/tool/search_planetary_location",
                    json={"q": "Olympus Mons"})
    assert r.status_code == 200
    result = r.json()["result"]
    assert "error" not in result


def test_assistant_chat_sse(client):
    with client.stream("POST", "/api/v1/assistant/chat",
                       json={"message": "find shelters near Olympus Mons"}) as r:
        assert r.status_code == 200
        events = []
        for line in r.iter_lines():
            if line.startswith("data: "):
                events.append(json.loads(line[6:]))
    kinds = [e["type"] for e in events]
    assert "done" in kinds
    tool_calls = [e for e in events if e["type"] == "tool_call"]
    assert tool_calls and tool_calls[0]["tool"] == "find_shelter"


# ---------------------------------------------------------------------------
# mars3d engine endpoints (root level)
# ---------------------------------------------------------------------------

def test_terrain_sample_and_tile(client):
    s = client.get("/terrain/sample", params={"lat": 18.65, "lon": 226.2}).json()
    assert 19000 < s["elev_m"] < 23000 and s["slope_deg"] >= 0
    t = client.get("/terrain/tile", params={"lat": 18.65, "lon": 226.2, "size": 2}).json()
    assert len(t["grid"]) == 5 and len(t["grid"][0]) == 5


def test_route_plan_cpp(client):
    r = client.post("/route/plan", json={
        "src": {"lat": 18.4447, "lon": 77.4508},
        "dst": {"lat": 17.0, "lon": 79.0},
        "weights": {"slope": 1.0, "rough": 0.5, "hazard": 1.0}})
    assert r.status_code == 200
    body = r.json()
    assert body["n"] >= 2 and body["length_km"] > 50


def test_landing_score(client):
    r = client.get("/landing/score", params={"lat": 18.4447, "lon": 77.4508}).json()
    assert 0 <= r["score"] <= 100 and r["n_cells"] >= 1


def test_globe_layers_and_heightmap(client):
    hm = client.get("/globe/heightmap").json()
    assert hm["w"] == 360 and hm["h"] == 180 and len(hm["data"]) == 64800
    gl = client.get("/globe/layers").json()
    assert len(gl["slope"]) == 64800 and len(gl["hazard"]) == 64800


def test_ai_ask_local(client):
    r = client.get("/ai/ask", params={"q": "What is the tallest volcano on Mars?"}).json()
    assert r["answer"] and "Olympus" in r["answer"]
    assert r["engine"] in ("local", "gemini", "openai")


def test_datasets_and_metrics(client):
    d = client.get("/datasets").json()
    assert len(d["sources"]) == 6
    m = client.get("/metrics").json()
    assert m["data"]["features"] == 102
    assert m["matcher"]["places"] >= 100


# ---------------------------------------------------------------------------
# marswalk trained matcher
# ---------------------------------------------------------------------------

def test_matcher_typo_tolerance(client):
    r = client.get("/search", params={"q": "olympous mons"}).json()
    assert r["ok"] is True and "Olympus" in r["name"]


def test_matcher_paraphrase(client):
    r = client.get("/search", params={"q": "tallest volcano"}).json()
    assert r["ok"] is True and "Olympus" in r["name"]
    r2 = client.get("/search", params={"q": "curiosity rover"}).json()
    assert r2["ok"] is True and "Gale" in r2["name"]


def test_matcher_anti_hallucination(client):
    r = client.get("/search", params={"q": "pizza"}).json()
    assert r["ok"] is False
    r2 = client.get("/search", params={"q": "new york"}).json()
    assert r2["ok"] is False


def test_api_v1_search_alias(client):
    r = client.get("/api/v1/search", params={"q": "hellas"}).json()
    assert r["ok"] is True and "Hellas" in r["name"]
    assert "elev_m" in r  # enriched from the MOLA grid


# ---------------------------------------------------------------------------
# Assistant: ML-first intent routing (multilingual + paraphrases)
# ---------------------------------------------------------------------------

def _chat(client, message):
    with client.stream("POST", "/api/v1/assistant/chat",
                       json={"message": message}) as r:
        return [json.loads(l[6:]) for l in r.iter_lines() if l.startswith("data: ")]


def _chat_text(events):
    return "".join(e.get("text", "") for e in events if e["type"] == "token")


def test_assistant_flagship_phrases(client):
    """The 8 flagship demo phrases must all route to something useful."""
    # 1. navigation + facts
    ev = _chat(client, "Take me to Olympus Mons")
    assert any(e["type"] == "fly_to" for e in ev)
    assert "Olympus Mons" in _chat_text(ev)
    # 2. landing-site listing → result payload drives the UI overlay
    ev = _chat(client, "Show me all major landing sites")
    res = [e for e in ev if e["type"] == "result"]
    assert res and len(res[0]["result"]["sites"]) == 13
    # 3. site comparison
    ev = _chat(client, "Compare Jezero and Gale crater")
    assert "Jezero" in _chat_text(ev) and "Gale" in _chat_text(ev) and "154" in _chat_text(ev)
    # 4. ancient-water regions → water candidates for markers
    ev = _chat(client, "Find regions with evidence of ancient water")
    res = [e for e in ev if e["type"] == "result"]
    assert res and len(res[0]["result"]["water_candidates"]) >= 1
    # 5. historical rover traverse (honest: documented, not live)
    ev = _chat(client, "Show me Perseverance's route")
    assert "traverse" in _chat_text(ev).lower() and any(e["type"] == "fly_to" for e in ev)
    # 6. highest mountains → live MOLA-sampled ranking
    ev = _chat(client, "Show me the highest mountains on Mars")
    assert "Olympus Mons" in _chat_text(ev) and "Ascraeus" in _chat_text(ev)
    # 7/8 covered by the ML tests below (current context + formations near here)


def test_assistant_ml_multilingual_fly_to(client):
    with client.stream("POST", "/api/v1/assistant/chat",
                       json={"message": "带我去奥林匹斯山"}) as r:
        events = [json.loads(l[6:]) for l in r.iter_lines() if l.startswith("data: ")]
    kinds = [e["type"] for e in events]
    assert "done" in kinds
    fly = [e for e in events if e["type"] == "fly_to"]
    assert fly, "Chinese navigation query should produce a fly_to"
    # Olympus Mons is around 18.65N 226.2E
    lat, lon = fly[0]["lat"], fly[0]["lon"]
    assert 15 < lat < 23 and 220 < lon < 232


def test_assistant_ml_paraphrase_action(client):
    with client.stream("POST", "/api/v1/assistant/chat",
                       json={"message": "I need the safest shelter close to Olympus Mons"}) as r:
        events = [json.loads(l[6:]) for l in r.iter_lines() if l.startswith("data: ")]
    tool_calls = [e for e in events if e["type"] == "tool_call"]
    assert tool_calls and tool_calls[0]["tool"] == "find_shelter"


# ---------------------------------------------------------------------------
# WebSocket contracts
# ---------------------------------------------------------------------------

def test_ws_presence_and_events(client):
    with client.websocket_connect("/ws/presence") as ws:
        hello = json.loads(ws.receive_text())
        assert hello["type"] == "hello" and hello["channel"] == "presence"
        snap = json.loads(ws.receive_text())
        assert snap["type"] == "presence.update" and snap["agents"]
    with client.websocket_connect("/ws/events") as ws:
        hello = json.loads(ws.receive_text())
        assert hello["type"] == "hello" and "storm.alert" in hello["subscribed"]
        tick = json.loads(ws.receive_text())
        assert tick["type"] == "telemetry.tick"


def test_ws_storm_alert_broadcast(client):
    """The integration fix: simulating a storm pushes storm.alert to /ws/events."""
    import threading
    got = {}
    ready = threading.Event()

    def reader():
        with client.websocket_connect("/ws/events") as ws:
            hello = json.loads(ws.receive_text())
            ready.set()
            # drain telemetry ticks until the storm alert arrives (≤6s)
            for _ in range(10):
                msg = json.loads(ws.receive_text())
                if msg["type"] == "storm.alert":
                    got["alert"] = msg
                    return

    t = threading.Thread(target=reader, daemon=True)
    t.start()
    assert ready.wait(5), "reader never connected"
    client.post("/api/v1/env/storms/simulate",
                params={"kind": "sep", "severity": "X-flare-class", "lat": 18.4, "lon": 77.4})
    t.join(timeout=10)
    assert "alert" in got, "storm.alert was not broadcast to /ws/events"
    assert got["alert"]["event"]["kind"] == "sep"
