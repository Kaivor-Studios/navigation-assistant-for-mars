GHOSTTRACE LIVE SENSOR PROTOTYPE
================================

This build does NOT contain a guided demo or generated measurements.
It requires real DeviceMotion events from a phone browser.

FILES
-----
index.html  The complete standalone app. No external libraries or network APIs.

HOW TO OPEN ON YOUR PHONE
-------------------------
Device motion is restricted to secure contexts in modern browsers. The most reliable
way to test is to host this folder over HTTPS, then open that HTTPS link on your phone.

One straightforward option:
1. On a computer, create a free static-site deployment using a hosting service that
   provides HTTPS (for example, Netlify Drop or GitHub Pages).
2. Upload this folder with index.html at the site root.
3. Open the generated HTTPS address on your Android phone in Chrome, or on iPhone in
   Safari.
4. Tap “Enable phone sensor” and grant motion permission if the browser asks.
5. Move the phone gently. The live value and sample count should change.

You can also try opening the file directly on a phone, but browser security rules may
block motion sensors for local files. HTTPS is recommended.

TEST PROCEDURE
--------------
1. Build a small tabletop tower. Do not use or test a real building.
2. Select the floor where the phone is attached and select the axis aligned with the
   direction the model will move.
3. Strap the phone securely to that floor. Do not hold it by hand during a recording.
4. Tap “Record baseline”. During the 12-second countdown, gently pull the model a
   small distance sideways and release it once. Keep hands away while it vibrates.
5. Change one brace in the model.
6. Keep the phone in the same position and orientation. Repeat the same pull-and-release
   procedure with “Record after change”.
7. Compare the measured frequencies and export the raw CSV if required.

IMPORTANT LIMITATIONS
---------------------
- A single phone measures motion only at the floor where it is attached. It does not
  automatically locate damage across all floors. Move the same phone floor by floor
  and record a baseline/after pair for each floor if you want a multi-floor survey.
- The frequency estimate uses a windowed FFT on the real browser motion samples. The
  sample stream can be noisy, irregular, low-rate, filtered, or affected by how the
  phone is mounted. Some captures will be rejected as inconclusive.
- The stiffness estimate uses k2/k1 ~= (f2/f1)^2 and assumes comparable effective mass
  and vibration mode. This is a simplified model experiment, not a calibrated structural
  engineering method.
- Never use results to decide whether a real building is safe or safe to re-enter.
- No readings are uploaded. Measurement summaries stay in the current page session.

TROUBLESHOOTING
---------------
- “HTTPS required”: deploy over HTTPS and reopen the link.
- No live samples: use a phone browser, not a laptop; grant motion permission; make sure
  the page is in the foreground and the device supports motion events.
- Recording rejected: secure the phone, reduce hand contact, align the chosen axis with
  the model motion, use a more visible but gentle pull-and-release, and repeat.
- The first attempt is not a calibration. Repeat a few times and compare consistency.
