# MARSWALK — planetary atlas

MARSWALK is a static HTML/CSS/JavaScript frontend using CesiumJS and public NASA/JPL Mars Trek imagery.

## Run locally

1. Extract the ZIP.
2. Open the `marswalk_frontend` folder in VS Code.
3. Open a terminal in that folder and run:

```bash
py -m http.server 8000
```

4. Open `http://localhost:8000` in your browser.

Do not open `index.html` directly as `file://`. CesiumJS and NASA/JPL imagery are loaded from external services, so an internet connection is required.

## Deploy to Netlify

1. Sign in at https://app.netlify.com/.
2. Choose **Add new site** → **Deploy manually**.
3. Extract the ZIP on your computer.
4. Drag the `marswalk_frontend` folder (the folder containing `index.html`) into the Netlify deploy area.
5. Wait for the upload to finish. Netlify will provide a public website URL.

No build command is required. The publish directory is the frontend root (`marswalk_frontend/`). If configuring a Git-based deploy, use an empty build command and set the publish directory to `marswalk_frontend`.

## Home experience

- Cinematic MARSWALK introduction with the locked charcoal, graphite, copper and sandstone palette.
- Delayed heading/description/button reveal.
- Oversized, unframed GPU-rendered WebGL Mars globe using a locally bundled high-detail panoramic Mars surface texture, procedural micro-relief, slow rotation, atmospheric rim light and cursor-responsive orientation. A CSS fallback is retained for browsers without WebGL.
- Both **ENTER THE ATLAS** and selecting the planet reveal the existing CesiumJS atlas.
- Responsive desktop and mobile layouts, with reduced-motion support.

The homepage hero is a real WebGL-rendered sphere using a GPU fragment shader and a locally bundled panoramic Mars surface texture (`assets/mars-surface-texture.png`). Procedural micro-relief adds fine surface variation. The globe is intentionally oversized and shown without orbital rings or decorative spacecraft; it rotates slowly, responds to pointer movement, and has a soft atmospheric rim. The existing CesiumJS atlas remains intact and initializes behind the introduction. A CSS fallback appears if WebGL is unavailable.

## Existing atlas functionality

- Full-screen globe with locally generated six-face star skybox.
- Viking MDIM 2.1 global colour mosaic as the default basemap; MOLA colour hillshade as an alternate.
- Mars Trek equirectangular overlays, base-map switching and opacity controls.
- Custom XYZ / REST WMTS tile URL input.
- Data catalogue linking to NASA/JPL, PDS, USGS, THEMIS, HiRISE and rover-image sources.
- Location search, featured locations, point inspection and route sketching.
- Map image export and GeoJSON traverse export.

## Map services and scientific limitations

The default basemap is `Mars_Viking_MDIM21_ClrMosaic_global_232m`, a global Viking colour mosaic listed in the Mars Trek equirectangular service catalogue. It uses the Mars 2000 geographic/equirectangular grid.

The base globe uses Mars 2000 equatorial and polar radii (3,396,190 m and 3,376,200 m). Connected overlay tile templates use the Mars Trek equirectangular services and a geographic tiling scheme. A custom layer must use Mars equirectangular coordinates (EPSG:104905) and an XYZ-style template containing `{z}`, `{y}` and `{x}`.

The globe is a textured Mars ellipsoid, not a high-resolution terrain mesh. Mission markers are regional reference points, not current rover coordinates or landing ellipses. Route length is an approximate spherical surface-distance calculation; it does not account for terrain elevation, slope, obstacles, energy, communications, radiation, thermal conditions or mobility constraints. It must not be described as a safe route.

## Files

- `index.html` — entry experience and atlas interface
- `styles.css` — MARSWALK visual system and responsive layout
- `home.js` — WebGL Mars hero renderer, local surface texture loading, pointer interaction, reduced-motion handling and entry transition
- `assets/mars-surface-texture.png` — locally bundled panoramic Mars surface texture for the homepage hero
- `app.js` — Cesium globe, NASA imagery, layer manager, data catalogue and traversal tools

## Notes

- CesiumJS and imagery are external services. Their availability, CORS policy and terms are controlled by their providers.
- The Python/C++ NAM backend is not included in this static frontend ZIP. Backend API features require separate hosting and integration.
