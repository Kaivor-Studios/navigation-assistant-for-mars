(() => {
  "use strict";
  const home = document.getElementById("mars-home");
  const app = document.querySelector(".map-app");
  const planetButton = document.getElementById("planet-launch");
  const fallbackPlanet = document.getElementById("hero-planet");
  const canvas = document.getElementById("mars-webgl");
  const enterButton = document.getElementById("enter-atlas");
  if (!home || !app || !planetButton || !fallbackPlanet || !canvas || !enterButton) return;

  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  let entering = false;
  let gl = null;
  let animationFrame = 0;
  let program = null;
  let startTime = 0;
  let pointerX = 0;
  let pointerY = 0;
  let targetX = 0;
  let targetY = 0;
  let resizeObserver = null;
  let marsTexture = null;
  let textureReady = false;

  function enterAtlas() {
    if (entering) return;
    entering = true;
    home.classList.add("is-entering");
    app.classList.add("is-entered");
    if (animationFrame) cancelAnimationFrame(animationFrame);
    window.setTimeout(() => {
      home.hidden = true;
      const globeCanvas = document.querySelector("#cesiumContainer canvas");
      if (globeCanvas) globeCanvas.focus?.();
    }, 1050);
  }
  enterButton.addEventListener("click", enterAtlas);
  planetButton.addEventListener("click", enterAtlas);

  // A real WebGL sphere rendered with a ray/sphere intersection shader.
  // The procedural albedo is generated on the GPU, so no external texture is required.
  const vertexSource = `
    attribute vec2 a_position;
    varying vec2 v_uv;
    void main() {
      v_uv = a_position * 0.5 + 0.5;
      gl_Position = vec4(a_position, 0.0, 1.0);
    }
  `;
  const fragmentSource = `
    precision highp float;
    varying vec2 v_uv;
    uniform vec2 u_resolution;
    uniform float u_time;
    uniform vec2 u_pointer;
    uniform float u_motion;
    uniform sampler2D u_marsTexture;

    float hash31(vec3 p) {
      p = fract(p * 0.1031);
      p += dot(p, p.yzx + 33.33);
      return fract((p.x + p.y) * p.z);
    }
    float noise3(vec3 x) {
      vec3 i = floor(x), f = fract(x);
      f = f * f * (3.0 - 2.0 * f);
      return mix(mix(mix(hash31(i), hash31(i+vec3(1.0,0.0,0.0)),f.x),
                      mix(hash31(i+vec3(0.0,1.0,0.0)),hash31(i+vec3(1.0,1.0,0.0)),f.x),f.y),
                 mix(mix(hash31(i+vec3(0.0,0.0,1.0)),hash31(i+vec3(1.0,0.0,1.0)),f.x),
                      mix(hash31(i+vec3(0.0,1.0,1.0)),hash31(i+vec3(1.0,1.0,1.0)),f.x),f.y),f.z);
    }
    float fbm(vec3 p) {
      float v = 0.0, a = 0.5;
      for (int i=0; i<5; i++) { v += a * noise3(p); p *= 2.03; a *= 0.5; }
      return v;
    }
    void main() {
      vec2 centered = (v_uv - 0.5) * 2.0;
      centered.x *= u_resolution.x / u_resolution.y;
      float r2 = dot(centered, centered);
      if (r2 > 1.0) discard;
      float z = sqrt(max(0.0, 1.0-r2));
      vec3 n = normalize(vec3(centered.x, centered.y, z));
      float yaw = u_time * 0.105 + u_pointer.x * 0.22;
      float pitch = u_pointer.y * 0.12;
      mat3 ry = mat3(cos(yaw),0.0,-sin(yaw), 0.0,1.0,0.0, sin(yaw),0.0,cos(yaw));
      mat3 rx = mat3(1.0,0.0,0.0, 0.0,cos(pitch),sin(pitch), 0.0,-sin(pitch),cos(pitch));
      vec3 p = rx * ry * n;
      // Equirectangular Mars surface texture: real-looking global geology,
      // with procedural micro-relief layered over the albedo for depth.
      vec2 marsUV = vec2(atan(p.z, p.x) / 6.2831853 + 0.5,
                         asin(clamp(p.y, -1.0, 1.0)) / 3.14159265 + 0.5);
      vec3 textureColor = texture2D(u_marsTexture, marsUV).rgb;
      float land = fbm(p * 10.0 + vec3(1.7, 0.4, 2.1));
      float detail = fbm(p * 42.0 + vec3(0.0, 4.0, 1.0));
      float fine = noise3(p * 125.0);
      float relief = (land - 0.5) * 0.13 + (detail - 0.5) * 0.055 + (fine - 0.5) * 0.018;
      vec3 albedo = textureColor * (0.91 + relief);
      float polarDust = smoothstep(0.88, 0.995, abs(p.y));
      albedo = mix(albedo, vec3(0.63, 0.43, 0.32), polarDust * 0.34);
      float light = max(dot(n, normalize(vec3(-0.48,0.32,0.82))), 0.0);
      float ambient = 0.16;
      float limb = smoothstep(-0.16,0.22,z);
      float shade = (ambient + light*0.98) * limb;
      vec3 color = albedo * shade;
      float rim = pow(1.0-z, 3.0);
      color += vec3(0.72,0.30,0.17) * rim * 0.55;
      color += vec3(0.32,0.105,0.055) * pow(1.0-z, 7.0) * 0.8;
      gl_FragColor = vec4(color, 1.0);
    }
  `;

  function compileShader(type, source) {
    const shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
      const message = gl.getShaderInfoLog(shader) || "Unknown shader compilation error";
      gl.deleteShader(shader);
      throw new Error(message);
    }
    return shader;
  }

  function initWebGL() {
    try {
      gl = canvas.getContext("webgl", { alpha: true, antialias: true, powerPreference: "high-performance" }) ||
           canvas.getContext("experimental-webgl", { alpha: true, antialias: true });
      if (!gl) throw new Error("WebGL is unavailable in this browser.");
      const vertex = compileShader(gl.VERTEX_SHADER, vertexSource);
      const fragment = compileShader(gl.FRAGMENT_SHADER, fragmentSource);
      program = gl.createProgram();
      gl.attachShader(program, vertex);
      gl.attachShader(program, fragment);
      gl.linkProgram(program);
      if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(program) || "WebGL program link failed.");
      gl.useProgram(program);
      // Load the locally bundled high-detail Mars albedo texture. It is served
      // with the site, so the hero does not depend on a third-party image host.
      marsTexture = gl.createTexture();
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, marsTexture);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE,
                    new Uint8Array([118, 55, 35, 255]));
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.uniform1i(gl.getUniformLocation(program, "u_marsTexture"), 0);
      const surfaceImage = new Image();
      surfaceImage.onload = () => {
        if (!gl || !marsTexture) return;
        gl.bindTexture(gl.TEXTURE_2D, marsTexture);
        gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, surfaceImage);
        gl.generateMipmap(gl.TEXTURE_2D);
        textureReady = true;
      };
      surfaceImage.onerror = () => console.warn("MARSWALK: bundled Mars texture could not be loaded; procedural fallback remains active.");
      surfaceImage.src = "./assets/mars-surface-texture.png";
      const buffer = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1, 1,-1, -1,1, -1,1, 1,-1, 1,1]), gl.STATIC_DRAW);
      const position = gl.getAttribLocation(program, "a_position");
      gl.enableVertexAttribArray(position);
      gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);
      gl.uniform2f(gl.getUniformLocation(program, "u_pointer"), 0, 0);
      canvas.classList.add("is-webgl-ready");
      fallbackPlanet.hidden = true;
      resize();
      if ("ResizeObserver" in window) {
        resizeObserver = new ResizeObserver(resize);
        resizeObserver.observe(planetButton);
      } else window.addEventListener("resize", resize, { passive: true });
      canvas.addEventListener("webglcontextlost", (event) => {
        event.preventDefault();
        if (animationFrame) cancelAnimationFrame(animationFrame);
        canvas.classList.remove("is-webgl-ready");
        fallbackPlanet.hidden = false;
      });
      startTime = performance.now();
      if (!reducedMotion) animationFrame = requestAnimationFrame(draw);
      else draw(performance.now());
    } catch (error) {
      console.warn("MARSWALK WebGL hero unavailable; using the static CSS fallback.", error);
      if (gl) gl = null;
      canvas.classList.remove("is-webgl-ready");
      fallbackPlanet.hidden = false;
    }
  }

  function resize() {
    if (!gl) return;
    const rect = planetButton.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const cssWidth = rect.width * 0.90;
    const cssHeight = rect.height * 0.90;
    const width = Math.max(1, Math.round(cssWidth * dpr));
    const height = Math.max(1, Math.round(cssHeight * dpr));
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
      canvas.style.width = `${cssWidth}px`;
      canvas.style.height = `${cssHeight}px`;
      gl.viewport(0, 0, width, height);
    }
    gl.uniform2f(gl.getUniformLocation(program, "u_resolution"), width, height);
  }

  function draw(now) {
    if (!gl || entering) return;
    pointerX += (targetX-pointerX) * 0.055;
    pointerY += (targetY-pointerY) * 0.055;
    gl.useProgram(program);
    gl.uniform1f(gl.getUniformLocation(program, "u_time"), (now-startTime)/1000);
    gl.uniform2f(gl.getUniformLocation(program, "u_pointer"), pointerX, pointerY);
    gl.uniform1f(gl.getUniformLocation(program, "u_motion"), reducedMotion ? 0 : 1);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
    animationFrame = requestAnimationFrame(draw);
  }

  if (!reducedMotion) {
    planetButton.addEventListener("pointermove", (event) => {
      const rect = planetButton.getBoundingClientRect();
      targetX = ((event.clientX-rect.left)/rect.width - 0.5) * 2;
      targetY = ((event.clientY-rect.top)/rect.height - 0.5) * 2;
      fallbackPlanet.style.setProperty("--ry", `${targetX * 13}deg`);
      fallbackPlanet.style.setProperty("--rx", `${-targetY * 11}deg`);
      fallbackPlanet.style.setProperty("--px", `${targetX * 7}px`);
      fallbackPlanet.style.setProperty("--py", `${targetY * 7}px`);
    });
    planetButton.addEventListener("pointerleave", () => {
      targetX = 0; targetY = 0;
      fallbackPlanet.style.setProperty("--ry", "0deg");
      fallbackPlanet.style.setProperty("--rx", "0deg");
      fallbackPlanet.style.setProperty("--px", "0px");
      fallbackPlanet.style.setProperty("--py", "0px");
    });
  }
  document.addEventListener("visibilitychange", () => {
    if (document.hidden && animationFrame) cancelAnimationFrame(animationFrame);
    else if (!document.hidden && gl && !reducedMotion && !entering) animationFrame = requestAnimationFrame(draw);
  });
  initWebGL();
})();
