# NAM — Run & Train (the short version)

Two folders, both already in this download:

- **`mars3d/`** — the app: C++ cruncher + Python middle-end + the friend's
  `NAM.html` Cesium frontend (served verbatim, untouched).
- **`nam_train/`** — the AI training toolkit (data + scripts). You retrain the
  local model yourself and drop it into the backend.

The AI in the backend **smart-switches** between **Gemini** (if you set a key)
and the **local trained model** (the "python script AI"), with automatic
fallback to local on any Gemini failure.

---

## 1. Run the app (backend + frontend)

```bash
cd mars3d/backend
pip install -r requirements.txt        # fastapi, uvicorn, numpy, pydantic
python3 server.py                      # http://localhost:8000
```

Open **http://localhost:8000/** → loads `NAM.html` (3D Mars globe).

- No C++ compiler? Fine — `cruncher.py` auto-falls-back to a pure-numpy path
  with identical results. To compile for speed: Linux/macOS `./build.sh`,
  Windows `build.bat` (needs MinGW `g++`).

## 2. Train the AI yourself (the commands)

```bash
cd nam_train
pip install -r requirements.txt        # scikit-learn, numpy
python3 build_data.py                  # regenerate multilingual data (9 langs, 26 intents)
python3 train_model.py                 # train -> nam_model.json (prints CV metrics)
cp nam_model.json ../mars3d/data/nam_model.json   # drop into the backend
```

Then restart `python3 server.py`. Verify:

```bash
curl -s "http://localhost:8000/ai/ask?q=Tell%20me%20about%20Olympus%20Mons" | python3 -m json.tool
curl -s http://localhost:8000/metrics        # cv_accuracy, per-language, counts
python3 evaluate_model.py                    # full report + confusion + live demo
```

That is the whole loop: **build_data → train_model → cp → restart**.
Latest measured: 6172 examples, CV acc **0.943**, functional command intents
(navigate/route/mission/landing) **0.98–1.00**, English held-out **0.969**.

## 3. Smart switching: Gemini ⇄ local Python model

The local model is always the fallback. Add Gemini as the primary phrasing
engine by setting one env var before starting the backend:

```bash
export NAM_GEMINI_API_KEY="your_gemini_key"     # Google AI Studio key
export NAM_GEMINI_MODEL="gemini-1.5-flash"      # optional; default
cd mars3d/backend && python3 server.py
```

How it switches (automatic, per call):

- `GET /ai/status` → `{"engine":"gemini"}` while the key is set,
  `{"engine":"local"}` when it is not.
- For each question, Gemini is tried **only if** the local classifier is
  confident (≥ 0.45) and the intent is informational
  (feature / mission / instrument / planet-fact / …). Functional commands
  (navigate / route / mission / landing) never call Gemini.
- The retrieved catalog facts are fed to Gemini as grounding, so it cannot
  invent coordinates, elevations or observations.
- If Gemini errors (network / auth / quota / timeout), the answer
  **auto-falls-back** to the local model and the JSON carries
  `"fallback": true, "remote_error": "HTTP 400"` (or similar). The answer is
  still correct.

A secondary OpenAI-compatible endpoint is also supported
(`NAM_LLM_API_URL` / `NAM_LLM_API_KEY` / `NAM_LLM_MODEL`); Gemini takes
priority if both are set.

```bash
curl -s http://localhost:8000/ai/status
curl -s http://localhost:8000/healthz | python3 -m json.tool     # ai_engine field
```

## 4. The endpoints (backend API — parallel to the frontend)

| method | path | what |
| --- | --- | --- |
| GET | `/` | serves `NAM.html` (the friend's frontend, untouched) |
| GET | `/healthz` | engine + dataset + cruncher + **ai_engine** status |
| GET | `/ai/status` | which AI engine is live (gemini / openai / local) |
| GET | `/ai/ask?q=&lang=` | smart-switching AI answer |
| GET | `/terrain/sample?lat=&lon=` | elev, slope, rough, hazard (C++/numpy) |
| GET | `/terrain/tile?lat=&lon=&size=` | small-region grid stats |
| POST | `/route/plan` | C++ A* polyline + length/ascent |
| GET | `/landing/score?lat=&lon=&radius_km=` | NASA-style 0..100 landing score |
| GET | `/globe/layers` | 360×180 slope/rough/hazard for color layers |
| GET | `/datasets` | local + NASA source registry |
| GET | `/metrics` | accuracy + counts |

## 5. Accuracy (measured, honest)

- **Deterministic geospatial** (terrain / route / landing): exact by
  construction — Olympus 20,708 m, Hellas −6,151 m, Gale→Jezero 4,375 km,
  Jezero landing 61/100, all verified against the embedded MOLA.
- **AI intent classifier**: CV **94.3 %** overall; **98–100 %** on the
  functional command intents the plan emphasizes; English held-out 96.9 %.
  To push overall to 97 %+ see `nam_train/README.md` §7 (add examples for the
  confused pairs, tune `--c`, extend the ar/fr lexicons).

## 6. Note on the frontend

`NAM.html` is **self-contained**: Cesium + embedded MOLA (client-side
`CustomHeightmapTerrainProvider`) + OPM tiles + a rule-based assistant
(`answerQuestion` / `planIntents`). It makes **no calls** to the Python backend,
so it is unaffected by retraining or by the Gemini key. The backend `/ai/ask`
and friends are the trained-model + C++ path — usable now from curl / any
client, and ready for a future frontend to wire in. The frontend was not
modified (md5-verified copy).
