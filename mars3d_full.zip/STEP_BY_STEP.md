# NAM — Full Step-by-Step Walkthrough

This is the complete, ordered process: from the zip you downloaded to a running
3-D Mars app with a smart-switching AI, including how to retrain the local model
and improve it with your own corrections. The short command-only version lives in
`RUN_AND_TRAIN.md`; this file explains each step.

Everything below was executed and verified in the sandbox that built the zip.
Toolchain used: **Python 3.12**, **g++ 14** (optional), Linux x86-64.

---

## 0. What's in the download

| file | what it is |
|---|---|
| `mars3d_full.zip` | everything: the app + the training toolkit + this doc |
| `mars3d.zip` | the app only (`mars3d/`) |
| `nam_train.zip` | the training toolkit only (`nam_train/`) |
| `RUN_AND_TRAIN.md` | short command-only cheat sheet |
| `STEP_BY_STEP.md` | this file |

Inside `mars3d/`:
```
mars3d/
├─ backend/   server.py (FastAPI), hybrid_ai.py (AI), cruncher.py + terrain.cpp
│             + libterrain.so (prebuilt C++ for x86-64 Linux), datasets.py,
│             build.sh / build.bat, requirements.txt
├─ data/      nam_model.json (the trained AI), mola elevation arrays,
│             gazetteer.json, mola_heightmap.png
├─ frontend/  NAM.html (your friend's Cesium page, served verbatim), index.html
├─ README.md, ARCHITECTURE.md, shot_orbit.png, shot_surface.png
```
Inside `nam_train/`: `build_data.py`, `train_model.py`, `evaluate_model.py`,
`collect_feedback.py`, `intents.json`, `responses.json`, `entities.json`,
`nam_model.json`, `requirements.txt`, `README.md`.

**Prerequisites:** Python 3.10+ and `pip`. A C++ compiler (`g++`/`clang++`, or
MinGW on Windows) is *optional* — a prebuilt `libterrain.so` ships for x86-64
Linux, and `cruncher.py` auto-falls-back to pure NumPy (same results, ~50×
slower) if no library is found. No GPU, no SciPy/PyTorch at runtime.

---

## 1. Unzip

```bash
unzip mars3d_full.zip        # or: unzip mars3d.zip   (app only)
cd mars3d                    # you are now in the app root
```

You should see `backend/ data/ frontend/ README.md ARCHITECTURE.md`.

---

## 2. Install the backend dependencies

```bash
cd mars3d/backend
pip install -r requirements.txt
```

That installs only four packages: `fastapi`, `uvicorn`, `numpy`, `pydantic`. The
trained model is a plain JSON file scored in pure Python, so there is **no
scikit-learn / scipy / PyTorch needed to run the app** — they are only used when
you *train* (Step 7).

---

## 3. (Optional) Build or verify the C++ terrain cruncher

A prebuilt `libterrain.so` (20 KB, ELF x86-64) ships inside `backend/`, so on
matching Linux you can skip this. On macOS / Windows / other arch, rebuild it:

```bash
cd mars3d/backend
./build.sh          # Linux/macOS -> g++ -O3 -fPIC -shared terrain.cpp -o libterrain.so
# Windows (MinGW): build.bat
```

If the build fails or you have no compiler, **do nothing** — `cruncher.py` will
transparently use its pure-NumPy reference path. Results are identical; only
speed differs. You can confirm which path is active later via `/healthz`
(`cruncher` field) in Step 5.

---

## 4. Start the server

```bash
cd mars3d/backend
python3 server.py
```

You'll see uvicorn boot lines ending with `Uvicorn running on http://0.0.0.0:8000`.
The server mounts the frontend, the API, and the data files. Default port is
**8000**. Open **http://localhost:8000/** in a browser.

What loads: the Cesium 3-D Mars globe (`NAM.html`, served byte-for-byte — your
friend's file is not modified). Terrain imagery, MOLA elevation, and the camera
controls all work from the static assets in `data/`; the page itself makes zero
backend calls until you interact with it.

---

## 5. Confirm it's healthy

In another terminal:

```bash
curl -s http://localhost:8000/healthz | python3 -m json.tool
```

Expected fields (verified): `"status":"ok"`, `"cruncher":"nam-terrain-1.0 g++-O3"`
(or `numpy-fallback` if you skipped the C++ build), `"cruncher_ready":true`,
`"ai_model":true`, `"ai_engine":"local"`, `"ai_remote_configured":false`.

```bash
curl -s http://localhost:8000/ai/status
curl -s http://localhost:8000/metrics
```

`/metrics` reports the loaded model's CV accuracy (0.9431), per-language held-out
accuracy, intent/example counts, and the dataset counts (102 features, 13 sites,
13 instruments, 6 NASA sources).

---

## 6. Use the app + talk to the local AI

In the browser you can drop pins, request routes, score landing sites, and ask
the AI questions in the chat. The same calls work over HTTP — useful for testing:

```bash
# "Tell me about Olympus Mons" -> local model answers, grounded in the catalog
curl -s -X POST http://localhost:8000/ai/ask \
     -H 'Content-Type: application/json' \
     -d '{"text":"Tell me about Olympus Mons","lang":"en"}' | python3 -m json.tool
```

Verified reply: `engine: local`, `intent: feature_info`, `conf: 0.97`, answer
cites Olympus Mons at 21,287 m as the largest known volcano. Try other endpoints
the frontend uses: `/terrain/sample?lat=18.4&lon=77.7`,
`/route/plan?from=...&to=...`, `/landing/score?lat=18.4&lon=77.7&radius_km=50`,
`/globe/layers`, `/globe/heightmap`, `/datasets`.

The local model is a TF-IDF + L1-regularized logistic-regression classifier
trained on **6,172 multilingual examples across 26 intents and 9 languages**
(en/zh/es/fr/de/ru/ar/hi/ja), with a retrieval layer that grounds answers in the
embedded NASA-derived Mars catalog. It runs entirely offline.

---

## 7. Train the model yourself

The shipped `mars3d/data/nam_model.json` is already trained, so this step is
optional — do it only when you want to regenerate or improve the model.

```bash
cd nam_train
pip install -r requirements.txt     # scikit-learn, numpy
python3 build_data.py               # regenerate intents.json/responses.json/entities.json
python3 train_model.py              # train -> nam_model.json, prints CV metrics
python3 evaluate_model.py           # classification report + 9-language live demo
```

Verified output of `train_model.py`: 5-fold CV accuracy **0.9431**, macro-F1
0.85, weighted-F1 0.95; per-language held-out accuracy 0.89 (ar) … 0.97 (en).
Verified output of `evaluate_model.py`: a full per-intent precision/recall table,
the top confused pairs (e.g. `help → greet`), and a live demo that scored
**12/12 correct across all 9 languages**.

`build_data.py` is deterministic (`random.seed(7)`), so re-running it reproduces
the same 6,172 examples unless you edit the lexicons or merge feedback.

---

## 8. Drop the freshly trained model into the backend

```bash
cp nam_train/nam_model.json mars3d/data/nam_model.json
```

Then restart `python3 server.py` (the model is loaded once at startup). Confirm
the new metrics appear at `/metrics`. The frontend needs no change — it never
loads the model directly; it only talks to `/ai/ask`.

---

## 9. Switch the AI to Gemini (smart switching)

The backend automatically uses **Gemini** when a key is present and **the local
model** when not — no code change, no restart-of-frontend. Set the key and
restart the server:

```bash
export NAM_GEMINI_API_KEY="your_real_key"      # or: setx NAM_GEMINI_API_KEY ... on Windows
export NAM_GEMINI_MODEL="gemini-1.5-flash"     # optional; this is the default
python3 server.py
```

Verify the switch took effect:

```bash
curl -s http://localhost:8000/healthz | python3 -m json.tool
# -> "ai_engine":"gemini", "ai_remote_configured":true, "ai_remote_model":"gemini-1.5-flash"
```

**How the smart switch behaves (verified with a deliberately bogus key):** the
server reports `ai_engine: gemini`, calls Gemini for phraseable intents
(terrain/feature/planet facts, etc.) with the local model's classification as
context; if Gemini errors (bad key, network, quota — seen as `HTTP 400`), the
server **automatically falls back** to the local model and still returns a
correct, grounded answer with `fallback: true` and `remote_error` set. Unset the
key (`unset NAM_GEMINI_API_KEY`) and restart to go back to pure-local.

---

## 10. Improve the model with your own corrections (the retrain loop)

The loop is safe to run repeatedly: `build_data.py` **preserves** examples merged
by `collect_feedback.py` across regenerations (tracked by the `feedback_merged`
counter in `intents.json`), so corrections are never wiped.

1. Collect questions `/ai/ask` got wrong, and write them into
   `nam_train/nam_feedback.json` with the correct intent:
   ```json
   [ {"text": "bring me to valles marineris", "intent": "navigate", "lang": "en"} ]
   ```
   (The field may also be called `corrected` — both are accepted.)
2. Merge + retrain + drop in:
   ```bash
   cd nam_train
   python3 collect_feedback.py          # merges into intents.json (dedupes)
   python3 train_model.py
   cp nam_model.json ../mars3d/data/nam_model.json
   ```
3. Restart `python3 server.py`. Re-running `build_data.py` first is fine — your
   merged corrections survive.

Verified behaviour: two new examples merged (6172 → 6174), survived a
`build_data.py` regeneration (`feedback_merged: 2`), and a second merge skipped
them as dupes (no double-add). Duplicates are matched on `(text, lang)`.

---

## 11. Troubleshooting

- **`Address already in use` on port 8000** — another `server.py` is still
  running. Find and stop it: `pgrep -af "^python3 server\.py"` then
  `kill <pid>`. (Anchored pattern avoids killing your own shell.)
- **`cruncher` shows `numpy-fallback`** — `libterrain.so` didn't load. Rebuild
  with `./build.sh`; the app still works, just slower.
- **C++ build fails** — missing `g++`. Install `build-essential` (Debian/Ubuntu)
  or Xcode CLT (macOS), or simply skip — the NumPy fallback is correct.
- **Gemini answers but you didn't set a key** — impossible; `ai_engine` is
  `local` unless `NAM_GEMINI_API_KEY` is set. Check `/healthz`.
- **Gemini returns errors / `fallback: true`** — verify the key, model name, and
  network. The local model keeps the app fully functional in the meantime.
- **`/metrics` shows old numbers after retrain** — you forgot to copy the model
  or restart the server. Repeat Step 8.
- **Frontend loads but AI says "I'm not sure"** — `mars3d/data/nam_model.json`
  is missing or corrupt; re-copy from `nam_train/nam_model.json`.

---

## 12. Quick command recap (the whole flow)

```bash
# run the app
cd mars3d/backend
pip install -r requirements.txt
python3 server.py                          # http://localhost:8000

# (optional) switch AI to Gemini
export NAM_GEMINI_API_KEY=...; python3 server.py

# (optional) retrain the local model yourself
cd nam_train
pip install -r requirements.txt
python3 build_data.py && python3 train_model.py && python3 evaluate_model.py
cp nam_model.json ../mars3d/data/nam_model.json   # then restart server.py

# (optional) feed your corrections back in
# edit nam_feedback.json, then:
python3 collect_feedback.py && python3 train_model.py
cp nam_model.json ../mars3d/data/nam_model.json   # then restart server.py
```

That is the entire process. The frontend (`NAM.html`) is never modified — its
md5 is `77a7f8febad5d2287be79b4ad876cf1d`, identical to the file your friend
handed over.
