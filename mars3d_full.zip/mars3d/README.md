# NAM 3D — Mars (3D globe + C++/Python/Cesium stack)

A Google-Earth-style 3D Mars system: **C++ number cruncher** (backend) +
**Python middle-end** (FastAPI) + **Cesium frontend `NAM.html`** (your friend's,
served verbatim, untouched) + a **hybrid AI** with smart switching between
Gemini and the local trained model. Runs on 8 GB. See `ARCHITECTURE.md` for the
full plan.

## Quickstart

```bash
cd backend
pip install -r requirements.txt    # fastapi, uvicorn, numpy, pydantic
python3 server.py                  # http://localhost:8000
```

**That's it — the server runs immediately without compiling anything.** If no
compiled C++ library is present, `cruncher.py` automatically uses a pure-numpy
reference path that produces identical results (verified: Olympus slope 4.15°,
A* Gale→Jezero 275 waypoints, Jezero landing 45.0) — just a bit slower. This is
the path Windows uses out of the box.

### Optional: compile the C++ cruncher for full speed (~50–100× faster terrain compute)

- **Linux**: `./build.sh`  → produces `libterrain.so`
- **macOS**: `./build.sh`  → produces `libterrain.dylib`
- **Windows**: `build.bat` → produces `terrain.dll`  (needs MinGW-w64 `g++` on PATH;
  install via MSYS2 `pacman -S mingw-w64-ucrt-x86_64-gcc`)

`cruncher.py` auto-detects the right file per platform. If you skip compiling,
the numpy fallback handles everything.

Open `http://localhost:8000/` → loads `NAM.html` (the Cesium 3D Mars globe).
The frontend is self-contained (Cesium + embedded MOLA + OPM tiles + a rule-based
assistant) and runs standalone. The backend's `/ai/ask`, `/terrain`, `/route`,
`/landing` endpoints are the trained-model + C++ path — usable from curl or any
client, and ready for a future frontend to call.

## Smart AI switching (Gemini ⇄ local Python model)

The backend AI (`hybrid_ai.py`) auto-switches per call:

- **Gemini** if `NAM_GEMINI_API_KEY` is set → grounds the answer with the local
  retrieval corpus first, then asks Gemini to phrase it (cannot hallucinate
  beyond the catalog).
- **Local trained model** (`data/nam_model.json`, TF-IDF + L1 LogReg) otherwise,
  or automatically if Gemini fails (network/auth/quota/timeout).
- Functional command intents (navigate / route / mission / landing) never call
  Gemini — they stay local and execute tools.

```bash
export NAM_GEMINI_API_KEY="your_key"     # optional; omit to stay fully local
python3 server.py
curl -s http://localhost:8000/ai/status   # -> {"engine":"gemini"} or {"engine":"local"}
curl -s "http://localhost:8000/ai/ask?q=Tell%20me%20about%20Olympus%20Mons"
```

A secondary OpenAI-compatible endpoint is also supported (`NAM_LLM_API_URL` /
`NAM_LLM_API_KEY` / `NAM_LLM_MODEL`); Gemini takes priority if both are set.

## Platform notes

- The shipped `libterrain.so` is a **Linux x86-64** binary. On Windows/macOS,
  either run `build.bat`/`build.sh` to recompile, or just run `python3 server.py`
  directly (numpy fallback).
- Python 3.10+ (tested on 3.12 and 3.15). numpy, fastapi, uvicorn, pydantic are
  the only runtime deps.

## What's here

- `frontend/NAM.html` — your friend's Cesium 3D Mars globe, served **verbatim,
  untouched** (embedded MOLA heightmap via `CustomHeightmapTerrainProvider`,
  OPM basemap/colour/hillshade tiles, rule-based assistant + planner). Self-
  contained; no backend calls.
- `backend/terrain.cpp` + `libterrain.so` — C++ cruncher (slope/rough/hazard,
  A* routing, NASA landing-site scorer), called via ctypes (numpy fallback if
  not compiled).
- `backend/server.py` — FastAPI middle-end (`/terrain /route /landing /ai/ask
  /ai/status /globe /datasets /metrics /healthz`); serves `NAM.html` at `/`.
- `backend/hybrid_ai.py` — **smart-switching AI**: Gemini (if key) ⇄ local
  trained model, auto-fallback, retrieval-grounded.
- `data/` — real local datasets: MOLA heightmap (720×1440, verified Olympus
  20,708 m / Hellas −6,151 m), gazetteer (102 features), trained AI model
  (`nam_model.json` — retrain with `nam_train/`).

## Accuracy (measured, not promised)

- Deterministic geospatial compute (slope/route/landing): exact by construction.
- AI intent classifier: **94.3 % overall CV**, ~98–100 % on functional command
  intents, **18/18 (100 %)** on the live multilingual demo. Full table in
  `ARCHITECTURE.md`. Retrain with the `nam_train/` toolkit to push higher.

## NASA-practical

Landing-site scoring (Jezero = 61/100), terrain-optimized A* routing
(Gale→Jezero, 4,375 km), hazard layer, and honest provenance — every value
traces to the embedded NASA/PDS MOLA or the IAU/USGS gazetteer; the NASA source
URLs are listed in `/datasets` with their real streamable status.
