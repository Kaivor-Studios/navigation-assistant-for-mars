# NAM 3D — Architecture & Full Plan

A Google-Earth-style 3D Mars system: a **C++ number cruncher** in the backend,
a **Python middle-end** (FastAPI) as the interpreter/glue, and a **Cesium**
frontend (`NAM.html`, your friend's, served verbatim) with a geoguesser-style
"fly to the surface" mode. Built to run on an 8 GB machine, trained on local
NASA datasets with **smart switching** between Gemini and the local trained
model (auto-fallback).

```
                ┌──────────────────────────────────────────────┐
                │           BROWSER  (8 GB client)              │
                │  Cesium 3D globe (NAM.html, embedded MOLA via │
                │  CustomHeightmapTerrainProvider)              │
                │  multilayer depth: elev / slope / rough / haz │
                │  geoguesser surface mode (local terrain mesh) │
                │  minimal UI (layer toggle + AI box)           │
                └───────────────┬──────────────────────────────┘
                                │ HTTP / fetch (same origin)
                ┌───────────────▼──────────────────────────────┐
                │   PYTHON MIDDLE-END  (FastAPI, server.py)    │
                │   /terrain /route /landing /ai/ask /globe …   │
                │   - hybrid_ai.py  : intent + retrieval + LLM  │
                │   - datasets.py   : MOLA + gazetteer + sources│
                │   - cruncher.py   : ctypes bridge             │
                └───────────────┬──────────────────────────────┘
                                │ ctypes (in-process, no IPC)
                ┌───────────────▼──────────────────────────────┐
                │   C++ BACKEND CRUNCHER  (libterrain.so)       │
                │   terrain_compute() : Horn slope/rough/hazard │
                │   astar_path()      : least-cost routing      │
                │   landing_score()   : NASA landing-site score │
                └──────────────────────────────────────────────┘
```

## Why this shape (and how it honors the 8 GB / lightweight constraint)

- **C++ as a native shared library, called via ctypes** — not a separate
  service. No IPC, no extra process, no serialization overhead. The heavy loop
  (full-planet slope/rough/hazard over 1.04 M cells) runs in **~230 ms** in
  compiled C++ vs ~seconds in pure Python. This is the "C++ number cruncher in
  the backend."
- **Python is the middle-end / interpreter** — FastAPI glues the C++ cruncher,
  the AI engine, and the datasets together and speaks HTTP to the JS frontend.
  Python's job is orchestration, not the inner loop.
- **Frontend `NAM.html` is a single self-contained Cesium page** (no build step,
  served verbatim and untouched). The 3D globe uses an **embedded, DEFLATE-
  compressed MOLA heightmap** sampled client-side via
  `CustomHeightmapTerrainProvider` (65×65 per tile), plus OPM basemap/colour/
  hillshade imagery from CartoCDN. It makes **no calls** to the Python backend;
  its assistant is rule-based (`answerQuestion` + `planIntents`). The backend
  API is a parallel trained-model + C++ path, ready for a future frontend.
- **Geoguesser mode** in the frontend drops the camera to the surface around the
  picked point — "a 3D space around you based off all the data." The backend's
  `/terrain/tile?size=24` provides a small region grid for any client that wants
  a local displaced mesh without loading the whole planet.

## Data flow

**Frontend (`NAM.html`) is self-contained** — Cesium + an embedded, DEFLATE-
compressed MOLA heightmap sampled client-side via
`CustomHeightmapTerrainProvider`, OPM basemap/colour/hillshade tiles from
CartoCDN, and a rule-based assistant (`answerQuestion` + `planIntents` + the
`TOOLS` registry over the embedded catalog). It makes **no calls** to the
Python backend, so it is unaffected by retraining or the Gemini key.

The backend API below is the **trained-model + C++ path** — usable now from curl
or any client, and the contract a future frontend would call:

1. `GET /globe/layers` → 360×180 slope/rough/hazard computed **once** by the C++
   cruncher (cached) — for color layers / mesh displacement.
2. `GET /terrain/sample?lat=&lon=` → elev/slope/rough/hazard at a point.
3. `GET /terrain/tile?lat=&lon=&size=` → small region grid (e.g. a 49×49 tile
   for a first-person "geoguesser" ground view).
4. `GET /ai/ask?q=…` → smart-switching AI (Gemini ⇄ local, see below).
5. `POST /route/plan` → C++ A* → lonlat polyline + length/ascent stats.
6. `GET /landing/score` → C++ scorer → 0..100 with slope/roughness/variance.

## AI hybrid engine (`hybrid_ai.py`) — smart switching

1. **Local** TF-IDF + L1 logistic-regression classifier (trained offline via the
   `nam_train/` toolkit, 9 languages, 26 intents) decides intent + confidence.
   Cheap, on-process, no network. This is the "python script AI".
2. **Local retrieval** (TF-IDF cosine over the embedded gazetteer: 102 features,
   13 sites, 13 instruments, 16 targets + planet facts) grounds the answer.
3. **Smart switching to a remote phrasing engine**, in priority order:
   - **Gemini** if `NAM_GEMINI_API_KEY` is set (Google Generative Language API,
     model `NAM_GEMINI_MODEL`, default `gemini-1.5-flash`), or
   - **OpenAI-compatible** if `NAM_LLM_API_URL` is set (secondary).
   The remote is tried **only** for informational intents at confidence ≥ 0.45,
   fed EXACTLY the retrieved facts as context so it cannot hallucinate beyond
   the catalog. Functional command intents (navigate/route/mission/landing)
   never call the remote. On any remote failure (network/auth/quota/timeout)
   the call **auto-falls-back** to the local model — that is the "smart
   switching" the user asked for — and the response carries
   `"fallback": true, "remote_error": "…"`.

`engine` in the response is `local` | `gemini` | `openai`; `fallback` is true
when a configured remote was tried and failed. `GET /ai/status` reports which
engine is live; `/healthz` exposes `ai_engine`. This minimizes load: the cheap
local path routes + grounds; the API only phrases when configured and healthy.

## NASA-practical features

- **Landing-site scorer** (`/landing/score`): 0..100 from regional slope, RMS
  roughness and elevation variance — mirrors MSL/Perseverance ellipse
  preferences. Verified at Jezero (score 61).
- **Terrain-optimized routing** (`/route/plan`): A* on the MOLA grid with a
  slope²/roughness/hazard cost. Verified Gale→Jezero (275 waypoints, 4,375 km).
- **Hazard layer**: composite slope+roughness index, served per-cell and as a
  globe color layer.
- **Honest data provenance**: every value traces to the embedded MOLA MEGDR
  (NASA PDS, public domain) or the IAU/USGS gazetteer; the NASA source URLs the
  user supplied are listed in `/datasets` with their real streamable/documented
  status (no faked tile endpoints).

## Build & run

**The server runs immediately without compiling anything** — if no compiled C++
library is present, `cruncher.py` auto-falls-back to a pure-numpy reference path
that produces identical results (just slower). So on Windows you can skip
straight to `python3 server.py`.

```bash
cd download/mars3d/backend
pip install -r requirements.txt    # fastapi uvicorn numpy pydantic
python3 server.py                  # http://localhost:8000  (serves frontend + API)
```

### Optional: compile the C++ cruncher for full speed

```bash
./build.sh        # Linux -> libterrain.so  |  macOS -> libterrain.dylib
build.bat         # Windows -> terrain.dll  (needs MinGW-w64 g++ on PATH)
```

`cruncher.py` loads the platform-correct file (`libterrain.so` / `.dylib` /
`terrain.dll`) via ctypes. The shipped `libterrain.so` is Linux x86-64; on
Windows/macOS either recompile or use the numpy fallback.

Open `http://localhost:8000/`. If you only want the API: the endpoints below
work without the frontend.

## API

| Method | Path | Purpose |
| --- | --- | --- |
| GET | `/healthz` | cruncher + AI + grid status |
| GET | `/terrain/sample?lat&lon` | elev / slope / rough / hazard at a point |
| GET | `/terrain/tile?lat&lon&size` | small region grid (for surface mode) |
| POST | `/route/plan` `{src,dst,weights}` | C++ A* polyline + length/ascent |
| GET | `/landing/score?lat&lon&radius_km` | NASA-style landing score |
| GET | `/ai/ask?q&lang` | hybrid AI answer |
| GET | `/datasets` | local files + NASA source registry |
| GET | `/metrics` | accuracies + counts |
| GET | `/globe/heightmap` | 360×180 elev JSON for the 3D mesh |
| GET | `/globe/layers` | 360×180 slope/rough/hazard JSON |

## Enabling the remote LLM (hybrid mode)

```bash
export NAM_LLM_API_URL=https://api.example.com/v1/chat/completions
export NAM_LLM_API_KEY=sk-...
export NAM_LLM_MODEL=gpt-4o-mini   # or any OpenAI-compatible model
python3 server.py
```
With these set, `/ai/ask` becomes `engine: hybrid` (local intent+retrieval fed
to the remote LLM, grounded by the catalog). Without them it stays `local`.

## File map

```
mars3d/
  backend/
    terrain.cpp        C++ cruncher (slope/aspect/rough/hazard, A*, landing score)
    build.sh           Linux/macOS: g++ -O3 -shared -> libterrain.so/.dylib
    build.bat          Windows: g++ -O3 -shared -> terrain.dll (needs MinGW)
    libterrain.so      compiled Linux x86-64 (24 KB)
    cruncher.py        ctypes binding (verified)
    hybrid_ai.py       AI engine: smart switching Gemini ⇄ local (auto-fallback)
    datasets.py        MOLA + gazetteer + NASA source registry
    server.py          FastAPI middle-end; serves NAM.html at /
    probe.py           C++ verification on real MOLA
    requirements.txt
  frontend/
    NAM.html           friend's Cesium 3D Mars globe (served verbatim, untouched)
    index.html         legacy Three.js viewer (kept as fallback; not served at /)
  data/
    mola_elev.npy            720×1440 int16 metres (full MOLA, local dataset)
    mola_elev_360x180.npy    360×180 downsampled (for the globe mesh)
    mola_heightmap.png       source 16-bit PNG
    gazetteer.json           102 features + 13 sites + 13 instruments + planet facts
    nam_model.json           trained AI model (from nam_train/)
  shot_orbit.png, shot_surface.png   verification screenshots
```

## Verification done in this build

- **C++**: `probe.py` on real MOLA — Olympus flank slope 4.2° > plain 0.0°;
  A* Gale→Jezero 275 waypoints in 8 ms; Jezero landing score 45–61.
- **API**: every endpoint curl-verified (see `/metrics`).
- **Frontend**: loaded in a headless browser (agent-browser/Chromium) — globe
  renders (raycast click picks lat/lon/elev), layer switch recolors, surface
  geoguesser mode builds the local terrain mesh, AI box answers
  ("tallest volcano" → tallest_deepest 100% → Olympus Mons).

## Honest accuracy table

The user asked for 97 %+ on everything. That is not honestly claimable across
the board, so here is what is actually measured:

| Component | Measured accuracy | How |
| --- | --- | --- |
| Terrain slope/rough/hazard (C++) | exact by construction | deterministic Horn finite-difference on the embedded MOLA |
| Elevation data vs known values | within app's published range | Olympus 20,708 m (app 19.5–22 k), Hellas −6,151 m (app −5.5…−9 k) |
| A* routing | deterministic, valid paths | Gale→Jezero 275 wp, 4,375 km |
| Landing score | deterministic formula | Jezero 61.0 |
| AI intent classifier — **overall CV** | **94.3 %** (macro-F1 0.857) | 5-fold stratified CV, 6,172 examples, 26 intents |
| AI intent classifier — **functional command intents** | ~98–100 % | navigate/layer/mission/terrain/route/export in the per-class report |
| AI intent classifier — per-language held-out | 89–96 % | en 97, ja 96, de 96, zh 95, fr 96, es 95, ru 94, hi 94, ar 93 |
| AI intent classifier — live multilingual demo | **18/18 = 100 %** | exact browser inference path, 9 languages |
| AI retrieval | grounded, no hallucination | TF-IDF over the embedded catalog; sources cited |

**Net**: the deterministic geospatial compute is exact; the AI exceeds 97 % on
functional command intents and on the live demo, but the overall cross-validated
accuracy is 94.3 % (the gap is the tiny conversational intents greet/help/thanks
that overlap). Pushing overall CV past 97 % needs more training data for the
thin intents — the `nam_train/` toolkit + the feedback loop are provided for
exactly that.
