# NAM — Multilingual AI Training Toolkit

This trains the **NAM AI intent model** (`nam_model.json`) — the *local* engine of
the backend's hybrid AI in `mars3d/backend/hybrid_ai.py`. It is a trained,
multilingual intent classifier (TF-IDF + L1 logistic regression) backed by a
retrieval corpus over the embedded NASA-derived Mars catalog. You can retrain it
on your own machine in a few seconds and feed your own corrections back in.

> **Where the model is used.** The trained `nam_model.json` is loaded by the
> **Python backend** (`hybrid_ai.py`) and exposed at `GET /ai/ask`. It is the
> "python script AI" half of the **smart switching** engine:
> - if `NAM_GEMINI_API_KEY` is set → Gemini phrases the answer (grounded by the
>   local retrieval below);
> - otherwise, or if Gemini fails → this local model answers, automatically.
>
> The shipped frontend `NAM.html` has its **own** rule-based assistant
> (`answerQuestion` + `planIntents`) and does not call the backend, so it is
> unaffected by retraining. The backend `/ai/ask` is the trained-model path —
> usable from curl, a future frontend, or any client.

- **9 languages**: English, 中文, Español, Français, Deutsch, Русский, العربية, हिन्दी, 日本語
- **26 intents** mapped to the app's map/data tools + knowledge answers
- **~6,200 labeled utterances**, generated from per-language lexicons + native templates
- Cross-validated accuracy ≈ **94.3 % overall**; **functional command intents
  (navigate / create_mission / generate_route / activate_layer / landing) ≈ 98–100 %**;
  held-out per-language 89–97 % (English 96.9 %)
- The exported model is a single **~96 KB JSON** file — no GPU, no API key

---

## 1. Install (one time)

```bash
cd download/nam_train
python3 -m pip install -r requirements.txt     # scikit-learn, numpy
```

Requires Python ≥ 3.9.

## 2. Train the model (the exact commands)

```bash
# regenerate the multilingual training data from the lexicons
python3 build_data.py

# train + write nam_model.json (prints cross-validated metrics)
python3 train_model.py
```

You should see:

```
examples=6172  classes=26  vocab=1865
CV acc = 0.943 ± 0.007
CV F1  = 0.852 ± 0.022
held-out accuracy by language:
  en: 0.969   zh: 0.935   es: 0.941   fr: 0.927   de: 0.957
  ru: 0.942   ar: 0.892   hi: 0.936   ja: 0.957
wrote nam_model.json  (96 KB, 1418 nonzero weights)
```

## 3. Drop the trained model into the backend

```bash
# from download/nam_train/
cp nam_model.json ../mars3d/data/nam_model.json
```

Then restart the backend (`python3 server.py` in `mars3d/backend/`). Verify:

```bash
curl -s "http://localhost:8000/ai/ask?q=Tell%20me%20about%20Olympus%20Mons" | python3 -m json.tool
curl -s http://localhost:8000/metrics          # shows cv_accuracy, per-lang, counts
```

That is the whole retrain loop: **build_data → train_model → cp → restart**.

## 4. Enable smart switching to Gemini (optional)

The local model above is always the fallback. To add Gemini as the primary
phrasing engine, set one env var before starting the backend:

```bash
export NAM_GEMINI_API_KEY="your_gemini_key"          # Google AI Studio key
export NAM_GEMINI_MODEL="gemini-1.5-flash"           # optional; default
cd mars3d/backend && python3 server.py
```

Switching is automatic and per-call:
- `GET /ai/status` → `{"engine":"gemini", ...}` while the key is set,
  `{"engine":"local", ...}` when it is not.
- For each informational question, Gemini is tried **only if** the local
  classifier is confident (≥ 0.45) and the intent is informational
  (feature/mission/instrument/planet-fact/…). Functional commands
  (navigate / route / mission / landing) never call Gemini — they need tool
  calls, not prose.
- If Gemini errors (network / auth / quota / timeout), the response falls back
  to the local model automatically and the JSON carries
  `"fallback": true, "remote_error": "HTTP 400"` (or similar). The answer is
  still correct because it is grounded in the local catalog.

A secondary OpenAI-compatible endpoint is also supported (`NAM_LLM_API_URL`,
`NAM_LLM_API_KEY`, `NAM_LLM_MODEL`); Gemini takes priority if both are set.

```bash
# quick check of which engine is live
curl -s http://localhost:8000/ai/status
curl -s http://localhost:8000/healthz | python3 -m json.tool   # ai_engine field
```

## 5. Evaluate / inspect

```bash
python3 evaluate_model.py
```

Prints a full classification report, the top confused intent pairs, and a live
demo across all 9 languages.

## 6. Improve the model with your own corrections (the retrain loop)

The loop is safe to run in any order: `build_data.py` **preserves** examples
merged by `collect_feedback.py` across regenerations (tracked via the
`feedback_merged` count in `intents.json`), so corrections are never wiped.

**Easiest path — hand-written corrections** (recommended; the Cesium frontend has
no 👍/👎 export):

1. Note questions that `/ai/ask` gets wrong. Create `nam_feedback.json` next to
   the scripts with the correct intent:
   ```json
   [ {"text": "bring me to valles marineris", "intent": "navigate", "lang": "en"} ]
   ```
   (`corrected` is also accepted — that's the field name an exported feedback
   file would use.)
2. Merge + retrain + drop into the backend:
   ```bash
   python3 collect_feedback.py
   python3 train_model.py
   cp nam_model.json ../mars3d/data/nam_model.json
   ```
3. Restart `server.py` to load it. (Re-running `build_data.py` first is fine —
   your merged corrections survive.)

Repeated merges accumulate; duplicates (same text + lang) are skipped.

## 7. Push accuracy toward 97 %+ overall

Overall CV is 94.3 %; the drag is the long tail of similar *knowledge* intents
in the lower-resource languages (ar 0.89). To raise it:

- **Add examples** for the confused intent pairs reported by `evaluate_model.py`
  (20–40 per pair per language usually resolves it).
- **Tune C**: `python3 train_model.py --c 1.0` (more regularization) or `--c 4.0`
  (less). `--folds 10` for a tighter CV estimate.
- **Bigger lexicons** in `build_data.py` for ar/fr (the two lowest).
- The functional command intents the plan cares about most are already 98–100 %.

## 8. Add a new intent or language

Open `build_data.py`:

- **New language**: add a `LEX["xx"]` block and a `NATIVE["xx"]` block, then add
  `"xx"` to `LANGS` and `LANG_NAMES`. Add localized aliases for famous features
  in `ALIASES`. Re-run steps 2–3.
- **New intent**: add a tuple to `INTENT_META`, a `NATIVE[lang]["your_intent"]`
  list for each language, and a `responses[lang]["your_intent"]` template.

---

## File map

| file | purpose |
| --- | --- |
| `build_data.py` | generates `intents.json`, `responses.json`, `entities.json` from lexicons |
| `train_model.py` | trains TF-IDF + L1 LogReg, writes `nam_model.json`; `--c`/`--folds` flags |
| `evaluate_model.py` | CV report, confusion, live multilingual demo |
| `collect_feedback.py` | merges exported corrections into `intents.json` |
| `intents.json` | labeled utterances `{text, intent, lang}` + intent schema |
| `responses.json` | localized response templates per intent (slot-filled at runtime) |
| `entities.json` | layer/type/criterion/format/unit keywords + multilingual feature aliases |
| `nam_model.json` | the trained model — **copy to `../mars3d/data/nam_model.json`** |
| `requirements.txt` | scikit-learn, numpy |

## Architecture (one paragraph)

`build_data.py` expands per-language lexicons + native templates into labeled
utterances. `train_model.py` fits a `TfidfVectorizer` (custom multilingual
tokenizer: word unigrams for latin/cyrillic/arabic/devanagari, per-char
unigrams **and** char-bigrams for CJK) + an L1-regularized one-vs-rest
`LogisticRegression` (sparse, ~1.4k nonzero weights). It serializes the
vocabulary, idf, class weights and intercepts, the localized response templates
and the entity gazetteer into one JSON. The backend `hybrid_ai.py` mirrors the
exact tokenizer and inference in pure Python (no sklearn at runtime), classifies
the query, retrieves grounding docs from the embedded Mars catalog, and either
returns a grounded local answer or hands the grounding to Gemini for phrasing.
Every answer traces to the embedded, attributed NASA data; unknowns are answered
honestly instead of invented.
