#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NAM model trainer.

Pipeline:
  1. Load intents.json / responses.json / entities.json (from build_data.py)
  2. TF-IDF with a custom multilingual tokenizer
        - latin/cyrillic/arabic/devanagari: word unigrams (lowercased)
        - CJK (han/kana): per-char unigrams + char bigrams (no spaces in CJK)
  3. LogisticRegression (L1, liblinear, class-balanced) — sparse, interpretable
  4. Stratified 5-fold CV -> accuracy + macro-F1
  5. Refit on all data, export a single self-contained JSON model:
        window.NAM_MODEL = { meta, intents, classifier{vocab,idf,classes,
        intercept, weights_by_token, norm}, responses, entities }

Usage:
  python train_model.py                 # writes nam_model.json, prints metrics
  python train_model.py --embed HTML    # also injects the model into the HTML
  python train_model.py --c CVAL        # override logistic-regression C
  python train_model.py --folds N       # override CV folds
"""
import json, os, re, sys, time, math, warnings
import numpy as np
from collections import Counter
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.metrics import classification_report, accuracy_score, f1_score

HERE = os.path.dirname(os.path.abspath(__file__))

# ---- multilingual tokenizer (mirrored exactly in the JS runtime) ----------
CJK = re.compile(r"[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]")
WORD = re.compile(
    r"[A-Za-z0-9_"
    r"\u00c0-\u00ff"   # latin supplement
    r"\u0100-\u024f"   # latin extended
    r"\u0400-\u04ff"   # cyrillic
    r"\u0600-\u06ff"   # arabic
    r"\u0900-\u097f"   # devanagari
    r"]+")

def tokenize(s):
    s=(s or "").lower()
    toks=[]
    for m in WORD.finditer(s):
        toks.append(m.group())
    cjk=[c for c in s if CJK.match(c)]
    for c in cjk: toks.append(c)
    for i in range(len(cjk)-1): toks.append(cjk[i]+cjk[i+1])
    return toks

def main():
    warnings.filterwarnings("ignore")

    cval=2.0; folds=5; embed_path=None
    args=sys.argv[1:]
    i=0
    while i<len(args):
        a=args[i]
        if a=="--embed" and i+1<len(args): embed_path=args[i+1]; i+=2; continue
        if a=="--c" and i+1<len(args): cval=float(args[i+1]); i+=2; continue
        if a=="--folds" and i+1<len(args): folds=int(args[i+1]); i+=2; continue
        print("unknown arg",a); sys.exit(2); 
    intents=json.load(open(os.path.join(HERE,"intents.json"),encoding="utf-8"))
    responses=json.load(open(os.path.join(HERE,"responses.json"),encoding="utf-8"))
    entities=json.load(open(os.path.join(HERE,"entities.json"),encoding="utf-8"))
    exs=[e for e in intents["examples"] if e["intent"]!="fallback"]
    X_text=[e["text"] for e in exs]
    y=[e["intent"] for e in exs]
    langs=[e["lang"] for e in exs]
    intent_meta=intents["intents"]   # [(intent,tool,needs),...]

    vec=TfidfVectorizer(analyzer=tokenize, token_pattern=None,
                        ngram_range=(1,1), sublinear_tf=True,
                        min_df=2, norm="l2")
    X=vec.fit_transform(X_text)
    classes=sorted(set(y))
    clf=LogisticRegression(penalty="l1", solver="liblinear", C=cval,
                           class_weight="balanced", max_iter=1500)

    print(f"examples={len(exs)}  classes={len(classes)}  vocab={len(vec.vocabulary_)}")
    # ---- cross-validated metrics ----
    skf=StratifiedKFold(n_splits=folds, shuffle=True, random_state=13)
    accs=[]; f1s=[]
    for tr,va in skf.split(X,y):
        c=LogisticRegression(penalty="l1",solver="liblinear",C=cval,
                             class_weight="balanced",max_iter=1500)
        c.fit(X[tr],[y[i] for i in tr])
        pred=c.predict(X[va])
        accs.append(accuracy_score([y[i] for i in va],pred))
        f1s.append(f1_score([y[i] for i in va],pred,average="macro",labels=classes,zero_division=0))
    print(f"CV acc = {np.mean(accs):.3f} ± {np.std(accs):.3f}")
    print(f"CV F1  = {np.mean(f1s):.3f} ± {np.std(f1s):.3f}")

    # ---- per-language accuracy (leave-one-out style: predict on whole set, slice by lang) ----
    clf.fit(X,y)
    pred=clf.predict(X)
    by_lang={}
    for t,py_,lg in zip(X_text,pred,langs):
        by_lang.setdefault(lg,[0,0])
        # train-acc per lang (optimistic) — for a true OOD estimate see evaluate_model.py
    # instead compute a quick held-out per-lang using a 20% stratified split
    from sklearn.model_selection import train_test_split
    Xtr,Xva,ytr,yva,lt,lv=train_test_split(X,y,langs,test_size=0.2,
        random_state=21,stratify=[(y[i],langs[i]) for i in range(len(y))])
    c2=LogisticRegression(penalty="l1",solver="liblinear",C=cval,
                          class_weight="balanced",max_iter=1500)
    c2.fit(Xtr,ytr)
    pred2=c2.predict(Xva)
    lang_acc={}
    for py_,true,lg in zip(pred2,yva,lv):
        lang_acc.setdefault(lg,[0,0]); lang_acc[lg][1]+=1
        if py_==true: lang_acc[lg][0]+=1
    print("held-out accuracy by language:")
    for lg in intents["languages"]:
        c_,t_=lang_acc.get(lg,[0,0]); print(f"  {lg}: {c_}/{t_} = {c_/max(t_,1):.3f}")

    # ---- export sparse model ----
    vocab=vec.vocabulary_               # token -> idx
    idf=vec.idf_                        # len = vocab size
    coefs=clf.coef_                     # (n_classes, n_features) aligned to classes_ order
    order=list(clf.classes_)            # sklearn's class order
    intercepts=clf.intercept_           # (n_classes,)
    # build weights_by_token: { idx: [[class_pos, weight], ...] } for |w|>0.004
    wbt={}
    nz=0
    for tok,idx in vocab.items():
        col=[]
        for ci in range(len(order)):
            w=float(coefs[ci][idx])
            if abs(w)>0.004: col.append([ci,round(w,5)]); nz+=1
        if col: wbt[str(idx)]=col
    # classes mapped to intent names in sklearn order
    classes_out=order
    intents_out=[{"intent":it,"tool":tool,"needs":needs}
                 for (it,tool,needs) in intent_meta if it!="fallback"]
    model={
      "meta":{
        "version":"nam-nlp-1.0",
        "trained_at":time.strftime("%Y-%m-%d %H:%M:%S"),
        "engine":"tfidf-l1-logreg",
        "languages":intents["languages"],
        "language_names":intents["language_names"],
        "n_examples":len(exs),
        "n_intents":len(intents_out),
        "vocab_size":len(vocab),
        "nonzero_weights":nz,
        "cv_accuracy":round(float(np.mean(accs)),4),
        "cv_f1_macro":round(float(np.mean(f1s)),4),
        "cv_folds":folds,
        "C":cval,
        "heldout_acc_by_lang":{lg:round(lang_acc.get(lg,[0,1])[0]/max(lang_acc.get(lg,[0,1])[1],1),4)
                               for lg in intents["languages"]},
        "tokenization":"lowercased word unigrams (latin/cyrillic/arabic/devanagari) + CJK char unigrams & bigrams; sublinear tf; l2 norm",
      },
      "intents":intents_out,
      "classifier":{
        "vocab":vocab,            # token -> idx
        "idf":[round(float(v),5) for v in idf],
        "classes":classes_out,    # intent names in weight order
        "intercept":[round(float(v),5) for v in intercepts],
        "weights_by_token":wbt,   # idx(str) -> [[class_pos, weight], ...]
        "norm":"l2",
        "sublinear_tf":True,
      },
      "responses":responses,
      "entities":entities,
      "suggestions":[
        "Take me to Jezero Crater","Show Olympus Mons","What is the elevation here?",
        "Find interesting targets within 800 km","Identify hazards",
        "Create a rover mission from Gale to Hellas","Generate route",
        "Optimize route for science","Explain route","Export mission as JSON",
        "Compare elevation and geological layers","What datasets cover this region?",
      ],
    }
    out_path=os.path.join(HERE,"nam_model.json")
    json.dump(model,open(out_path,"w",encoding="utf-8"),ensure_ascii=False,separators=(",",":"))
    size=os.path.getsize(out_path)
    print(f"wrote {out_path}  ({size/1024:.0f} KB, {nz} nonzero weights)")
    # show top features for a few intents (interpretability check)
    inv={v:k for k,v in vocab.items()}
    print("top features per intent (sanity):")
    for ci,cn in enumerate(order):
        if cn not in ("navigate","activate_layer","create_mission","feature_info","planet_fact"): continue
        feats=sorted(((coefs[ci][j],inv[j]) for j in range(coefs.shape[1])),reverse=True)[:6]
        print(f"  {cn:18s} "+", ".join(f"{t}({w:.2f})" for w,t in feats if w>0))

    # ---- optional embed ----
    if embed_path:
        embed_into_html(embed_path, model)
    return model

def embed_into_html(html_path, model):
    js=json.dumps(model,ensure_ascii=False,separators=(",",":"))
    src=open(html_path,encoding="utf-8").read()
    marker_start="/*NAM_MODEL_EMBED_START*/"
    marker_end="/*NAM_MODEL_EMBED_END*/"
    if marker_start in src and marker_end in src:
        i=src.index(marker_start)+len(marker_start)
        j=src.index(marker_end)
        src=src[:i]+js+src[j:]
        msg="updated embedded model"
    else:
        anchor="<script>window.CESIUM_BASE_URL="
        if anchor not in src:
            print("ERROR: could not find injection anchor in HTML"); return
        idx=src.index(anchor)
        end=src.index("</script>",idx)+len("</script>")
        placeholder=("\n<script>window.NAM_MODEL = "+marker_start+js+marker_end+
                     ";</script>")
        src=src[:end]+placeholder+src[end:]
        msg="inserted embedded model (first run)"
    open(html_path,"w",encoding="utf-8").write(src)
    print(f"embed: {msg} -> {html_path} (+{len(js)/1024:.0f} KB)")

if __name__=="__main__":
    main()
