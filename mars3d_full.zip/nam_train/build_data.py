#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NAM multilingual training-data generator.

Produces three JSON files used by nam_train.py:
  - intents.json    : labeled utterances  [{text, intent, lang}, ...]
  - responses.json  : localized response templates per intent  {lang:{intent:{text,html}}}
  - entities.json   : entity keywords (layer names, mission types, units, criteria,
                      export formats) + multilingual aliases for famous features.

The data is generated from compact per-language lexicons + per-intent templates
(template expansion is a standard, transparent data-augmentation technique; we
control every string, so no facts are invented).

Languages: en, zh, es, fr, de, ru, ar, hi, ja
"""
import json, os, itertools, random

HERE = os.path.dirname(os.path.abspath(__file__))
random.seed(7)

LANGS = ["en","zh","es","fr","de","ru","ar","hi","ja"]
LANG_NAMES = {"en":"English","zh":"中文","es":"Español","fr":"Français",
              "de":"Deutsch","ru":"Русский","ar":"العربية","hi":"हिन्दी","ja":"日本語"}

# ---------------------------------------------------------------------------
# Per-language lexicons
# ---------------------------------------------------------------------------
LEX = {
# ---- English -------------------------------------------------------------
"en": {
  "nav_verbs": ["take me to","go to","fly to","navigate to","show me","zoom to","jump to","center on","bring me to","focus on"],
  "here": ["here","this spot","current location","where i am","this point","right here"],
  "layer_verbs": ["show","display","activate","turn on","add","enable","overlay","switch on"],
  "layers": {"hillshade":"hillshade","roughness":"roughness","basemap":"basemap","mola":"mola","elevation":"elevation",
             "viking":"viking","mdim":"mdim","opm":"opm","topography":"topography","relief":"relief"},
  "mission_types": {"rover":"rover","human":"human","crew":"crewed","geology":"geology","mineral":"mineral","sample":"sample","recon":"reconnaissance"},
  "criteria": {"length":"shortest","risk":"safest","science":"science","balanced":"balanced"},
  "formats": {"json":"json","csv":"csv","txt":"txt"},
  "units": ["km","kilometers","kilometres"],
  "greet": ["hello","hi","hey","greetings","good morning","good evening"],
  "help": ["help","what can you do","how does this work","what are you","commands","guide me"],
  "thanks": ["thanks","thank you","cheers","appreciate it"],
  "and": ["and","to","vs","versus","with"],
  "from": ["from","starting at","starting from","begin at"],
  "to": ["to","toward","heading to","up to"],
  "near": ["within","around","near","within a radius of","in"],
  "profile_from": ["profile from","elevation profile from","cross-section from","section from"],
  "what": ["what is","what's","tell me about","describe","explain","give me info on"],
  "why": ["why is it interesting","why is it important","what's special about","what makes it notable"],
},
# ---- Chinese -------------------------------------------------------------
"zh": {
  "nav_verbs": ["带我去","前往","飞到","导航到","显示","放大到","跳转到","定位到","去看看","聚焦"],
  "here": ["这里","这个位置","当前位置","我在哪","这一点","此地"],
  "layer_verbs": ["显示","打开","启用","添加","叠加","开启","切换到"],
  "layers": {"hillshade":"晕渲","roughness":"粗糙度","basemap":"底图","mola":"MOLA","elevation":"高程",
             "viking":"海盗号","mdim":"MDIM","opm":"OPM","topography":"地形","relief":"地势"},
  "mission_types": {"rover":"火星车","human":"载人","crew":"载人","geology":"地质","mineral":"矿物","sample":"采样","recon":"侦察"},
  "criteria": {"length":"最短","risk":"最安全","science":"科研","balanced":"均衡"},
  "formats": {"json":"json","csv":"csv","txt":"txt"},
  "units": ["公里","千米","km"],
  "greet": ["你好","嗨","您好","哈喽","早上好","晚上好"],
  "help": ["帮助","你能做什么","怎么用","你是谁","指令","使用指南"],
  "thanks": ["谢谢","感谢","多谢"],
  "and": ["到","和","与","对比"],
  "from": ["从","起点","出发"],
  "to": ["到","前往","驶向"],
  "near": ["以内","附近","周围","半径","方圆"],
  "profile_from": ["剖面从","高程剖面从","断面从"],
  "what": ["介绍一下","告诉我","什么是","描述一下","说明一下"],
  "why": ["为什么重要","有什么特别","为什么有意思"],
},
# ---- Spanish -------------------------------------------------------------
"es": {
  "nav_verbs": ["llévame a","ve a","vuela a","navega a","muéstrame","acércate a","salta a","centra en","llévame","enfoca"],
  "here": ["aquí","este sitio","ubicación actual","dónde estoy","este punto","justo aquí"],
  "layer_verbs": ["muestra","activa","enciende","añade","superpone","activa","muestra"],
  "layers": {"hillshade":"sombreado","roughness":"rugosidad","basemap":"mapa base","mola":"mola","elevation":"elevación",
             "viking":"viking","mdim":"mdim","opm":"opm","topography":"topografía","relief":"relieve"},
  "mission_types": {"rover":"rover","human":"humano","crew":"tripulado","geology":"geología","mineral":"mineral","sample":"muestras","recon":"reconocimiento"},
  "criteria": {"length":"más corto","risk":"más seguro","science":"ciencia","balanced":"equilibrado"},
  "formats": {"json":"json","csv":"csv","txt":"txt"},
  "units": ["km","kilómetros","kilometros"],
  "greet": ["hola","buenas","oye","saludos","buenos días","buenas tardes"],
  "help": ["ayuda","qué puedes hacer","cómo funciona","quién eres","comandos","guía"],
  "thanks": ["gracias","muchas gracias","genial"],
  "and": ["y","a","vs","contra","con"],
  "from": ["desde","saliendo de","partiendo de"],
  "to": ["hasta","a","hacia"],
  "near": ["dentro de","alrededor de","cerca de","a un radio de","en"],
  "profile_from": ["perfil desde","perfil de elevación desde","sección desde"],
  "what": ["qué es","dime sobre","describe","explica","información sobre"],
  "why": ["por qué es interesante","por qué importa","qué tiene de especial"],
},
# ---- French --------------------------------------------------------------
"fr": {
  "nav_verbs": ["emmène-moi à","va à","vole vers","navigue vers","montre-moi","zoome sur","saute à","centre sur","amène-moi à","focalise sur"],
  "here": ["ici","cet endroit","position actuelle","où suis-je","ce point","juste ici"],
  "layer_verbs": ["affiche","active","allume","ajoute","superpose","montre"],
  "layers": {"hillshade":"ombrage","roughness":"rugosité","basemap":"fond de carte","mola":"mola","elevation":"élévation",
             "viking":"viking","mdim":"mdim","opm":"opm","topography":"topographie","relief":"relief"},
  "mission_types": {"rover":"rover","human":"humain","crew":"habité","geology":"géologie","mineral":"minéral","sample":"échantillons","recon":"reconnaissance"},
  "criteria": {"length":"le plus court","risk":"le plus sûr","science":"science","balanced":"équilibré"},
  "formats": {"json":"json","csv":"csv","txt":"txt"},
  "units": ["km","kilomètres","kilometres"],
  "greet": ["bonjour","salut","coucou","bonsoir","enchanté"],
  "help": ["aide","que peux-tu faire","comment ça marche","qui es-tu","commandes","guide"],
  "thanks": ["merci","merci beaucoup","super"],
  "and": ["et","à","vs","versus","avec"],
  "from": ["depuis","en partant de","au départ de"],
  "to": ["vers","jusqu'à","à"],
  "near": ["dans un rayon de","autour de","près de","rayon de","dans"],
  "profile_from": ["profil depuis","profil d'élévation depuis","coupe depuis"],
  "what": ["qu'est-ce que","dis-moi en plus sur","décris","explique","parle-moi de"],
  "why": ["pourquoi c'est intéressant","pourquoi c'est important","qu'y a-t-il de spécial"],
},
# ---- German --------------------------------------------------------------
"de": {
  "nav_verbs": ["bring mich zu","gehe zu","fliege zu","navigiere zu","zeig mir","zoome auf","springe zu","zentriere auf","fokussiere auf"],
  "here": ["hier","diese stelle","aktuelle position","wo bin ich","dieser punkt","genau hier"],
  "layer_verbs": ["zeige","aktiviere","schalte ein","füge hinzu","lege darüber","blende ein"],
  "layers": {"hillshade":"schummerung","roughness":"rauigkeit","basemap":"grundkarte","mola":"mola","elevation":"höhe",
             "viking":"viking","mdim":"mdim","opm":"opm","topography":"topographie","relief":"relief"},
  "mission_types": {"rover":"rover","human":"bemannt","crew":"bemannt","geology":"geologie","mineral":"mineral","sample":"proben","recon":"aufklärung"},
  "criteria": {"length":"kürzeste","risk":"sicherste","science":"wissenschaft","balanced":"ausgewogen"},
  "formats": {"json":"json","csv":"csv","txt":"txt"},
  "units": ["km","kilometer"],
  "greet": ["hallo","hi","hey","guten tag","guten morgen","servus"],
  "help": ["hilfe","was kannst du","wie funktioniert das","wer bist du","befehle","anleitung"],
  "thanks": ["danke","vielen dank","super"],
  "and": ["und","nach","vs","gegen","mit"],
  "from": ["von","ab","startend von"],
  "to": ["nach","bis","zu"],
  "near": ["innerhalb von","um","in der nähe von","im radius von","in"],
  "profile_from": ["profil von","höhenprofil von","schnitt von"],
  "what": ["was ist","erzähl mir über","beschreibe","erkläre","info über"],
  "why": ["warum interessant","warum wichtig","was ist besonders"],
},
# ---- Russian -------------------------------------------------------------
"ru": {
  "nav_verbs": ["отправься к","перейди к","лети к","навигай к","покажи","приблизь к","прыгни к","центрируй на","покажи мне"],
  "here": ["здесь","эта точка","текущее положение","где я","эта позиция","прямо здесь"],
  "layer_verbs": ["покажи","включи","активируй","добавь","наложи","включи"],
  "layers": {"hillshade":"отмывка","roughness":"шероховатость","basemap":"подложка","mola":"mola","elevation":"высота",
             "viking":"viking","mdim":"mdim","opm":"opm","topography":"топография","relief":"рельеф"},
  "mission_types": {"rover":"ровер","human":"пилотируемый","crew":"экипаж","geology":"геология","mineral":"минералы","sample":"образцы","recon":"разведка"},
  "criteria": {"length":"кратчайший","risk":"безопасный","science":"наука","balanced":"сбалансированный"},
  "formats": {"json":"json","csv":"csv","txt":"txt"},
  "units": ["км","километров","km"],
  "greet": ["привет","здравствуй","здравствуйте","доброе утро","добрый вечер"],
  "help": ["помощь","что умеешь","как пользоваться","кто ты","команды","инструкция"],
  "thanks": ["спасибо","благодарю","спасибо большое"],
  "and": ["и","до","vs","против","с"],
  "from": ["из","от","начиная от"],
  "to": ["до","к","в"],
  "near": ["в радиусе","вокруг","рядом с","в пределах","около"],
  "profile_from": ["профиль от","профиль высот от","разрез от"],
  "what": ["что такое","расскажи про","опиши","объясни","информация о"],
  "why": ["почему интересно","почему важно","что особенного"],
},
# ---- Arabic --------------------------------------------------------------
"ar": {
  "nav_verbs": ["خذني إلى","اذهب إلى","طر إلى","تنقل إلى","أرني","كبّر على","انتقل إلى","ركّز على","اعرض"],
  "here": ["هنا","هذه النقطة","الموقع الحالي","أين أنا","هذا الموضع"],
  "layer_verbs": ["اعرض","فعّل","شغّل","أضف","طبّق","أبرز"],
  "layers": {"hillshade":"تظليل","roughness":"خشونة","basemap":"الخريطة الأساسية","mola":"mola","elevation":"ارتفاع",
             "viking":"viking","mdim":"mdim","opm":"opm","topography":"تضاريس","relief":"تضاريس"},
  "mission_types": {"rover":"مركبة","human":"مأهول","crew":"طاقم","geology":"جيولوجيا","mineral":"معادن","sample":"عينات","recon":"استطلاع"},
  "criteria": {"length":"الأقصر","risk":"الأكثر أماناً","science":"علم","balanced":"متوازن"},
  "formats": {"json":"json","csv":"csv","txt":"txt"},
  "units": ["كم","كيلومتر","km"],
  "greet": ["مرحبا","أهلا","السلام عليكم","صباح الخير","مساء الخير"],
  "help": ["مساعدة","ماذا تستطيع","كيف يعمل","من أنت","أوامر","دليل"],
  "thanks": ["شكرا","شكراً جزيلا","ممتاز"],
  "and": ["و","إلى","مقابل","مع"],
  "from": ["من","انطلاقاً من"],
  "to": ["إلى","نحو","حتى"],
  "near": ["ضمن","حول","بالقرب من","في نطاق","بنطاق"],
  "profile_from": ["مقطع من","مقطع ارتفاع من","قطاع من"],
  "what": ["ما هو","أخبرني عن","صف","اشرح","معلومات عن"],
  "why": ["لماذا مثير","لماذا مهم","ما المميز فيه"],
},
# ---- Hindi ---------------------------------------------------------------
"hi": {
  "nav_verbs": ["मुझे ले जाओ","जाओ","उड़ो","नेविगेट करो","दिखाओ","ज़ूम करो","कूदो","केंद्रित करो","दिखाओ"],
  "here": ["यहाँ","इस जगह","वर्तमान स्थान","मैं कहाँ हूँ","यह बिंदु"],
  "layer_verbs": ["दिखाओ","चालू करो","सक्रिय करो","जोड़ो","ओवरले करो","बदलो"],
  "layers": {"hillshade":"हिलशेड","roughness":"खुरदरापन","basemap":"बेस मैप","mola":"mola","elevation":"ऊँचाई",
             "viking":"वाइकिंग","mdim":"mdim","opm":"opm","topography":"स्थलाकृति","relief":"राहत"},
  "mission_types": {"rover":"रोवर","human":"मानव","crew":"चालक दल","geology":"भूविज्ञान","mineral":"खनिज","sample":"नमूने","recon":"अन्वेषण"},
  "criteria": {"length":"सबसे छोटा","risk":"सबसे सुरक्षित","science":"विज्ञान","balanced":"संतुलित"},
  "formats": {"json":"json","csv":"csv","txt":"txt"},
  "units": ["किमी","किलोमीटर","km"],
  "greet": ["नमस्ते","हैलो","सुप्रभात","शुभ संध्या"],
  "help": ["मदद","आप क्या कर सकते हैं","यह कैसे काम करता है","आप कौन हैं","आदेश","मार्गदर्शक"],
  "thanks": ["धन्यवाद","बहुत धन्यवाद","शानदार"],
  "and": ["और","से","बनाम","के साथ"],
  "from": ["से","प्रारंभ करते हुए","शुरुआत"],
  "to": ["तक","की ओर","प्रति"],
  "near": ["के भीतर","आसपास","के पास","त्रिज्या","में"],
  "profile_from": ["प्रोफ़ाइल से","ऊँचाई प्रोफ़ाइल से","अनुप्रस्थ काट से"],
  "what": ["क्या है","बताओ","वर्णन करो","समझाओ","जानकारी"],
  "why": ["क्यों दिलचस्प","क्यों महत्वपूर्ण","क्या खास है"],
},
# ---- Japanese ------------------------------------------------------------
"ja": {
  "nav_verbs": ["連れて行って","行って","飛んで","ナビゲートして","見せて","ズームして","ジャンプして","中心を合わせて","表示して"],
  "here": ["ここ","この場所","現在地","どこにいるの","この地点"],
  "layer_verbs": ["表示して","オンにして","有効にして","追加して","重ねて","切り替えて"],
  "layers": {"hillshade":"陰影","roughness":"粗さ","basemap":"背景地図","mola":"mola","elevation":"標高",
             "viking":"バイキング","mdim":"mdim","opm":"opm","topography":"地形","relief":"起伏"},
  "mission_types": {"rover":"ローバー","human":"有人","crew":"有人","geology":"地質","mineral":"鉱物","sample":"サンプル","recon":"偵察"},
  "criteria": {"length":"最短","risk":"最も安全","science":"科学","balanced":"バランス"},
  "formats": {"json":"json","csv":"csv","txt":"txt"},
  "units": ["km","キロ","キロメートル"],
  "greet": ["こんにちは","やあ","こんばんは","おはよう"],
  "help": ["ヘルプ","何ができる","使い方","あなたは誰","コマンド","ガイド"],
  "thanks": ["ありがとう","ありがとうございます","ありがとう"],
  "and": ["と","から","対","vs"],
  "from": ["から","出発","始点"],
  "to": ["へ","まで","に向かって"],
  "near": ["以内","周辺","の近く","半径","の中の"],
  "profile_from": ["断面図","標高断面","プロファイル"],
  "what": ["とは","教えて","説明して","について","詳しく"],
  "why": ["なぜ面白い","なぜ重要","何が特別"],
},
}

# ---------------------------------------------------------------------------
# Famous features — multilingual aliases (alias -> feature id in NAM.DATA.FEATURES)
# Proper nouns are mostly shared; we add localized aliases for the best-known ones.
# ---------------------------------------------------------------------------
ALIASES = {
  "olympus-mons": {
    "en":["Olympus Mons","Olympus"],
    "zh":["奥林帕斯山","奥林波斯山","奥林匹斯山","奥林匹斯","奥林帕斯"],
    "es":["Monte Olimpo","Olympus Mons"],
    "fr":["Mont Olympe","Olympus Mons"],
    "de":["Olympus Mons","Olymp"],
    "ru":["Олимп","гора Олимп","Olympus Mons"],
    "ar":["أوليمبوس","أوليمبوس مونس"],
    "hi":["ओलिंपस","ओलिंपस मॉन्स"],
    "ja":["オリンポス山","オリンパス山"],
  },
  "hellas": {
    "en":["Hellas Planitia","Hellas basin","Hellas"],
    "zh":["海拉斯平原","海拉斯盆地","海拉斯"],
    "es":["Llanura de Hellas","Hellas"],
    "fr":["Plaine d'Hellas","Hellas"],
    "de":["Hellas-Senke","Hellas-Becken","Hellas"],
    "ru":["Эллада","равнина Эллада","Hellas"],
    "ar":["هيلاس","سهل هيلاس"],
    "hi":["हेलस","हेलस मैदान"],
    "ja":["ヘラス平原","ヘラス"],
  },
  "valles-marineris": {
    "en":["Valles Marineris","Mariner Valley"],
    "zh":["水手谷","水手号峡谷"],
    "es":["Valles Marineris"],
    "fr":["Valles Marineris"],
    "de":["Valles Marineris","Mariner-Täler"],
    "ru":["Валлы Маринера","долина Маринера"],
    "ar":["وادي مارينر","فاليس مارينيريس"],
    "hi":["मैरिनर घाटी","वैलेस मैरिनेरिस"],
    "ja":["マリネリス峡谷","ヴァレス・マリネリス"],
  },
  "gale": {
    "en":["Gale crater","Gale Crater","Gale"],
    "zh":["盖尔陨石坑","盖尔坑","盖尔"],
    "es":["Cráter Gale","Gale"],
    "fr":["Cratère Gale","Gale"],
    "de":["Gale-Krater","Gale"],
    "ru":["Кратер Гейл","Гейл"],
    "ar":["غيل","فوهة غيل"],
    "hi":["गेल","गेल क्रेटर"],
    "ja":["ゲール","ゲールクレーター"],
  },
  "jezero": {
    "en":["Jezero crater","Jezero Crater","Jezero"],
    "zh":["耶泽罗陨石坑","杰泽罗坑","耶泽罗","杰泽罗"],
    "es":["Cráter Jezero","Jezero"],
    "fr":["Cratère Jezero","Jezero"],
    "de":["Jezero-Krater","Jezero"],
    "ru":["Кратер Езеро","Езеро"],
    "ar":["جيزيرو","فوهة جيزيرو"],
    "hi":["जेज़ेरो","जेज़ेरो क्रेटर"],
    "ja":["イェゼロ","イェゼロクレーター"],
  },
  "tharsis-montes": {
    "en":["Tharsis Montes","Tharsis"],
    "zh":["塔尔西斯山群","塔尔西斯"],
    "es":["Tharsis Montes","Tharsis"],
    "fr":["Tharsis Montes","Tharsis"],
    "de":["Tharsis Montes","Tharsis"],
    "ru":["Тарсис","горы Тарсис"],
    "ar":["ثارسيس"],
    "hi":["थारसिस"],
    "ja":["タルシス","タルシス・モンテス"],
  },
  "arsia-mons": {
    "en":["Arsia Mons","Arsia"],
    "zh":["阿尔西亚山","阿尔西亚"],
    "es":["Arsia Mons"],
    "fr":["Arsia Mons"],
    "de":["Arsia Mons"],
    "ru":["Арсия"],
    "ar":["أرسيا"],
    "hi":["आर्सिया"],
    "ja":["アルシア・モンス","アルシア山"],
  },
  "ascraeus-mons": {
    "en":["Ascraeus Mons","Ascraeus"],
    "zh":["阿斯克赖俄斯山","阿斯克赖俄斯"],
    "es":["Ascraeus Mons"],
    "fr":["Ascraeus Mons"],
    "de":["Ascraeus Mons"],
    "ru":["Аскрей"],
    "ar":["أسكريوس"],
    "hi":["अस्क्रेयस"],
    "ja":["アスクラエウス・モンス"],
  },
  "pavonis-mons": {
    "en":["Pavonis Mons","Pavonis"],
    "zh":["帕沃尼斯山","帕沃尼斯"],
    "es":["Pavonis Mons"],
    "fr":["Pavonis Mons"],
    "de":["Pavonis Mons"],
    "ru":["Павонис"],
    "ar":["بافونيس"],
    "hi":["पावोनिस"],
    "ja":["パボニス・モンス"],
  },
  "elysium-mons": {
    "en":["Elysium Mons","Elysium"],
    "zh":["厄律西昂山","厄律西昂"],
    "es":["Elysium Mons"],
    "fr":["Elysium Mons"],
    "de":["Elysium Mons"],
    "ru":["Элизиум"],
    "ar":["إليزيوم"],
    "hi":["एलिसियम"],
    "ja":["エリュシウム・モンス"],
  },
  "argyre": {
    "en":["Argyre Planitia","Argyre","Argyre basin"],
    "zh":["阿尔及尔平原","阿尔及尔"],
    "es":["Argyre Planitia","Argyre"],
    "fr":["Argyre Planitia"],
    "de":["Argyre-Senke"],
    "ru":["Аргир","равнина Аргир"],
    "ar":["أرجير"],
    "hi":["आर्गायर"],
    "ja":["アルギレ平原","アルギレ"],
  },
  "isidis": {
    "en":["Isidis Planitia","Isidis","Isidis basin"],
    "zh":["伊希地平原","伊希地"],
    "es":["Isidis Planitia"],
    "fr":["Isidis Planitia"],
    "de":["Isidis Planitia"],
    "ru":["Исидис"],
    "ar":["إيسيديس"],
    "hi":["इसिडिस"],
    "ja":["イシディス平原"],
  },
}

# A handful of famous features used as slot fillers in templates (English id used
# by the entity matcher; the alias map above provides cross-language matching).
FEATURES_EN = ["Olympus Mons","Hellas Planitia","Valles Marineris","Jezero crater","Gale crater",
               "Arsia Mons","Ascraeus Mons","Pavonis Mons","Elysium Mons","Argyre Planitia",
               "Isidis Planitia","Tharsis Montes","Noctis Labyrinthus","Coprates Chasma",
               "Kasei Valles","Mawrth Vallis","Syrtis Major Planum","Utopia Planitia"]

# ---------------------------------------------------------------------------
# Intent templates. Each intent: list of (template, slot-fillers-fn) per concept.
# We expand per language. Slots: {PLACE}, {PLACE2}, {LAYER}, {TYPE}, {CRIT},
# {FMT}, {RAD}, {FEAT}, {FEAT2}.
# ---------------------------------------------------------------------------
def _expand(lang, templates, fillers):
    """fillers: dict slot->list. Produce cartesian product."""
    out=[]
    for tpl in templates:
        slots=[s for s in fillers if ("{"+s+"}") in tpl]
        if not slots:
            out.append(tpl); continue
        for combo in itertools.product(*[fillers[s] for s in slots]):
            t=tpl
            for s,v in zip(slots,combo):
                t=t.replace("{"+s+"}",v)
            out.append(t.strip())
    return out

# ---------------------------------------------------------------------------
# Native (fully localized) templates per intent per language.
# Slots: {PLACE}{FEAT}{FEAT2}{LAYER}{TYPE}{CRIT}{FMT}{RAD}{UNIT}{FROM}{TO}{HERE}{NEAR}
# Filled from the localized LEX above. These teach native command structure,
# not just slot words — essential for CJK/Arabic/Hindi/Russian users.
# ---------------------------------------------------------------------------
NATIVE = {
"en": {
  "navigate":["take me to {FEAT}","go to {FEAT}","fly to {FEAT}","show me {FEAT}"],
  "activate_layer":["show the {LAYER} layer","activate {LAYER}","turn on {LAYER}","display {LAYER}"],
  "find_targets":["find interesting targets within {RAD} {UNIT}","find science targets","find hydrated minerals"],
  "observations_nearby":["what observations are within {RAD} {UNIT}","what data covers this area","datasets near here"],
  "elevation_here":["what is the elevation here","how high am i","elevation at this point"],
  "analyze_terrain":["analyze the terrain","terrain analysis","slope map of this view"],
  "identify_hazards":["identify hazards","are there dangers here","show the risk map"],
  "generate_route":["generate a route","compute the route","plan a route"],
  "optimize_route":["optimize the route for {CRIT}","make the route {CRIT}","prefer a {CRIT} route"],
  "explain_route":["explain the route","why this route","explain why this path"],
  "current_context":["where am i","what is my current view","current map context"],
  "search_datasets":["what datasets cover this region","which nasa data is here","data sources"],
  "planet_fact":["what is the gravity","how long is a day","what is the atmospheric pressure","radiation level","how far is mars from the sun"],
  "tallest_deepest":["what is the tallest mountain","highest volcano","deepest point on mars"],
  "model_info":["what languages do you speak","how does the ai work","model info"],
  "create_mission":["create a {TYPE} mission from {FEAT} to {FEAT2}","plan a {TYPE} mission from {FEAT} to {FEAT2}"],
  "add_waypoint":["add a waypoint at {FEAT}","add a stop at {FEAT}"],
  "elevation_profile":["elevation profile from {FEAT} to {FEAT2}","profile from {FEAT} to {FEAT2}"],
},
"zh": {
  "navigate":["带我去{FEAT}","前往{FEAT}","飞到{FEAT}","显示{FEAT}"],
  "activate_layer":["显示{LAYER}图层","打开{LAYER}","启用{LAYER}"],
  "find_targets":["在{RAD}{UNIT}内寻找有趣目标","寻找科学目标","查找含水矿物"],
  "observations_nearby":["{RAD}{UNIT}内有哪些观测","这里有什么数据","附近的数据集"],
  "elevation_here":["这里有多高","当前位置的高程","这一点的海拔"],
  "analyze_terrain":["分析地形","地形分析","这个区域的坡度图"],
  "identify_hazards":["识别危险区域","这里有危险吗","显示风险图"],
  "generate_route":["生成路线","计算路线","规划路线"],
  "optimize_route":["为{CRIT}优化路线","让路线{CRIT}","偏好{CRIT}路线"],
  "explain_route":["解释这条路线","为什么选这条路线","说明路线理由"],
  "current_context":["我在哪里","当前视图是什么","当前地图上下文"],
  "search_datasets":["这个区域有哪些数据集","这里有什么NASA数据","数据来源"],
  "planet_fact":["火星的重力是多少","一天有多长","大气压是多少","辐射水平","火星离太阳多远"],
  "tallest_deepest":["最高的山是什么","最高的火山","火星最低点"],
  "model_info":["你会说哪些语言","这个AI怎么工作","模型信息"],
  "create_mission":["创建从{FEAT}到{FEAT2}的{TYPE}任务","规划从{FEAT}到{FEAT2}的{TYPE}任务"],
  "add_waypoint":["在{FEAT}添加航点","在{FEAT}加一个停靠点"],
  "elevation_profile":["从{FEAT}到{FEAT2}的高程剖面","{FEAT}到{FEAT2}的剖面"],
},
"es": {
  "navigate":["llévame a {FEAT}","ve a {FEAT}","vuela a {FEAT}","muéstrame {FEAT}"],
  "activate_layer":["muestra la capa {LAYER}","activa {LAYER}","enciende {LAYER}"],
  "find_targets":["busca objetivos interesantes en {RAD} {UNIT}","busca objetivos científicos","busca minerales hidratados"],
  "observations_nearby":["qué observaciones hay en {RAD} {UNIT}","qué datos cubren esta zona","conjuntos de datos cerca"],
  "elevation_here":["cuál es la elevación aquí","a qué altura estoy","elevación en este punto"],
  "analyze_terrain":["analiza el terreno","análisis del terreno","mapa de pendientes de esta vista"],
  "identify_hazards":["identifica peligros","hay peligros aquí","muestra el mapa de riesgo"],
  "generate_route":["genera una ruta","calcula la ruta","planifica una ruta"],
  "optimize_route":["optimiza la ruta para {CRIT}","haz la ruta {CRIT}","prefiere una ruta {CRIT}"],
  "explain_route":["explica la ruta","por qué esta ruta","explica por qué este camino"],
  "current_context":["dónde estoy","cuál es mi vista actual","contexto actual del mapa"],
  "search_datasets":["qué conjuntos de datos cubren esta región","qué datos de nasa hay aquí","fuentes de datos"],
  "planet_fact":["cuál es la gravedad","cuánto dura un día","cuál es la presión atmosférica","nivel de radiación","a qué distancia está marte del sol"],
  "tallest_deepest":["cuál es la montaña más alta","volcán más alto","punto más profundo de marte"],
  "model_info":["qué idiomas hablas","cómo funciona la ia","información del modelo"],
  "create_mission":["crea una misión {TYPE} de {FEAT} a {FEAT2}","planifica una misión {TYPE} de {FEAT} a {FEAT2}"],
  "add_waypoint":["añade un punto de ruta en {FEAT}","añade una parada en {FEAT}"],
  "elevation_profile":["perfil de elevación de {FEAT} a {FEAT2}","perfil de {FEAT} a {FEAT2}"],
},
"fr": {
  "navigate":["emmène-moi à {FEAT}","va à {FEAT}","vole vers {FEAT}","montre-moi {FEAT}"],
  "activate_layer":["affiche la couche {LAYER}","active {LAYER}","allume {LAYER}"],
  "find_targets":["cherche des cibles intéressantes dans {RAD} {UNIT}","cherche des cibles scientifiques","cherche des minéraux hydratés"],
  "observations_nearby":["quelles observations dans {RAD} {UNIT}","quelles données couvrent cette zone","jeux de données à proximité"],
  "elevation_here":["quelle est l'élévation ici","à quelle altitude suis-je","élévation en ce point"],
  "analyze_terrain":["analyse le terrain","analyse du terrain","carte des pentes de cette vue"],
  "identify_hazards":["identifie les dangers","y a-t-il des dangers ici","affiche la carte des risques"],
  "generate_route":["génère un itinéraire","calcule l'itinéraire","planifie un itinéraire"],
  "optimize_route":["optimise l'itinéraire pour {CRIT}","rends l'itinéraire {CRIT}","préfère un itinéraire {CRIT}"],
  "explain_route":["explique l'itinéraire","pourquoi cet itinéraire","explique pourquoi ce chemin"],
  "current_context":["où suis-je","quelle est ma vue actuelle","contexte actuel de la carte"],
  "search_datasets":["quels jeux de données couvrent cette région","quelles données nasa ici","sources de données"],
  "planet_fact":["quelle est la gravité","combien dure un jour","quelle est la pression atmosphérique","niveau de rayonnement","à quelle distance est mars du soleil"],
  "tallest_deepest":["quelle est la montagne la plus haute","volcan le plus haut","point le plus profond de mars"],
  "model_info":["quelles langues parles-tu","comment fonctionne l'ia","info modèle"],
  "create_mission":["crée une mission {TYPE} de {FEAT} à {FEAT2}","planifie une mission {TYPE} de {FEAT} à {FEAT2}"],
  "add_waypoint":["ajoute un point de passage à {FEAT}","ajoute un arrêt à {FEAT}"],
  "elevation_profile":["profil d'élévation de {FEAT} à {FEAT2}","profil de {FEAT} à {FEAT2}"],
},
"de": {
  "navigate":["bring mich zu {FEAT}","gehe zu {FEAT}","fliege zu {FEAT}","zeig mir {FEAT}"],
  "activate_layer":["zeige die {LAYER}-ebene","aktiviere {LAYER}","schalte {LAYER} ein"],
  "find_targets":["finde interessante ziele innerhalb {RAD} {UNIT}","finde wissenschaftliche ziele","finde hydratisierte minerale"],
  "observations_nearby":["welche beobachtungen gibt es in {RAD} {UNIT}","welche daten decken diese zone ab","datensätze in der nähe"],
  "elevation_here":["wie hoch ist es hier","auf welcher höhe bin ich","höhe an diesem punkt"],
  "analyze_terrain":["analysiere das gelände","geländeanalyse","hangneigungskarte dieser ansicht"],
  "identify_hazards":["identifiziere gefahren","gibt es hier gefahren","zeige die risikokarte"],
  "generate_route":["generiere eine route","berechne die route","plane eine route"],
  "optimize_route":["optimiere die route für {CRIT}","mache die route {CRIT}","bevorzuge eine {CRIT} route"],
  "explain_route":["erkläre die route","warum diese route","erkläre warum dieser weg"],
  "current_context":["wo bin ich","was ist meine aktuelle ansicht","aktueller kartenkontext"],
  "search_datasets":["welche datensätze decken diese region","welche nasa-daten gibt es hier","datenquellen"],
  "planet_fact":["wie groß ist die schwerkraft","wie lange dauert ein tag","wie hoch ist der luftdruck","strahlungsniveau","wie weit ist der mars von der sonne"],
  "tallest_deepest":["welches ist der höchste berg","höchster vulkan","tiefster punkt des mars"],
  "model_info":["welche sprachen sprichst du","wie funktioniert die ki","modell-info"],
  "create_mission":["erstelle eine {TYPE}-mission von {FEAT} nach {FEAT2}","plane eine {TYPE}-mission von {FEAT} nach {FEAT2}"],
  "add_waypoint":["füge einen wegpunkt bei {FEAT} hinzu","füge einen stopp bei {FEAT} hinzu"],
  "elevation_profile":["höhenprofil von {FEAT} nach {FEAT2}","profil von {FEAT} nach {FEAT2}"],
},
"ru": {
  "navigate":["отправься к {FEAT}","перейди к {FEAT}","лети к {FEAT}","покажи {FEAT}"],
  "activate_layer":["покажи слой {LAYER}","включи {LAYER}","активируй {LAYER}"],
  "find_targets":["найди интересные цели в радиусе {RAD} {UNIT}","найди научные цели","найди гидратированные минералы"],
  "observations_nearby":["какие наблюдения в радиусе {RAD} {UNIT}","какие данные покрывают эту зону","наборы данных рядом"],
  "elevation_here":["какая здесь высота","на какой высоте я","высота в этой точке"],
  "analyze_terrain":["проанализируй рельеф","анализ рельефа","карта уклонов этого обзора"],
  "identify_hazards":["определи опасные участки","здесь есть опасности","покажи карту рисков"],
  "generate_route":["построй маршрут","рассчитай маршрут","спланируй маршрут"],
  "optimize_route":["оптимизируй маршрут для {CRIT}","сделай маршрут {CRIT}","предпочти {CRIT} маршрут"],
  "explain_route":["объясни маршрут","почему этот маршрут","объясни почему этот путь"],
  "current_context":["где я","какой мой текущий обзор","текущий контекст карты"],
  "search_datasets":["какие наборы данных покрывают этот регион","какие данные nasa здесь","источники данных"],
  "planet_fact":["какая гравитация","сколько длится день","каково атмосферное давление","уровень радиации","на каком расстоянии марс от солнца"],
  "tallest_deepest":["какая самая высокая гора","высочайший вулкан","самая глубокая точка марса"],
  "model_info":["на каких языках говоришь","как работает ии","информация о модели"],
  "create_mission":["создай {TYPE} миссию из {FEAT} в {FEAT2}","спланируй {TYPE} миссию из {FEAT} в {FEAT2}"],
  "add_waypoint":["добавь точку маршрута у {FEAT}","добавь остановку у {FEAT}"],
  "elevation_profile":["профиль высот от {FEAT} до {FEAT2}","профиль от {FEAT} до {FEAT2}"],
},
"ar": {
  "navigate":["خذني إلى {FEAT}","اذهب إلى {FEAT}","طر إلى {FEAT}","أرني {FEAT}"],
  "activate_layer":["اعرض طبقة {LAYER}","فعّل {LAYER}","شغّل {LAYER}"],
  "find_targets":["ابحث عن أهداف مثيرة ضمن {RAD} {UNIT}","ابحث عن أهداف علمية","ابحث عن معادن مائية"],
  "observations_nearby":["ما الرصد المتوفر ضمن {RAD} {UNIT}","ما البيانات التي تغطي هذه المنطقة","مجموعات بيانات قريبة"],
  "elevation_here":["ما الارتفاع هنا","على أي ارتفاع أنا","الارتفاع عند هذه النقطة"],
  "analyze_terrain":["حلل التضاريس","تحليل التضاريس","خريطة الميول لهذا العرض"],
  "identify_hazards":["حدد المخاطر","هل هناك مخاطر هنا","اعرض خريطة المخاطر"],
  "generate_route":["أنشئ مساراً","احسب المسار","خطط مساراً"],
  "optimize_route":["حسّن المسار من أجل {CRIT}","اجعل المسار {CRIT}","فضّل مساراً {CRIT}"],
  "explain_route":["اشرح المسار","لماذا هذا المسار","اشرح سبب هذا الطريق"],
  "current_context":["أين أنا","ما عرضي الحالي","سياق الخريطة الحالي"],
  "search_datasets":["ما مجموعات البيانات التي تغطي هذا الإقليم","ما بيانات nasa المتوفرة هنا","مصادر البيانات"],
  "planet_fact":["ما الجاذبية","كم يدوم اليوم","ما الضغط الجوي","مستوى الإشعاع","كم يبعد المريخ عن الشمس"],
  "tallest_deepest":["ما أعلى جبل","أعلى بركان","أعمق نقطة على المريخ"],
  "model_info":["ما اللغات التي تتكلمها","كيف يعمل الذكاء الاصطناعي","معلومات النموذج"],
  "create_mission":["أنشئ مهمة {TYPE} من {FEAT} إلى {FEAT2}","خطط مهمة {TYPE} من {FEAT} إلى {FEAT2}"],
  "add_waypoint":["أضف نقطة طريق عند {FEAT}","أضف توقفاً عند {FEAT}"],
  "elevation_profile":["مقطع ارتفاع من {FEAT} إلى {FEAT2}","مقطع من {FEAT} إلى {FEAT2}"],
},
"hi": {
  "navigate":["मुझे {FEAT} पर ले जाओ","{FEAT} पर जाओ","{FEAT} पर उड़ो","मुझे {FEAT} दिखाओ"],
  "activate_layer":["{LAYER} परत दिखाओ","{LAYER} सक्रिय करो","{LAYER} चालू करो"],
  "find_targets":["{RAD} {UNIT} के भीतर रोचक लक्ष्य ढूंढो","वैज्ञानिक लक्ष्य ढूंढो","जलीय खनिज ढूंढो"],
  "observations_nearby":["{RAD} {UNIT} के भीतर कौन से अवलोकन हैं","कौन सा डेटा इस क्षेत्र को कवर करता है","आसपास के डेटासेट"],
  "elevation_here":["यहाँ ऊँचाई कितनी है","मैं किस ऊँचाई पर हूँ","इस बिंदु पर ऊँचाई"],
  "analyze_terrain":["भूभाग का विश्लेषण करो","भूभाग विश्लेषण","इस दृश्य का ढाल मानचित्र"],
  "identify_hazards":["खतरों की पहचान करो","क्या यहाँ खतरे हैं","जोखिम मानचित्र दिखाओ"],
  "generate_route":["मार्ग बनाओ","मार्ग की गणना करो","मार्ग योजना बनाओ"],
  "optimize_route":["{CRIT} हेतु मार्ग अनुकूलित करो","मार्ग को {CRIT} बनाओ","{CRIT} मार्ग पसंद करो"],
  "explain_route":["मार्ग समझाओ","यह मार्ग क्यों","इस रास्ते का कारण बताओ"],
  "current_context":["मैं कहाँ हूँ","मेरा वर्तमान दृश्य क्या है","वर्तमान मानचित्र संदर्भ"],
  "search_datasets":["कौन से डेटासेट इस क्षेत्र को कवर करते हैं","यहाँ कौन सा nasa डेटा है","डेटा स्रोत"],
  "planet_fact":["गुरुत्वाकर्षण कितना है","दिन कितनी देर चलता है","वायुमंडलीय दबाव क्या है","विकिरण स्तर","मंगल सूर्य से कितना दूर है"],
  "tallest_deepest":["सबसे ऊँचा पर्वत कौन","सबसे ऊँचा ज्वालामुखी","मंगल का सबसे गहरा बिंदु"],
  "model_info":["तुम कौन सी भाषाएँ बोलते हो","यह एआई कैसे काम करता है","मॉडल जानकारी"],
  "create_mission":["{FEAT} से {FEAT2} तक {TYPE} मिशन बनाओ","{FEAT} से {FEAT2} तक {TYPE} मिशन योजना बनाओ"],
  "add_waypoint":["{FEAT} पर वेपॉइंट जोड़ो","{FEAT} पर स्टॉप जोड़ो"],
  "elevation_profile":["{FEAT} से {FEAT2} तक ऊँचाई प्रोफ़ाइल","{FEAT} से {FEAT2} तक प्रोफ़ाइल"],
},
"ja": {
  "navigate":["{FEAT}へ連れて行って","{FEAT}に行って","{FEAT}に飛んで","{FEAT}を見せて"],
  "activate_layer":["{LAYER}レイヤを表示して","{LAYER}を有効にして","{LAYER}をオンにして"],
  "find_targets":["{RAD}{UNIT}以内の興味深い対象を見つけて","科学対象を見つけて","含水鉱物を探して"],
  "observations_nearby":["{RAD}{UNIT}以内の観測は何がありますか","この地域をカバーするデータ","近くのデータセット"],
  "elevation_here":["ここの標高はどれくらい","どの高さにいますか","この地点の標高"],
  "analyze_terrain":["地形を解析して","地形解析","この表示範囲の傾斜図"],
  "identify_hazards":["危険箇所を特定して","ここに危険はありますか","リスクマップを表示して"],
  "generate_route":["ルートを生成して","ルートを計算して","ルートを計画して"],
  "optimize_route":["{CRIT}でルートを最適化して","ルートを{CRIT}にして","{CRIT}ルートを優先して"],
  "explain_route":["ルートを説明して","なぜこのルート","この経路の理由を説明して"],
  "current_context":["どこにいますか","現在の表示は何","現在の地図コンテキスト"],
  "search_datasets":["この地域をカバーするデータセットは","ここにあるnasaデータ","データソース"],
  "planet_fact":["重力はどれくらい","一日はどれくらい長い","大気圧はいくら","放射線レベル","火星は太陽からどれくらい遠い"],
  "tallest_deepest":["一番高い山は","一番高い火山","火星で一番深い地点"],
  "model_info":["何語を話せますか","このAIはどう動きますか","モデル情報"],
  "create_mission":["{FEAT}から{FEAT2}への{TYPE}ミッションを作って","{FEAT}から{FEAT2}への{TYPE}ミッションを計画して"],
  "add_waypoint":["{FEAT}にウェイポイントを追加して","{FEAT}にストップを追加して"],
  "elevation_profile":["{FEAT}から{FEAT2}の標高断面","{FEAT}から{FEAT2}のプロファイル"],
},
}

def _feats_for_lang(lang):
    """Localized famous-feature names for a language (from ALIASES), plus a few
    English proper-noun fallbacks that users of any language commonly type."""
    names=[]
    for fid, al in ALIASES.items():
        names.extend(al.get(lang,[]))
    # English proper nouns are commonly used in any language's queries too
    for n in ["Olympus Mons","Hellas Planitia","Valles Marineris","Jezero crater",
              "Gale crater","Arsia Mons","Elysium Mons"]:
        if n not in names: names.append(n)
    return names

def _native_fillers(L, lang):
    """slot -> value list for native templates, drawn from localized lexicon.
    FEAT/FEAT2 use LOCALIZED feature names so native queries match exactly."""
    feats=_feats_for_lang(lang)
    return {
      "FEAT": feats, "FEAT2": list(reversed(feats)),
      "LAYER": list(L["layers"].values()),
      "TYPE": list(L["mission_types"].values()),
      "CRIT": list(L["criteria"].values()),
      "FMT": list(L["formats"].values()),
      "RAD": ["200","500","800","1000"], "UNIT": L["units"][:1],
      "FROM": L["from"][:1], "TO": L["to"][:1],
      "HERE": L["here"], "NEAR": L["near"][:1],
    }

def gen_examples(lang):
    L=LEX[lang]
    ex=[]  # (text, intent)
    def add(intent, texts):
        for t in texts: ex.append({"text":t,"intent":intent,"lang":lang})

    # ---- native (fully localized) templates first — these carry the most signal
    nf=_native_fillers(L, lang)
    for intent, tpls in NATIVE.get(lang,{}).items():
        add(intent, _expand(lang, tpls, nf))
    # ---- extra verb-forward variants for intents that overlap with create_mission
    #  (export_mission shares "mission/misión/ミッション" with create_mission) and
    #  thin intents (identify_hazards / explain_route / thanks) that need more mass.
    EXTRA={
      "export_mission":{
        "en":["export as {FMT}","download {FMT}","save the mission as {FMT}","export {FMT}"],
        "zh":["导出为{FMT}","下载{FMT}","保存任务为{FMT}"],
        "es":["exporta como {FMT}","descarga {FMT}","guarda como {FMT}","exportar {FMT}"],
        "fr":["exporte en {FMT}","télécharge {FMT}","sauve en {FMT}"],
        "de":["exportiere als {FMT}","lade {FMT} herunter","speichere als {FMT}"],
        "ru":["экспортируй в {FMT}","скачай {FMT}","сохрани как {FMT}"],
        "ar":["صدّر بصيغة {FMT}","حمّل {FMT}","احفظ كـ {FMT}"],
        "hi":["{FMT} के रूप में निर्यात करो","{FMT} डाउनलोड करो","मिशन को {FMT} में सहेजो"],
        "ja":["{FMT}で書き出して","{FMT}でダウンロード","{FMT}として保存して"],
      },
      "identify_hazards":{
        "en":["any hazards here","danger map","show risks","is this terrain dangerous"],
        "zh":["这里有危险吗","显示风险图","危险地图","这里安全吗"],
        "es":["peligros aquí","mapa de riesgos","es peligroso el terreno","mostrar riesgos"],
        "fr":["dangers ici","carte des risques","le terrain est-il dangereux","montrer les risques"],
        "de":["gefahren hier","risikokarte","ist das gelände gefährlich","zeige risiken"],
        "ru":["опасности здесь","карта рисков","рельеф опасен","покажи риски"],
        "ar":["المخاطر هنا","خريطة المخاطر","هل التضاريس خطرة","أظهر المخاطر"],
        "hi":["खतरे पहचानो","खतरों की पहचान करो","जोखिम मानचित्र दिखाओ","यह भूभाग खतरनाक है"],
        "ja":["危険箇所","リスクマップ","この地形は危険","リスクを表示して"],
      },
      "explain_route":{
        "en":["why this route","explain the path","route reasoning","why was this route chosen"],
        "zh":["为什么这条路线","解释路径","路线理由","为何选这条路线"],
        "es":["por qué esta ruta","explica el camino","razón de la ruta"],
        "fr":["pourquoi cet itinéraire","explique le chemin","raison de l'itinéraire"],
        "de":["warum diese route","erkläre den weg","grund der route"],
        "ru":["почему этот маршрут","объясни путь","причина маршрута"],
        "ar":["لماذا هذا المسار","اشرح الطريق","سبب المسار"],
        "hi":["यह मार्ग क्यों","रास्ता समझाओ","मार्ग का कारण"],
        "ja":["なぜこのルート","経路を説明して","ルートの理由"],
      },
    }
    ef=_native_fillers(L, lang)
    for intent, tpls in EXTRA.items():
        if(lang in tpls): add(intent, _expand(lang, tpls[lang], ef))

    # 1 navigate -----------------------------------------------------------
    add("navigate", _expand(lang,
        [f"{v} {{PLACE}}" for v in L["nav_verbs"]] +
        [f"{v} {{FEAT}}" for v in L["nav_verbs"][:5]],
        {"PLACE": FEATURES_EN[:10], "FEAT": FEATURES_EN[10:16]}))

    # 2 activate_layer -----------------------------------------------------
    add("activate_layer", _expand(lang,
        [f"{v} {{LAYER}} layer" for v in L["layer_verbs"][:4]] +
        [f"{v} {{LAYER}}" for v in L["layer_verbs"][:4]],
        {"LAYER": list(L["layers"].values())}))

    # 3 compare_layers -----------------------------------------------------
    add("compare_layers", _expand(lang,
        [f"compare {{LAYER}} {{AND}} {{LAYER2}}",
         f"compare elevation and geology"],
        {"LAYER": ["mola","elevation"], "LAYER2":["hillshade","geology"], "AND": L["and"][:2]}))

    # 4 observations_nearby ------------------------------------------------
    add("observations_nearby", _expand(lang,
        [f"what observations {{NEAR}} {{RAD}} {{UNIT}}",
         f"what data is {{HERE}}",
         f"datasets {{NEAR}} {{RAD}} {{UNIT}}",
         f"what observations exist {{HERE}}"],
        {"NEAR": L["near"][:2], "RAD":["200","500","800","1000"], "UNIT": L["units"][:1],
         "HERE": L["here"][:2]}))

    # 5 elevation_here -----------------------------------------------------
    add("elevation_here", _expand(lang,
        [f"what is the elevation {{HERE}}",
         f"how high {{HERE}}",
         f"elevation {{HERE}}",
         f"altitude {{HERE}}"],
        {"HERE": L["here"]}))

    # 6 elevation_profile --------------------------------------------------
    add("elevation_profile", _expand(lang,
        [f"{{PF}} {{FEAT}} {{TO}} {{FEAT2}}",
         f"elevation profile {{FEAT}} {{TO}} {{FEAT2}}",
         f"profile {{FEAT}} {{TO}} {{FEAT2}}"],
        {"PF": L["profile_from"][:1], "FEAT": FEATURES_EN[:6], "FEAT2": FEATURES_EN[6:12],
         "TO": L["to"][:2]}))

    # 7 analyze_terrain ----------------------------------------------------
    add("analyze_terrain", _expand(lang,
        [f"analyze terrain", f"terrain analysis", f"slope map",
         f"analyze the terrain", f"terrain here"], {}))

    # 8 identify_hazards ---------------------------------------------------
    add("identify_hazards", _expand(lang,
        [f"identify hazards", f"hazards here", f"dangerous terrain",
         f"risk map", f"any hazards"], {}))

    # 9 find_targets -------------------------------------------------------
    add("find_targets", _expand(lang,
        [f"find interesting targets {{NEAR}} {{RAD}} {{UNIT}}",
         f"find science targets",
         f"find hydrated minerals",
         f"scientifically interesting areas {{NEAR}} {{RAD}} {{UNIT}}"],
        {"NEAR": L["near"][:2], "RAD":["500","800"], "UNIT": L["units"][:1]}))

    # 10 create_mission ----------------------------------------------------
    add("create_mission", _expand(lang,
        [f"create a {{TYPE}} mission {{FROM}} {{FEAT}} {{TO}} {{FEAT2}}",
         f"create mission {{FROM}} {{FEAT}} {{TO}} {{FEAT2}}",
         f"new {{TYPE}} mission {{FROM}} {{FEAT}} {{TO}} {{FEAT2}}",
         f"plan a {{TYPE}} mission {{FROM}} {{FEAT}} {{TO}} {{FEAT2}}"],
        {"TYPE": list(L["mission_types"].values()), "FEAT": FEATURES_EN[:6],
         "FEAT2": FEATURES_EN[6:12], "FROM": L["from"][:2], "TO": L["to"][:2]}))

    # 11 generate_route ----------------------------------------------------
    add("generate_route", _expand(lang,
        [f"generate route", f"compute route", f"plan a route",
         f"make me a route", f"generate routes"], {}))

    # 12 optimize_route ----------------------------------------------------
    add("optimize_route", _expand(lang,
        [f"optimize route for {{CRIT}}", f"optimize for {{CRIT}}",
         f"prefer {{CRIT}} route", f"make it {{CRIT}}"],
        {"CRIT": list(L["criteria"].values())}))

    # 13 add_waypoint ------------------------------------------------------
    add("add_waypoint", _expand(lang,
        [f"add a waypoint at {{FEAT}}", f"add waypoint {{FEAT}}",
         f"add a stop at {{FEAT}}", f"waypoint {{FEAT}}"],
        {"FEAT": FEATURES_EN[:8]}))

    # 14 explain_route -----------------------------------------------------
    add("explain_route", _expand(lang,
        [f"explain the route", f"why this route", f"explain route"], {}))

    # 15 export_mission ----------------------------------------------------
    add("export_mission", _expand(lang,
        [f"export mission as {{FMT}}", f"export as {{FMT}}", f"download {{FMT}}"],
        {"FMT": list(L["formats"].values())}))

    # 16 current_context ---------------------------------------------------
    add("current_context", _expand(lang,
        [f"where am i", f"current position", f"current view",
         f"map context", f"what is my context"], {}))

    # 17 search_datasets ---------------------------------------------------
    add("search_datasets", _expand(lang,
        [f"what datasets cover this region", f"data source", f"nasa dataset",
         f"instrument", f"where to get data"], {}))

    # 18 planet_fact -------------------------------------------------------
    add("planet_fact", _expand(lang,
        [f"what is the gravity", f"mars gravity",
         f"how long is a day", f"sol length",
         f"how long is a year", f"orbital period",
         f"what is the atmospheric pressure", f"mars atmosphere",
         f"radiation level", f"radiation dose",
         f"surface temperature", f"how far from the sun"], {}))

    # 19 feature_info ------------------------------------------------------
    add("feature_info", _expand(lang,
        [f"{{W}} {{FEAT}}", f"{{W}} {{FEAT}}",
         f"{{WHY}} {{FEAT}}"],
        {"W": L["what"][:3], "FEAT": FEATURES_EN[:10], "WHY": L["why"][:2]}))

    # 20 tallest_deepest ---------------------------------------------------
    add("tallest_deepest", _expand(lang,
        [f"tallest mountain", f"highest volcano", f"largest volcano",
         f"deepest point", f"lowest point on mars"], {}))

    # 21 mission_site_info -------------------------------------------------
    add("mission_site_info", _expand(lang,
        [f"{{W}} curiosity", f"{{W}} perseverance", f"{{W}} opportunity",
         f"where did perseverance land", f"curiosity landing site",
         f"how far has perseverance driven", f"perseverance distance record"], 
        {"W": L["what"][:2]}))

    # 22 instrument_info ---------------------------------------------------
    add("instrument_info", _expand(lang,
        [f"{{W}} hirise", f"{{W}} crism", f"{{W}} ctx",
         f"{{W}} themis", f"what is mola instrument"], 
        {"W": L["what"][:2]}))

    # 23 greet -------------------------------------------------------------
    add("greet", _expand(lang, [g for g in L["greet"]], {}))

    # 24 help --------------------------------------------------------------
    add("help", _expand(lang, [h for h in L["help"]], {}))

    # 25 thanks ------------------------------------------------------------
    add("thanks", _expand(lang, [t for t in L["thanks"]], {}))

    # 26 model_info / meta -------------------------------------------------
    add("model_info", _expand(lang,
        [f"what language do you speak", f"what languages",
         f"which languages", f"model info", f"how does the ai work"], {}))

    return ex

# ---------------------------------------------------------------------------
# Localized response templates (slot-filled at runtime in JS)
# ---------------------------------------------------------------------------
def build_responses():
    R={"en":{
      "navigate":"Navigating to <b>{name}</b> ({lat}, {lon}).",
      "activate_layer":"Activating the <b>{layer}</b> layer.",
      "compare_layers":"Comparing elevation and geology layers.",
      "observations_nearby":"Observation inventory within {radius} km:",
      "elevation_here":"Current elevation context:",
      "elevation_profile":"Elevation profile from {a} to {b}:",
      "analyze_terrain":"Terrain analysis of the current view:",
      "identify_hazards":"Hazard identification:",
      "find_targets":"Scientifically interesting targets within {radius} km:",
      "create_mission":"Created a {type} mission from {from} to {to}.",
      "generate_route":"Generating terrain-aware candidate routes…",
      "optimize_route":"Re-optimizing the selected route for <b>{criterion}</b>.",
      "add_waypoint":"Waypoint added at {place}.",
      "explain_route":"Route explanation:",
      "export_mission":"Exported mission as <b>{fmt}</b>.",
      "current_context":"Current map context:",
      "search_datasets":"Dataset lookup complete:",
      "planet_fact":"Planetary fact:",
      "feature_info":"Feature overview:",
      "tallest_deepest":"Extremum:",
      "mission_site_info":"Mission site:",
      "instrument_info":"Instrument:",
      "greet":"Hello — I'm NAM, your Mars navigation assistant. Ask me to navigate, analyze terrain, or build a mission.",
      "help":"I can navigate ('take me to Jezero Crater'), read terrain ('elevation profile Olympus Mons to Hellas'), inventory data, analyze hazards, and build/optimize missions. I work in 9 languages and ground every claim in embedded NASA-derived data.",
      "thanks":"Anytime. Ask me anything about Mars.",
      "model_info":"I'm a trained multilingual intent classifier (TF-IDF + logistic regression, 9 languages, {n_intents} intents) backed by a retrieval corpus over the embedded NASA catalog. Retrain me any time with the nam_train toolkit.",
      "fallback":"I couldn't confidently route that. I can navigate, analyze terrain, inventory data, identify hazards, and build/optimize missions. For live catalogs see Layers → registry links.",
    },
    "zh":{
      "navigate":"正在前往 <b>{name}</b>（{lat}, {lon}）。",
      "activate_layer":"正在启用 <b>{layer}</b> 图层。",
      "compare_layers":"正在对比高程与地质图层。",
      "observations_nearby":"{radius} 公里范围内的观测清单：",
      "elevation_here":"当前高程信息：",
      "elevation_profile":"从 {a} 到 {b} 的高程剖面：",
      "analyze_terrain":"当前视野的地形分析：",
      "identify_hazards":"危险区域识别：",
      "find_targets":"{radius} 公里范围内有科学价值的目标：",
      "create_mission":"已创建从 {from} 到 {to} 的{type}任务。",
      "generate_route":"正在生成地形感知的候选路线…",
      "optimize_route":"按 <b>{criterion}</b> 重新优化所选路线。",
      "add_waypoint":"已在 {place} 添加航点。",
      "explain_route":"路线说明：",
      "export_mission":"已将任务导出为 <b>{fmt}</b>。",
      "current_context":"当前地图上下文：",
      "search_datasets":"数据集查询完成：",
      "planet_fact":"行星常识：",
      "feature_info":"地貌概况：",
      "tallest_deepest":"极值：",
      "mission_site_info":"任务着陆点：",
      "instrument_info":"科学仪器：",
      "greet":"你好——我是 NAM，你的火星导航助手。可以让我导航、分析地形或规划任务。",
      "help":"我能导航（“带我去耶泽罗陨石坑”）、读取地形（“奥林帕斯山到海拉斯的高程剖面”）、盘点数据、识别危险、构建并优化任务。支持 9 种语言，所有结论都基于内嵌的 NASA 数据。",
      "thanks":"不客气，随时问我火星的任何问题。",
      "model_info":"我是一个训练好的多语言意图分类器（TF-IDF + 逻辑回归，9 种语言，{n_intents} 个意图），后接基于内嵌 NASA 目录的检索式问答。可随时用 nam_train 工具包重新训练我。",
      "fallback":"我无法确定如何处理这句话。我能导航、分析地形、盘点数据、识别危险、构建并优化任务。实时目录请见“图层”中的注册表链接。",
    },
    "es":{
      "navigate":"Navegando a <b>{name}</b> ({lat}, {lon}).",
      "activate_layer":"Activando la capa <b>{layer}</b>.",
      "compare_layers":"Comparando capas de elevación y geología.",
      "observations_nearby":"Inventario de observaciones en {radius} km:",
      "elevation_here":"Contexto de elevación actual:",
      "elevation_profile":"Perfil de elevación de {a} a {b}:",
      "analyze_terrain":"Análisis del terreno en la vista actual:",
      "identify_hazards":"Identificación de peligros:",
      "find_targets":"Objetivos de interés científico en {radius} km:",
      "create_mission":"Misión {type} creada de {from} a {to}.",
      "generate_route":"Generando rutas candidatas según el terreno…",
      "optimize_route":"Reoptimizando la ruta para <b>{criterion}</b>.",
      "add_waypoint":"Punto de ruta añadido en {place}.",
      "explain_route":"Explicación de la ruta:",
      "export_mission":"Misión exportada como <b>{fmt}</b>.",
      "current_context":"Contexto actual del mapa:",
      "search_datasets":"Búsqueda de datos completada:",
      "planet_fact":"Dato planetario:",
      "feature_info":"Vista general del elemento:",
      "tallest_deepest":"Extremo:",
      "mission_site_info":"Sitio de la misión:",
      "instrument_info":"Instrumento:",
      "greet":"Hola — soy NAM, tu asistente de navegación de Marte. Pídeme navegar, analizar el terreno o planificar una misión.",
      "help":"Puedo navegar ('llévame al cráter Jezero'), leer el terreno ('perfil de elevación de Olympus Mons a Hellas'), inventariar datos, identificar peligros y crear/optimizar misiones. Funciono en 9 idiomas y fundamento cada afirmación en datos NASA incrustados.",
      "thanks":"Cuando quieras. Pregúntame sobre Marte.",
      "model_info":"Soy un clasificador multilingüe entrenado (TF-IDF + regresión logística, 9 idiomas, {n_intents} intents) respaldado por un corpus de recuperación sobre el catálogo NASA incrustado. Reentréname con el toolkit nam_train.",
      "fallback":"No pude enrutar eso con confianza. Puedo navegar, analizar terreno, inventariar datos, identificar peligros y crear/optimizar misiones.",
    },
    "fr":{
      "navigate":"Navigation vers <b>{name}</b> ({lat}, {lon}).",
      "activate_layer":"Activation de la couche <b>{layer}</b>.",
      "compare_layers":"Comparaison des couches d'élévation et de géologie.",
      "observations_nearby":"Inventaire des observations dans {radius} km :",
      "elevation_here":"Contexte d'élévation actuel :",
      "elevation_profile":"Profil d'élévation de {a} à {b} :",
      "analyze_terrain":"Analyse du terrain sur la vue courante :",
      "identify_hazards":"Identification des dangers :",
      "find_targets":"Cibles d'intérêt scientifique dans {radius} km :",
      "create_mission":"Mission {type} créée de {from} à {to}.",
      "generate_route":"Génération d'itinéraires candidats adaptés au terrain…",
      "optimize_route":"Ré-optimisation de l'itinéraire pour <b>{criterion}</b>.",
      "add_waypoint":"Point de passage ajouté à {place}.",
      "explain_route":"Explication de l'itinéraire :",
      "export_mission":"Mission exportée en <b>{fmt}</b>.",
      "current_context":"Contexte cartographique actuel :",
      "search_datasets":"Recherche de jeux de données terminée :",
      "planet_fact":"Fait planétaire :",
      "feature_info":"Aperçu de l'élément :",
      "tallest_deepest":"Extremum :",
      "mission_site_info":"Site de mission :",
      "instrument_info":"Instrument :",
      "greet":"Bonjour — je suis NAM, votre assistant de navigation martienne. Demandez-moi de naviguer, analyser le terrain ou planifier une mission.",
      "help":"Je peux naviguer ('emmène-moi au cratère Jezero'), lire le terrain ('profil d'élévation d'Olympus Mons à Hellas'), inventorier les données, identifier les dangers et créer/optimiser des missions. Je fonctionne en 9 langues et fonde chaque affirmation sur les données NASA intégrées.",
      "thanks":"À votre service. Posez-moi vos questions sur Mars.",
      "model_info":"Je suis un classifieur d'intentions multilingue entraîné (TF-IDF + régression logistique, 9 langues, {n_intents} intentions) adossé à un corpus de récupération sur le catalogue NASA intégré. Réentraînez-moi avec le toolkit nam_train.",
      "fallback":"Je n'ai pas pu router cela avec confiance. Je peux naviguer, analyser le terrain, inventorier les données, identifier les dangers et créer/optimiser des missions.",
    },
    "de":{
      "navigate":"Navigiere zu <b>{name}</b> ({lat}, {lon}).",
      "activate_layer":"Aktiviere die <b>{layer}</b>-Ebene.",
      "compare_layers":"Vergleiche Höhen- und Geologie-Ebenen.",
      "observations_nearby":"Beobachtungs-Inventar innerhalb {radius} km:",
      "elevation_here":"Aktuelle Höhen-Info:",
      "elevation_profile":"Höhenprofil von {a} nach {b}:",
      "analyze_terrain":"Geländeanalyse der aktuellen Ansicht:",
      "identify_hazards":"Gefahrenkennung:",
      "find_targets":"Wissenschaftlich interessante Ziele innerhalb {radius} km:",
      "create_mission":"{type}-Mission von {from} nach {to} erstellt.",
      "generate_route":"Generiere geländeangepasste Routenvorschläge…",
      "optimize_route":"Optimiere die Route für <b>{criterion}</b>.",
      "add_waypoint":"Wegpunkt bei {place} hinzugefügt.",
      "explain_route":"Routenerklärung:",
      "export_mission":"Mission als <b>{fmt}</b> exportiert.",
      "current_context":"Aktueller Kartenkontext:",
      "search_datasets":"Datensatz-Suche abgeschlossen:",
      "planet_fact":"Planeten-Fakt:",
      "feature_info":"Überblick zum Objekt:",
      "tallest_deepest":"Extremwert:",
      "mission_site_info":"Missionsstandort:",
      "instrument_info":"Instrument:",
      "greet":"Hallo — ich bin NAM, dein Mars-Navigationsassistent. Lass mich navigieren, Gelände analysieren oder eine Mission planen.",
      "help":"Ich kann navigieren ('bring mich zum Jezero-Krater'), Gelände lesen ('Höhenprofil von Olympus Mons nach Hellas'), Daten inventarisieren, Gefahren erkennen und Missionen erstellen/optimieren. Ich arbeite in 9 Sprachen und belege jede Aussage mit eingebetteten NASA-Daten.",
      "thanks":"Gern. Frag mich alles über den Mars.",
      "model_info":"Ich bin ein trainierter multilingualer Intent-Klassifikator (TF-IDF + logistische Regression, 9 Sprachen, {n_intents} Intents) mit einem Retrieval-Korpus über den eingebetteten NASA-Katalog. Trainier mich jederzeit mit dem nam_train-Toolkit neu.",
      "fallback":"Das konnte ich nicht zuverlässig routen. Ich kann navigieren, Gelände analysieren, Daten inventarisieren, Gefahren erkennen und Missionen erstellen/optimieren.",
    },
    "ru":{
      "navigate":"Перелёт к <b>{name}</b> ({lat}, {lon}).",
      "activate_layer":"Включаю слой <b>{layer}</b>.",
      "compare_layers":"Сравнение слоёв высот и геологии.",
      "observations_nearby":"Перечень наблюдений в радиусе {radius} км:",
      "elevation_here":"Текущая высота:",
      "elevation_profile":"Профиль высот от {a} до {b}:",
      "analyze_terrain":"Анализ рельефа текущего обзора:",
      "identify_hazards":"Опасные участки:",
      "find_targets":"Научно-интересные цели в радиусе {radius} км:",
      "create_mission":"Создана {type}-миссия из {from} в {to}.",
      "generate_route":"Строю маршруты с учётом рельефа…",
      "optimize_route":"Переоптимизация маршрута для <b>{criterion}</b>.",
      "add_waypoint":"Добавлена точка маршрута у {place}.",
      "explain_route":"Объяснение маршрута:",
      "export_mission":"Миссия экспортирована как <b>{fmt}</b>.",
      "current_context":"Текущий контекст карты:",
      "search_datasets":"Поиск данных завершён:",
      "planet_fact":"Факт о планете:",
      "feature_info":"Об объекте:",
      "tallest_deepest":"Экстремум:",
      "mission_site_info":"Место миссии:",
      "instrument_info":"Инструмент:",
      "greet":"Привет — я NAM, ваш марсианский навигационный ассистент. Просите navigating, анализировать рельеф или спланировать миссию.",
      "help":"Я умею navigating ('отправься к кратеру Езеро'), читать рельеф ('профиль высот от Олимпа до Эллады'), инвентаризировать данные, выявлять опасности и строить/оптимизировать миссии. Работаю на 9 языках, каждое утверждение опираю на встроенные данные NASA.",
      "thanks":"Пожалуйста. Спрашивайте о Марсе что угодно.",
      "model_info":"Я — обученный мультиязычный классификатор интентов (TF-IDF + логистическая регрессия, 9 языков, {n_intents} интентов) с поиском по встроенному каталогу NASA. Переобучайте меня в любой момент набором nam_train.",
      "fallback":"Не удалось уверенно определить действие. Я могу navigating, анализировать рельеф, инвентаризировать данные, выявлять опасности и строить/оптимизировать миссии.",
    },
    "ar":{
      "navigate":"نتجه إلى <b>{name}</b> ({lat}, {lon}).",
      "activate_layer":"تفعيل طبقة <b>{layer}</b>.",
      "compare_layers":"مقارنة طبقات الارتفاع والجيولوجيا.",
      "observations_nearby":"قائمة الرصد ضمن {radius} كم:",
      "elevation_here":"سياق الارتفاع الحالي:",
      "elevation_profile":"مقطع الارتفاع من {a} إلى {b}:",
      "analyze_terrain":"تحليل التضاريس للعرض الحالي:",
      "identify_hazards":"تحديد المخاطر:",
      "find_targets":"أهداف ذات أهمية علمية ضمن {radius} كم:",
      "create_mission":"تم إنشاء مهمة {type} من {from} إلى {to}.",
      "generate_route":"جارٍ توليد مسارات مرشحة تراعي التضاريس…",
      "optimize_route":"إعادة تحسين المسار لـ <b>{criterion}</b>.",
      "add_waypoint":"إضافة نقطة طريق عند {place}.",
      "explain_route":"شرح المسار:",
      "export_mission":"تصدير المهمة بصيغة <b>{fmt}</b>.",
      "current_context":"سياق الخريطة الحالي:",
      "search_datasets":"اكتمل البحث عن البيانات:",
      "planet_fact":"معلومة كوكبية:",
      "feature_info":"نظرة عامة على المعلم:",
      "tallest_deepest":"القيمة القصوى:",
      "mission_site_info":"موقع المهمة:",
      "instrument_info":"الجهاز:",
      "greet":"مرحباً — أنا NAM، مساعدك للملاحة على المريخ. اطلب التنقل أو تحليل التضاريس أو تخطيط مهمة.",
      "help":"أستطيع التنقل ('خذني إلى فوهة جيزيرو')، وقراءة التضاريس ('مقطع ارتفاع من أوليمبوس إلى هيلاس')، وجرد البيانات، وتحديد المخاطر، وبناء وتحسين المهام. أعمل بـ9 لغات وأستند إلى بيانات NASA المضمّنة.",
      "thanks":"على الرحب والسعة. اسألني أي شيء عن المريخ.",
      "model_info":"أنا مصنّف نيات متعدد اللغات مُدرَّب (TF-IDF + انحدار لوجستي، 9 لغات، {n_intents} نية) مدعوم بفهرس استرجاع على كتالوج NASA المضمّن. أعد تدريبي في أي وقت بأدوات nam_train.",
      "fallback":"تعذّر توجيه ذلك بثقة. أستطيع التنقل، وتحليل التضاريس، وجرد البيانات، وتحديد المخاطر، وبناء وتحسين المهام.",
    },
    "hi":{
      "navigate":"<b>{name}</b> ({lat}, {lon}) की ओर जा रहा हूँ।",
      "activate_layer":"<b>{layer}</b> परत सक्रिय कर रहा हूँ।",
      "compare_layers":"ऊँचाई और भूविज्ञान परतों की तुलना।",
      "observations_nearby":"{radius} किमी के भीतर अवलोकन सूची:",
      "elevation_here":"वर्तमान ऊँचाई संदर्भ:",
      "elevation_profile":"{a} से {b} तक ऊँचाई प्रोफ़ाइल:",
      "analyze_terrain":"वर्तमान दृश्य का भू-विश्लेषण:",
      "identify_hazards":"खतरों की पहचान:",
      "find_targets":"{radius} किमी के भीतर वैज्ञानिक रूप से रोचक लक्ष्य:",
      "create_mission":"{from} से {to} तक {type} मिशन बनाया।",
      "generate_route":"भूभाग-जागरूक उम्मीदवार मार्ग बना रहा हूँ…",
      "optimize_route":"चयनित मार्ग को <b>{criterion}</b> हेतु पुनः-अनुकूलित कर रहा हूँ।",
      "add_waypoint":"{place} पर वेपॉइंट जोड़ा।",
      "explain_route":"मार्ग व्याख्या:",
      "export_mission":"मिशन को <b>{fmt}</b> के रूप में निर्यात किया।",
      "current_context":"वर्तमान मानचित्र संदर्भ:",
      "search_datasets":"डेटासेट खोज पूर्ण:",
      "planet_fact":"ग्रह तथ्य:",
      "feature_info":"विशेषता का अवलोकन:",
      "tallest_deepest":"चरम:",
      "mission_site_info":"मिशन स्थल:",
      "instrument_info":"उपकरण:",
      "greet":"नमस्ते — मैं NAM हूँ, आपका मंगल नेविगेशन सहायक। नेविगेट, भूभाग विश्लेषण या मिशन योजना के लिए कहें।",
      "help":"मैं नेविगेट कर सकता हूँ ('मुझे जेज़ेरो क्रेटर पर ले जाओ'), भूभाग पढ़ सकता हूँ ('ओलिंपस से हेलस तक ऊँचाई प्रोफ़ाइल'), डेटा की सूची बना सकता हूँ, खतरे पहचान सकता हूँ और मिशन बना/अनुकूलित कर सकता हूँ। मैं 9 भाषाओं में काम करता हूँ और हर दावे को अंतःस्थापित NASA डेटा पर आधारित करता हूँ।",
      "thanks":"कोई बात नहीं। मंगल के बारे में कुछ भी पूछें।",
      "model_info":"मैं एक प्रशिक्षित बहुभाषी इंटेंट क्लासिफ़ायर हूँ (TF-IDF + लॉजिस्टिक रिग्रेशन, 9 भाषाएँ, {n_intents} इंटेंट) जो अंतःस्थापित NASA कैटलॉग पर रिट्रीवल कॉर्पस से समर्थित है। nam_train टूलकिट से कभी भी पुनः प्रशिक्षित करें।",
      "fallback":"मैं इसे आत्मविश्वास से रूट नहीं कर सका। मैं नेविगेट, भूभाग विश्लेषण, डेटा जानच, खतरे पहचान और मिशन बना/अनुकूलित कर सकता हूँ।",
    },
    "ja":{
      "navigate":"<b>{name}</b>（{lat}, {lon}）へ移動します。",
      "activate_layer":"<b>{layer}</b> レイヤを有効化します。",
      "compare_layers":"標高と地質レイヤを比較します。",
      "observations_nearby":"{radius} km 以内の観測一覧：",
      "elevation_here":"現在の標高情報：",
      "elevation_profile":"{a} から {b} の標高断面：",
      "analyze_terrain":"現在の表示範囲の地形解析：",
      "identify_hazards":"危険箇所の特定：",
      "find_targets":"{radius} km 以内の科学的に興味深い対象：",
      "create_mission":"{from} から {to} への{type}ミッションを作成しました。",
      "generate_route":"地形対応の候補ルートを生成中…",
      "optimize_route":"選択ルートを <b>{criterion}</b> で再最適化します。",
      "add_waypoint":"{place} にウェイポイントを追加しました。",
      "explain_route":"ルートの説明：",
      "export_mission":"ミッションを <b>{fmt}</b> でエクスポートしました。",
      "current_context":"現在の地図コンテキスト：",
      "search_datasets":"データセット検索完了：",
      "planet_fact":"惑星の事実：",
      "feature_info":"地形の概要：",
      "tallest_deepest":"極値：",
      "mission_site_info":"ミッション着陸地点：",
      "instrument_info":"観測機器：",
      "greet":"こんにちは——私は NAM、あなたの火星ナビゲーションアシスタントです。移動、地形分析、ミッション計画を指示してください。",
      "help":"移動（「イェゼロクレーターへ連れて行って」）、地形の読み取り（「オリンポス山からヘラスまで標高断面」）、データ一覧、危険箇所の特定、ミッションの作成・最適化ができます。9 言語で動作し、すべての主張は組み込みの NASA データに基づきます。",
      "thanks":"どういたしまして。火星について何でも聞いてください。",
      "model_info":"私は訓練済みの多言語インテント分類器（TF-IDF + ロジスティック回帰、9 言語、{n_intents} インテント）で、組み込み NASA カタログ上の検索コーパスを背後に持ちます。nam_train ツールキットでいつでも再訓練できます。",
      "fallback":"確信を持ってルーティングできませんでした。移動、地形分析、データ一覧、危険特定、ミッション作成・最適化が可能です。",
    }}
    return R

# ---------------------------------------------------------------------------
# Entity keywords (language-neutral canonical tokens used by the JS matcher)
# ---------------------------------------------------------------------------
def build_entities():
    ent={
      "layers": {
        # canonical layer id -> synonyms across languages (lowercased)
        "opm-basemap": ["basemap","base map","background","底图","mapa base","fond de carte","grundkarte","подложка","الخريطة الأساسية","बेस मैप","背景地図","opm"],
        "opm-hillshade": ["hillshade","hill shade","shaded relief","sombreado","ombrage","schummerung","отмывка","تظليل","हिलशेड","陰影","hill"],
        "opm-mola-color": ["mola","elevation","topography","高程","地形","elevación","topografía","élévation","höhe","topographie","высота","топография","ارتفاع","تضاريس","ऊँचाई","स्थलाकृति","標高","topo","relief"],
        "mola-roughness": ["roughness","rugosidad","rugosité","rauigkeit","шероховатость","خشونة","खुरदरापन","粗さ","rough"],
        "viking-mdim": ["viking","mdim","バイキング","海盗号","viking","viking","viking","viking","वाइकिंग","viking"],
      },
      "mission_types": {
        "rover": ["rover","火星车","rover","rover","rover","ровер","مركبة","रोवर","ローバー"],
        "human": ["human","crew","crewed","载人","humano","tripulado","humain","habité","bemannt","пилотируемый","مأهول","मानव","有人"],
        "geology": ["geology","geological","地质","geología","géologie","geologie","геология","جيولوجيا","भूविज्ञान","地質"],
        "mineral": ["mineral","mineralogy","矿物","mineral","minéral","mineral","минерал","معادن","खनिज","鉱物"],
        "sample": ["sample","sampling","采样","muestras","échantillons","proben","образцы","عينات","नमूने","サンプル"],
        "recon": ["recon","reconnaissance","侦察","reconocimiento","reconnaissance","aufklärung","разведка","استطلاع","अन्वेषण","偵察"],
      },
      "criteria": {
        "length": ["shortest","length","最短","más corto","le plus court","kürzeste","кратчайший","الأقصر","सबसे छोटा","最短","short"],
        "risk": ["safest","safe","risk","最安全","más seguro","le plus sûr","sicherste","безопасный","الأكثر أماناً","सबसे सुरक्षित","最も安全","safe"],
        "science": ["science","science","科研","ciencia","science","wissenschaft","наука","علم","विज्ञान","科学"],
        "balanced": ["balanced","均衡","equilibrado","équilibré","ausgewogen","сбалансированный","متوازن","संतुलित","バランス"],
      },
      "formats": {
        "json": ["json"], "csv": ["csv"], "txt": ["txt","text"],
      },
      "units": {
        "km": ["km","kms","kilomet","公里","千米","kilómetros","kilometros","kilomètres","kilometres","kilometer","километ","كم","كيلومتر","किमी","किलोमीटर","キロ","キロメートル"],
      },
      "feature_aliases": ALIASES,
    }
    return ent

# Intent metadata (label, tool to dispatch, needs_entities)
INTENT_META = [
  ("navigate","search_planetary_location",["place"]),
  ("activate_layer","activate_map_layer",["layer"]),
  ("compare_layers","_compare",[]),
  ("observations_nearby","get_location_observations",["radius"]),
  ("elevation_here","get_current_map_context",[]),
  ("elevation_profile","get_elevation_profile",["a","b"]),
  ("analyze_terrain","analyze_terrain",[]),
  ("identify_hazards","identify_hazards",[]),
  ("find_targets","find_scientific_targets",["radius"]),
  ("create_mission","create_mission",["type","from","to"]),
  ("generate_route","generate_route",[]),
  ("optimize_route","optimize_route",["criterion"]),
  ("add_waypoint","add_waypoint",["place"]),
  ("explain_route","explain_route",[]),
  ("export_mission","export_mission",["format"]),
  ("current_context","get_current_map_context",[]),
  ("search_datasets","search_nasa_datasets",["query"]),
  ("planet_fact","_kb_planet",[]),
  ("feature_info","_kb_feature",["place"]),
  ("tallest_deepest","_kb_extreme",[]),
  ("mission_site_info","_kb_site",["place"]),
  ("instrument_info","_kb_instrument",["query"]),
  ("greet","_conversational",[]),
  ("help","_conversational",[]),
  ("thanks","_conversational",[]),
  ("model_info","_conversational",[]),
  ("fallback","_fallback",[]),
]

def main():
    raw=[]
    for lang in LANGS:
        raw.extend(gen_examples(lang))
    # dedupe
    seen=set(); uniq=[]
    for e in raw:
        k=(e["text"],e["lang"])
        if k in seen: continue
        seen.add(k); uniq.append(e)
    # cap per (intent,lang) for class balance — keep variety, drop cartesian explosion
    CAP=80
    from collections import defaultdict
    buckets=defaultdict(list)
    for e in uniq:
        buckets[(e["intent"],e["lang"])].append(e)
    capped=[]
    for k,lst in buckets.items():
        random.shuffle(lst)
        capped.extend(lst[:CAP])
    # drop intents with no examples (fallback handled at runtime via threshold)
    random.shuffle(capped)
    examples=capped
    # ---- preserve feedback merged by collect_feedback.py across regenerations ----
    # collect_feedback.py appends user corrections (e.g. from nam_feedback.json)
    # to intents.json; without this, regenerating would silently wipe them.
    fb_merged=0
    fb_path=os.path.join(HERE,"intents.json")
    if os.path.exists(fb_path):
        try:
            prev=json.load(open(fb_path,encoding="utf-8"))
            # examples carrying the feedback marker OR arriving after the last
            # regeneration are exactly those collect_feedback.py added.
            gen_keys={(e["text"],e["lang"]) for e in examples}
            keys=[]
            for e in prev.get("examples",[]):
                k=(e["text"],e["lang"])
                if k not in gen_keys:
                    examples.append(e); fb_merged+=1
        except Exception as ex:
            print("feedback-preserve warning:",ex)
    intents={"intents":INTENT_META,"examples":examples,
             "languages":LANGS,"language_names":LANG_NAMES,
             "feedback_merged":fb_merged}
    with open(os.path.join(HERE,"intents.json"),"w",encoding="utf-8") as f:
        json.dump(intents,f,ensure_ascii=False,indent=1)
    with open(os.path.join(HERE,"responses.json"),"w",encoding="utf-8") as f:
        json.dump(build_responses(),f,ensure_ascii=False,indent=1)
    with open(os.path.join(HERE,"entities.json"),"w",encoding="utf-8") as f:
        json.dump(build_entities(),f,ensure_ascii=False,indent=1)
    # per-intent / per-language counts
    from collections import Counter
    print(f"wrote {len(examples)} examples across {len(INTENT_META)} intents x {len(LANGS)} langs (cap {CAP}/intent/lang)")
    print("per-intent totals:")
    bi=Counter(e["intent"] for e in examples)
    for intent, _tool, _needs in INTENT_META:
        langs=sorted(set(e["lang"] for e in examples if e["intent"]==intent))
        print(f"  {intent:22s} {bi[intent]:4d}   langs={len(langs)}")
    print("files: intents.json, responses.json, entities.json")

if __name__=="__main__":
    main()
