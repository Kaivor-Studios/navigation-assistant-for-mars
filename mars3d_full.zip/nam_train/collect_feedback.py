#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NAM feedback collector.

Merges your corrections into intents.json (as new labeled examples), so the
next `python train_model.py` learns from them. Repeated runs accumulate, and
`build_data.py` preserves the merged examples across regenerations.

Usage:

    python collect_feedback.py

expects `nam_feedback.json` next to this script, e.g.:

    [ {"text": "bring me to valles marineris", "intent": "navigate", "lang": "en"} ]

(the intent field may also be called "corrected" — the name an exported
feedback file would use).

Feedback record format (also accepted):
  [
    { "text": "...", "predicted": "...", "corrected": "...", "lang": "en", "t": 1700000000 },
    ...
  ]
"""
import json, os, sys
from collections import Counter

HERE=os.path.dirname(os.path.abspath(__file__))

def main():
    fb_path=os.path.join(HERE,"nam_feedback.json")
    if not os.path.exists(fb_path):
        print("no nam_feedback.json found here. Export feedback from the app's")
        print("AI Engine panel first, then copy the downloaded file into:")
        print("  "+fb_path)
        return
    fb=json.load(open(fb_path,encoding="utf-8"))
    if isinstance(fb,dict) and "feedback" in fb: fb=fb["feedback"]
    intents_path=os.path.join(HERE,"intents.json")
    intents=json.load(open(intents_path,encoding="utf-8"))
    existing={(e["text"],e["lang"]) for e in intents["examples"]}
    added=0; skipped=0
    for r in fb:
        text=(r.get("text") or "").strip()
        corr=r.get("corrected") or r.get("intent")
        lang=(r.get("lang") or "en")
        if not text or not corr or corr=="fallback":
            skipped+=1; continue
        key=(text,lang)
        if key in existing:
            skipped+=1; continue
        intents["examples"].append({"text":text,"intent":corr,"lang":lang})
        existing.add(key); added+=1
    # keep metadata sane
    intents.setdefault("feedback_merged",0)
    intents["feedback_merged"]=intents.get("feedback_merged",0)+added
    json.dump(intents,open(intents_path,"w",encoding="utf-8"),ensure_ascii=False,indent=1)
    print(f"merged {added} new example(s) into intents.json ({skipped} skipped as dupes/empty).")
    by=Counter(e["intent"] for e in intents["examples"])
    print("intent totals now:")
    for k in sorted(by): print(f"  {k:22s} {by[k]}")
    print("\nnext steps:")
    print("  python train_model.py                  # retrain on the merged data")
    print("  cp nam_model.json ../mars3d/data/nam_model.json   # drop into the backend")
    print("  (restart server.py to load it)")

if __name__=="__main__":
    main()
