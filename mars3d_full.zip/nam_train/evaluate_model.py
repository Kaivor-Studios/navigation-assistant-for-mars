#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NAM model evaluator — detailed metrics, confusion matrix, and a live
inference sanity check using the EXACT JSON inference path the browser runs.

Run:  python evaluate_model.py
"""
import json, os, re, math, warnings
import numpy as np
import warnings
from collections import Counter, defaultdict
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import confusion_matrix, classification_report

HERE=os.path.dirname(os.path.abspath(__file__))
CJK=re.compile(r"[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]")
WORD=re.compile(r"[A-Za-z0-9_\u00c0-\u00ff\u0100-\u024f\u0400-\u04ff\u0600-\u06ff\u0900-\u097f]+")
def tokenize(s):
    s=(s or "").lower(); toks=[]
    for m in WORD.finditer(s): toks.append(m.group())
    cjk=[c for c in s if CJK.match(c)]
    for c in cjk: toks.append(c)
    for i in range(len(cjk)-1): toks.append(cjk[i]+cjk[i+1])
    return toks

# ---- JS-equivalent inference over the exported JSON model ---------------
def js_infer(model, query):
    cl=model["classifier"]; vocab=cl["vocab"]; idf=cl["idf"]
    classes=cl["classes"]; intercept=cl["intercept"]; wbt=cl["weights_by_token"]
    toks=tokenize(query)
    tf=Counter(toks)
    vec={}
    for term,cnt in tf.items():
        idx=vocab.get(term)
        if idx is None: continue
        val=(1.0+math.log(cnt))*idf[idx]
        vec[idx]=val
    # l2 normalize
    norm=math.sqrt(sum(v*v for v in vec.values())) or 1.0
    scores=list(intercept)
    for idx,val in vec.items():
        col=wbt.get(str(idx))
        if not col: continue
        val/=norm
        for ci,w in col: scores[ci]+=val*w
    # softmax
    m=max(scores); exps=[math.exp(s-m) for s in scores]; Z=sum(exps)
    probs=[e/Z for e in exps]
    best=int(np.argmax(probs))
    return classes[best], probs[best], list(zip(classes,probs))

def main():
    warnings.filterwarnings("ignore")

    model=json.load(open(os.path.join(HERE,"nam_model.json"),encoding="utf-8"))
    intents=json.load(open(os.path.join(HERE,"intents.json"),encoding="utf-8"))
    exs=[e for e in intents["examples"] if e["intent"]!="fallback"]
    X_text=[e["text"] for e in exs]; y=[e["intent"] for e in exs]; langs=[e["lang"] for e in exs]

    # 1) Cross-validated full report (refits a fresh model per fold)
    vec=TfidfVectorizer(analyzer=tokenize,token_pattern=None,ngram_range=(1,1),
                        sublinear_tf=True,min_df=2,norm="l2")
    X=vec.fit_transform(X_text)
    classes=sorted(set(y))
    skf=StratifiedKFold(n_splits=5,shuffle=True,random_state=13)
    y_pred=[None]*len(y)
    for tr,va in skf.split(X,y):
        c=LogisticRegression(penalty="l1",solver="liblinear",C=2.0,
                             class_weight="balanced",max_iter=1500)
        c.fit(X[tr],[y[i] for i in tr])
        pr=c.predict(X[va])
        for k,i in enumerate(va): y_pred[i]=pr[k]
    print("=== 5-fold CV classification report ===")
    print(classification_report(y,y_pred,labels=classes,zero_division=0))

    # 2) JS-inference parity check: does the exported JSON agree with sklearn?
    print("=== JS-inference parity (exported model on its own training set) ===")
    agree=0
    for t,true in zip(X_text,y):
        pred,_p,_=js_infer(model,t)
        if pred==true: agree+=1
    print(f"  exported-JSON inference train agreement: {agree}/{len(y)} = {agree/len(y):.3f}")

    # 3) Confusion: which intents get confused with which (top pairs)
    cm=confusion_matrix(y,y_pred,labels=classes)
    inv={c:i for i,c in enumerate(classes)}
    confpairs=[]
    for i in range(len(classes)):
        for j in range(len(classes)):
            if i==j: continue
            if cm[i][j]>0: confpairs.append((int(classes[i] is not None)*cm[i][j],classes[i],classes[j],cm[i][j]))
    confpairs=[(n,a,b) for n,a,b in [(cm[i][j],classes[i],classes[j]) for i in range(len(classes)) for j in range(len(classes)) if i!=j and cm[i][j]>0]]
    confpairs.sort(reverse=True)
    print("=== top confusions (true -> predicted : count) ===")
    for n,a,b in confpairs[:8]:
        print(f"  {a:18s} -> {b:18s} : {n}")

    # 4) Live demo queries across languages — proves the runtime works
    demos=[
      ("en","Take me to Jezero Crater","navigate"),
      ("zh","带我去奥林匹斯山","navigate"),
      ("es","activa la capa mola","activate_layer"),
      ("fr","profil d'élévation de Olympus Mons à Hellas","elevation_profile"),
      ("de","erstelle eine rover mission von Gale zu Hellas","create_mission"),
      ("ru","оптимизируй для науки","optimize_route"),
      ("ar","اعرض تظليل","activate_layer"),
      ("hi","800 किमी के भीतर लक्ष्य ढूंढो","find_targets"),
      ("ja","ルートを説明して","explain_route"),
      ("en","how long is a martian day","planet_fact"),
      ("en","where am i","current_context"),
      ("zh","这里有多高","elevation_here"),
    ]
    print("=== live demo (JS-inference on exported model) ===")
    correct=0
    for lang,q,expected in demos:
        pred,conf,top=js_infer(model,q)
        ok=pred==expected; correct+=ok
        flag="OK " if ok else "!! "
        print(f"  [{lang}] {flag} '{q}' -> {pred} (p={conf:.2f})  expected={expected}")
    print(f"demo accuracy: {correct}/{len(demos)}")

if __name__=="__main__":
    main()
